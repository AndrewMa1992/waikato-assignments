using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Circuits
{
    /// <summary>
    /// The main GUI for the COMP104 digital circuits editor.
    /// This has a toolbar, containing buttons called buttonAnd, buttonOr, etc.
    /// The contents of the circuit are drawn directly onto the form.
    /// 
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// The (x,y) mouse position of the last MouseDown event.
        /// </summary>
        protected int startX, startY;

        /// <summary>
        /// If this is non-null, we are inserting a wire by
        /// dragging the mouse from startPin to some output Pin.
        /// </summary>
        protected Pin startPin = null;

        /// <summary>
        /// The (x,y) position of the current gate, just before we started dragging it.
        /// </summary>
        protected int currentX, currentY;

        /// <summary>
        /// The set of gates in the circuit
        /// </summary>
        protected List<Gate> gates = new List<Gate>();

        /// <summary>
        /// The set of connector wires in the circuit
        /// </summary>
        protected List<Wire> wires = new List<Wire>();

        /// <summary>
        /// The currently selected gate, or null if no gate is selected.
        /// </summary>
        protected Gate current = null;

        /// <summary>
        /// The new gate that is about to be inserted into the circuit
        /// </summary>
        protected Gate newGate = null;

        /// <summary>
        /// the new compound to be initilised 
        /// </summary>
        protected Compound compound1;

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
        }

        /// <summary>
        /// Finds the pin that is close to (x,y), or returns
        /// null if there are no pins close to the position.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public Pin findPin(int x, int y)
        {
            foreach (Gate g in gates)
            {
                foreach (Pin p in g.Pins)
                {
                    if (p.isMouseOn(x, y))
                        return p;
                }
            }
            return null;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
                foreach (Gate g in gates)
                {
                    g.Draw(e.Graphics);
                }
                foreach (Wire w in wires)
                {
                    w.Draw(e.Graphics);
                }
                if (startPin != null)
                {
                    e.Graphics.DrawLine(Pens.White,
                        startPin.X, startPin.Y,
                        currentX, currentY);
                }
                if (newGate != null)
                {
                    // show the gate that we are dragging into the circuit
                    newGate.MoveTo(currentX, currentY);
                    newGate.Draw(e.Graphics);
                }
            
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (compound1 != null) //when new compound has been initilised
            {
                foreach (Gate g in gates)
                {
                    if (g.IsMouseOn(e.X, e.Y))
                    {
                        compound1.AddGate(g); //add the clicked object to inside list of gates
                        
                    }
                }
            }
            if (current != null &&!(current is InputSource)) //if there is a selected gate but is not inputsource
            {
                current.Selected = false;
                current = null;
                this.Invalidate();
            }
            // See if we are inserting a new gate
            if (newGate != null)
            {
                newGate.MoveTo(e.X, e.Y);
                gates.Add(newGate);
                newGate = null;
                this.Invalidate();
            }
            else
            {
                // search for the first gate under the mouse position
                foreach (Gate g in gates)
                {
                    if (g.IsMouseOn(e.X, e.Y))
                    {
                        if (g is InputSource)
                        {
                                if (g.Selected) //deselect the input source
                                {
                                    g.Selected = false;
                                    current = null;
                                }
                                else
                                {
                                    g.Selected = true;
                                    current = g;
                                }
                        }
                        else
                        {
                            g.Selected = true;
                            current = g;
                        }
                        this.Invalidate();
                        break;
                     }
                 }
             }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (current == null)
            {
                // try to start adding a wire
                startPin = findPin(e.X, e.Y);
            }
            else if (current.IsMouseOn(e.X, e.Y))
            {
                // start dragging the current object around
                startX = e.X;
                startY = e.Y;
                currentX = current.Left;
                currentY = current.Top;
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (startPin != null)
            {
                Debug.WriteLine("wire from "+startPin+" to " + e.X + "," + e.Y);
                currentX = e.X;
                currentY = e.Y;
                this.Invalidate();  // this will draw the line
            }
            else if (startX >= 0 && startY >= 0 && current != null)
            {
                Debug.WriteLine("mouse move to " + e.X + "," + e.Y);
                current.MoveTo(currentX + (e.X - startX), currentY + (e.Y - startY));
                this.Invalidate();
            }
            else if (newGate != null)
            {
                currentX = e.X;
                currentY = e.Y;
                this.Invalidate();
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (startPin != null)
            {
                // see if we can insert a wire
                Pin endPin = findPin(e.X, e.Y);
                if (endPin != null)
                {
                    Debug.WriteLine("Trying to connect " + startPin + " to " + endPin);
                    Pin input, output;
                    if (startPin.IsOutput)
                    {
                        input = endPin;
                        output = startPin;
                    }
                    else
                    {
                        input = startPin;
                        output = endPin;
                    }
                    if (input.IsInput && output.IsOutput)
                    {
                        if (input.InputWire == null)
                        {
                            Wire newWire = new Wire(output, input);
                            input.InputWire = newWire;
                            wires.Add(newWire);
                        }
                        else
                        {
                            MessageBox.Show("That input is already used.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error: you must connect an output pin to an input pin.");
                    }
                }
                startPin = null;
                this.Invalidate();
            }
            // We have finished moving/dragging
            startX = -1;
            startY = -1;
            currentX = 0;
            currentY = 0;
        }
        /// <summary>
        /// add new And Gate
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AndGate_Button_Click(object sender, EventArgs e)
        {
            newGate = new AndGate(0, 0);
        }

        private void OrGate_Button_Click(object sender, EventArgs e)
        {
            newGate = new OrGate(0, 0);
        }

        private void NotGate_Button_Click(object sender, EventArgs e)
        {
            newGate = new NotGate(0, 0);
        }

        private void InputSource_Button_Click(object sender, EventArgs e)
        {
            newGate = new InputSource(0, 0);
        }

        private void OutputSource_Button_Click(object sender, EventArgs e)
        {
            newGate = new OutputSource(0, 0);
        }

        /// <summary>
        /// Evaluate the output of the whole circuit when its clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Evaluate_Button_Click(object sender, EventArgs e)
        {//evaluate
            foreach (Gate item in gates)
            {
                if (item is OutputSource)
                {
                    try
                    {
                        if (item.Evaluate())
                        {
                            item.Selected = true;
                        }
                        else
                        {
                            item.Selected = false;
                            
                        }
                        this.Invalidate();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    
                    
                }
            }

        }

        /// <summary>
        /// clone the selected object
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Copy_Button_Click(object sender, EventArgs e)
        {//clone
            foreach (Gate item in gates)
            {
                if (item.Selected)
                {
                    if (item is Compound) //if the object is compound, use special clone method
                    {
                        Compound newcom = (Compound)item;
                        newGate = newcom.CloneS(item);
                    }
                    else
                    {
                        newGate = item.Clone();
                        item.Selected = false;
                    }
                    
                    
                }
            }
        }

        /// <summary>
        /// create a new compound gate object, then the user clicks on the gate to include it in the new compound gate
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NewGroup_Button_Click(object sender, EventArgs e)
        {
            compound1 = new Compound(0,0,this.Width,this.Height);
        }

        /// <summary>
        /// once finish choosing gates for the compound gate, this button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EndGroup_Button_Click(object sender, EventArgs e)
        {//end group

            /// <summery>
            /// remove all the wires which are moved into the compound gate in the current form
            if (wires.Count != 0)
            {
                List<Wire> wirestomove = new List<Wire>();
                foreach (Wire w in wires)
                {
                    //if the wire is connected between gates which are selected as parts of compound gate
                    if (compound1.GatesInside.Contains(w.FromPin.Owner) && compound1.GatesInside.Contains(w.ToPin.Owner))
                    {
                        compound1.AddWiresInside(w);
                        wirestomove.Add(w);
                    }
                }
                foreach (Wire w in wirestomove)
                {
                    wires.Remove(w);
                }
                wirestomove.Clear();
            }
            
            /// <summery>
            /// remove all the gates which are moved into the compound gate in the current form
            /// 
            if (gates.Count != 0)
            {
                List<Gate> gatestoremove = new List<Gate>();
                foreach (Gate g in gates)
                {
                    if (compound1.GatesInside.Contains(g))
                    {
                        gatestoremove.Add(g);
                    }
                }
                foreach (Gate g in gatestoremove)
                {
                    gates.Remove(g);
                }
                gatestoremove.Clear();
            }
            else
            {
                MessageBox.Show("no gates are selected for compound gate");
            }

            /// <summery>
            /// initilise the compound gate
            compound1.CalculateMargins();
            newGate = compound1;
            compound1 = null;
        }

        /// <summary>
        /// clear all the objects in the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_Button_Click(object sender, EventArgs e)
        {//clear
            gates.Clear();
            wires.Clear();
            this.Invalidate();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
