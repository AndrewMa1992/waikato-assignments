﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;

namespace Circuits
{
    [Serializable]
    class OutputSource : Gate
    {
        /// <summary>
        /// indicating whether it has voltage through, true for yes, false for no
        /// </summary>
        private bool voltage = false;
        public bool VOLTAGE { get { return voltage; } set { voltage = value; } }
        public OutputSource(int x, int y)
            : base(x, y)
        {
            pins.Add(new Pin(this, true, 20));
            WIDTH = 25;
            HEIGHT = 25;
            MoveTo(x, y); // move the gate and position the pins
        }

        /// <summary>
        /// draw an ecclipse to represent the outputsource, it becomes yellow when selected, otherwise gray
        /// </summary>
        /// <param name="paper"></param>
        public override void Draw(Graphics paper)
        {
            Brush brush;
            voltage = selected;
            if (selected)
            {
                brush = Brushes.Yellow;
            }
            else
            {
                brush = Brushes.LightGray;
            }
            foreach (Pin p in pins)
                p.Draw(paper);
            
            paper.FillEllipse(brush, left, top, WIDTH, HEIGHT);
        }

        public override void MoveTo(int x, int y)
        {
            Debug.WriteLine("pins = " + pins.Count);
            left = x;
            top = y;
            // must move the pins too
            pins[0].X = x - GAP;
            pins[0].Y = y + HEIGHT / 2;
        }
        public override bool Evaluate()
        {
            if (pins[0].InputWire != null)
            {
                Gate gateA = pins[0].InputWire.FromPin.Owner;
                try
                {
                    return gateA.Evaluate(); //return the results of the input
                }
                catch (Exception)
                {
                    throw;
                }

            }
            else
            {
                throw new System.Exception("no input value for OutputSource");
            }
        }
        public override Gate Clone()
        {
            return new OutputSource(0, 0);
        }
    }
}
