﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;

namespace Circuits
{
    [Serializable]
    public class InputSource : Gate
    {
        /// <summary>
        /// whether there is voltage through
        /// </summary>
        private bool voltage = false;
        public bool VOLTAGE { get { return voltage; } set { voltage = value; } }
        public InputSource(int x, int y)
            : base(x, y)
        {
            pins.Add(new Pin(this, false, 20));
            WIDTH = 25;
            HEIGHT = 25;
            MoveTo(x, y); // move the gate and position the pins
        }

        public override void Draw(Graphics paper)
        {
            Brush brush;
            voltage = selected;
            if (selected)
            {
                brush = Brushes.Yellow;
            }
            else
            {
                brush = Brushes.LightGray;
            }
            foreach (Pin p in pins)
                p.Draw(paper);
            //draw the rectangle to represent input, if the input is selected, it becomes yellow, otherwise gray
            paper.FillRectangle(brush, left, top, WIDTH, HEIGHT);
        }

        public override void MoveTo(int x, int y)
        {
            Debug.WriteLine("pins = " + pins.Count);
            left = x;
            top = y;
            // must move the pins too
            pins[0].X = x + WIDTH + GAP;
            pins[0].Y = y + HEIGHT/2;
        }
        public override bool Evaluate()
        {
            return voltage; 
        }
        public override Gate Clone()
        {
            return new InputSource(0, 0);
        }
    }
}
