﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;

namespace Circuits
{
    [Serializable]
    class NotGate : Gate
    {
        
        public NotGate(int x, int y)
            : base(x, y)
        {
            pins.Add(new Pin(this, true, 20));

            pins.Add(new Pin(this, false, 20));
            MoveTo(x, y); // move the gate and position the pins
        }

        public override void Draw(Graphics paper)
        {
            Image img;
            if (selected)
            {
                img = Properties.Resources.NotGateRed;
            }
            else
            {
                img = Properties.Resources.NotGate;
            }
            
            foreach (Pin p in pins)
                p.Draw(paper);
            // AND is simple, so we can use a circle plus a rectange.
            // An alternative would be to use a bitmap.
            paper.DrawImage(img, left, top);
            //debug.WriteLine("notgate Draw" + left.ToString() + ", " + top.ToString());
        }

        public override void MoveTo(int x, int y)
        {
            //debug.WriteLine("notgate pins = " + pins.Count);
            left = x;
            top = y;
            // must move the pins too
            pins[0].X = x - GAP;
            pins[0].Y = y + GAP*2 +GAP/2;
            pins[1].X = x + WIDTH + 2*GAP;
            pins[1].Y = y + HEIGHT / 2+GAP/2;
        }
        public override bool Evaluate()
        {
            if (pins[0].InputWire != null)
            {
                Gate gateA = pins[0].InputWire.FromPin.Owner;
                try
                {
                    return !gateA.Evaluate(); //return the result of its input
                }
                catch (Exception)
                {
                    throw;
                }
                
            }
            else
            {
                throw new System.Exception("no input value for Not Gate");
            }

        }

        public override Gate Clone()
        {
            return new NotGate(0, 0);
        }
    }
}
