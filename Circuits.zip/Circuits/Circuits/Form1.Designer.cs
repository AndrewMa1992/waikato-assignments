namespace Circuits
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.AndGate_Button = new System.Windows.Forms.ToolStripButton();
            this.OrGate_Button = new System.Windows.Forms.ToolStripButton();
            this.NotGate_Button = new System.Windows.Forms.ToolStripButton();
            this.InpuutSource_Button = new System.Windows.Forms.ToolStripButton();
            this.OutputSource_Button = new System.Windows.Forms.ToolStripButton();
            this.Evaluate_Button = new System.Windows.Forms.ToolStripButton();
            this.Copy_Button = new System.Windows.Forms.ToolStripButton();
            this.StartGroup_Button = new System.Windows.Forms.ToolStripButton();
            this.EndGroup_Button = new System.Windows.Forms.ToolStripButton();
            this.Clear_Button = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AndGate_Button,
            this.OrGate_Button,
            this.NotGate_Button,
            this.InpuutSource_Button,
            this.OutputSource_Button,
            this.Evaluate_Button,
            this.Copy_Button,
            this.StartGroup_Button,
            this.EndGroup_Button,
            this.Clear_Button});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(472, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // AndGate_Button
            // 
            this.AndGate_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.AndGate_Button.Image = global::Circuits.Properties.Resources.AndIcon;
            this.AndGate_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AndGate_Button.Name = "AndGate_Button";
            this.AndGate_Button.Size = new System.Drawing.Size(23, 22);
            this.AndGate_Button.Text = "And Gate";
            this.AndGate_Button.Click += new System.EventHandler(this.AndGate_Button_Click);
            // 
            // OrGate_Button
            // 
            this.OrGate_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.OrGate_Button.Image = global::Circuits.Properties.Resources.OrIcon;
            this.OrGate_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OrGate_Button.Name = "OrGate_Button";
            this.OrGate_Button.Size = new System.Drawing.Size(23, 22);
            this.OrGate_Button.Text = "Or Gate";
            this.OrGate_Button.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.OrGate_Button.Click += new System.EventHandler(this.OrGate_Button_Click);
            // 
            // NotGate_Button
            // 
            this.NotGate_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.NotGate_Button.Image = global::Circuits.Properties.Resources.NotIcon;
            this.NotGate_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.NotGate_Button.Name = "NotGate_Button";
            this.NotGate_Button.Size = new System.Drawing.Size(23, 22);
            this.NotGate_Button.Text = "Not Gate";
            this.NotGate_Button.Click += new System.EventHandler(this.NotGate_Button_Click);
            // 
            // InpuutSource_Button
            // 
            this.InpuutSource_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.InpuutSource_Button.Image = global::Circuits.Properties.Resources.InputIcon;
            this.InpuutSource_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.InpuutSource_Button.Name = "InpuutSource_Button";
            this.InpuutSource_Button.Size = new System.Drawing.Size(23, 22);
            this.InpuutSource_Button.Text = "Input";
            this.InpuutSource_Button.Click += new System.EventHandler(this.InputSource_Button_Click);
            // 
            // OutputSource_Button
            // 
            this.OutputSource_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.OutputSource_Button.Image = global::Circuits.Properties.Resources.OutputIcon;
            this.OutputSource_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OutputSource_Button.Name = "OutputSource_Button";
            this.OutputSource_Button.Size = new System.Drawing.Size(23, 22);
            this.OutputSource_Button.Text = "Output";
            this.OutputSource_Button.Click += new System.EventHandler(this.OutputSource_Button_Click);
            // 
            // Evaluate_Button
            // 
            this.Evaluate_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Evaluate_Button.Image = global::Circuits.Properties.Resources.EvaluateIcon;
            this.Evaluate_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Evaluate_Button.Name = "Evaluate_Button";
            this.Evaluate_Button.Size = new System.Drawing.Size(23, 22);
            this.Evaluate_Button.Text = "Evaluate";
            this.Evaluate_Button.Click += new System.EventHandler(this.Evaluate_Button_Click);
            // 
            // Copy_Button
            // 
            this.Copy_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Copy_Button.Image = global::Circuits.Properties.Resources.CopyIcon;
            this.Copy_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Copy_Button.Name = "Copy_Button";
            this.Copy_Button.Size = new System.Drawing.Size(23, 22);
            this.Copy_Button.Text = "Copy";
            this.Copy_Button.Click += new System.EventHandler(this.Copy_Button_Click);
            // 
            // StartGroup_Button
            // 
            this.StartGroup_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StartGroup_Button.Image = global::Circuits.Properties.Resources.StartCompoundIcon;
            this.StartGroup_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StartGroup_Button.Name = "StartGroup_Button";
            this.StartGroup_Button.Size = new System.Drawing.Size(23, 22);
            this.StartGroup_Button.Text = "Start Group";
            this.StartGroup_Button.Click += new System.EventHandler(this.NewGroup_Button_Click);
            // 
            // EndGroup_Button
            // 
            this.EndGroup_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.EndGroup_Button.Image = global::Circuits.Properties.Resources.EndCompoundIcon;
            this.EndGroup_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.EndGroup_Button.Name = "EndGroup_Button";
            this.EndGroup_Button.Size = new System.Drawing.Size(23, 22);
            this.EndGroup_Button.Text = "End Group";
            this.EndGroup_Button.Click += new System.EventHandler(this.EndGroup_Button_Click);
            // 
            // Clear_Button
            // 
            this.Clear_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Clear_Button.Image = ((System.Drawing.Image)(resources.GetObject("Clear_Button.Image")));
            this.Clear_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Clear_Button.Name = "Clear_Button";
            this.Clear_Button.Size = new System.Drawing.Size(38, 22);
            this.Clear_Button.Text = "Clear";
            this.Clear_Button.Click += new System.EventHandler(this.Clear_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(472, 307);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form1";
            this.Text = "Digital Circuits 104";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton AndGate_Button;
        private System.Windows.Forms.ToolStripButton OrGate_Button;
        private System.Windows.Forms.ToolStripButton NotGate_Button;
        private System.Windows.Forms.ToolStripButton InpuutSource_Button;
        private System.Windows.Forms.ToolStripButton OutputSource_Button;
        private System.Windows.Forms.ToolStripButton Evaluate_Button;
        private System.Windows.Forms.ToolStripButton Copy_Button;
        private System.Windows.Forms.ToolStripButton StartGroup_Button;
        private System.Windows.Forms.ToolStripButton EndGroup_Button;
        private System.Windows.Forms.ToolStripButton Clear_Button;
    }
}

