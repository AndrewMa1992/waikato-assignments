using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;

namespace Circuits
{
    /// <summary>
    /// This class implements an AND gate with two inputs
    /// and one output.
    /// </summary>
    [Serializable]
    public class AndGate : Gate
    {
        public AndGate(int x, int y) : base(x,y)
        {
            //two input and one output
            pins.Add(new Pin(this, true, 20));
            pins.Add(new Pin(this, true, 20));
            pins.Add(new Pin(this, false, 20));
            MoveTo(x, y); // move the gate and position the pins
        }

        public override void Draw(Graphics paper)
        {
            Brush brush;
            if (selected)
            {
                brush = Brushes.Red;
            }
            else
            {
                brush = Brushes.LightGray;
            }
            foreach (Pin p in pins)
                p.Draw(paper);

            // AND is simple, so we can use a circle plus a rectange.
            // An alternative would be to use a bitmap.
            paper.FillEllipse(brush, left, top, WIDTH, HEIGHT);
            paper.FillRectangle(brush, left, top, WIDTH/2, HEIGHT);
            //debug.WriteLine("Andgate Draw" + left.ToString() + ", " + top.ToString());
        }

        public override void MoveTo(int x, int y)
        {
            //debug.WriteLine("Andgate pins = " + pins.Count);
            left = x;
            top = y;
            // must move the pins too
            pins[0].X = x - GAP;
            pins[0].Y = y + GAP;
            pins[1].X = x - GAP;
            pins[1].Y = y + HEIGHT - GAP;
            pins[2].X = x + WIDTH + GAP;
            pins[2].Y = y + HEIGHT / 2;
        }

        public override bool Evaluate()
        {
            if (pins[0].InputWire != null && pins[1].InputWire != null) //if there are two inputs
            {
                Gate gateA = pins[0].InputWire.FromPin.Owner;
                Gate gateB = pins[1].InputWire.FromPin.Owner;
                try
                {
                    return gateA.Evaluate() && gateB.Evaluate();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            else
            {
                throw new System.Exception("no input value for And Gate");
            }
        }
        public override Gate Clone()
        {
            return new AndGate(0, 0);
        }
    }
}
