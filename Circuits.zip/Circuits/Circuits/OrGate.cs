﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;

namespace Circuits
{
    [Serializable]
    class OrGate : Gate
    {
        public OrGate(int x, int y): base(x,y)
        {
            pins.Add(new Pin(this, true, 20)); //two input
            pins.Add(new Pin(this, true, 20));

            pins.Add(new Pin(this, false, 20));
            WIDTH = 50;
            MoveTo(x, y); // move the gate and position the pins
            
        }

        public override void Draw(Graphics paper)
        {
            Image img;
            if (selected)
            {
                img = Properties.Resources.OrGateRed;
            }
            else
            {
                img = Properties.Resources.OrGate;
            }
            foreach (Pin p in pins)
                p.Draw(paper);

            // AND is simple, so we can use a circle plus a rectange.
            // An alternative would be to use a bitmap.
            //paper.FillEllipse(brush, left, top, WIDTH, HEIGHT);
            paper.DrawImage(img, left, top);
            //Debug.WriteLine("Orgate Draw" +left.ToString() + ", " + top.ToString());
        }

        public override void MoveTo(int x, int y)
        {
            //debug.WriteLine("orgate pins = " + pins.Count);
            left = x;
            top = y;
            // must move the pins too
            pins[0].X = x - GAP/2;
            pins[0].Y = y + GAP;
            pins[1].X = x - GAP/2;
            pins[1].Y = y + HEIGHT;
            pins[2].X = x + WIDTH + 3*GAP;
            pins[2].Y = y + HEIGHT / 2 + GAP/2;
        }

        public override bool Evaluate()
        {
            if (pins[0].InputWire != null && pins[1].InputWire != null)
            {
                Gate gateA = pins[0].InputWire.FromPin.Owner;
                Gate gateB = pins[1].InputWire.FromPin.Owner;
                try
                {
                    return gateA.Evaluate() || gateB.Evaluate();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            else
            {
                throw new System.Exception("no input value for Or Gate");
            }
            
        }
        public override Gate Clone()
        {
            return new OrGate(0,0);
        }

    }
}
