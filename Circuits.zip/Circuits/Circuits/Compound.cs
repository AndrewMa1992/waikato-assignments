﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Circuits
{
    [Serializable]
    public class Compound:Gate
    {
        List<Gate> gatesinside = new List<Gate>();

        List<int> gatesmarginx = new List<int>();//each element of marginx, marginy correesponds to same element in gatesinside
        List<int> gatesmarginy = new List<int>();//gatesmarginx and gatesmarginy is the distance of each gate in respect to the top left gate;

        List<Wire> wireinside = new List<Wire>();

        int leftmost = 0; 
        int topmost = 0;
        int rightmostleft = 0;
        int downmosttop = 0; //four int values for the properties of the rectangle outside the compound gate
        
        public Compound(int x, int y, int formwidth, int formheight)
            : base(x, y)
        {
            leftmost = formwidth; 
            topmost = formheight; //set both values to the maximum possible, so that any value inputted is smaller then this.
            //the maximum left value is the formwidth, same for top value.
        }

        public List<Gate> GatesInside
        {
            get { return gatesinside; }
        }
        public void AddWiresInside (Wire w)
        {
            wireinside.Add(w);
        }

        /// <summary>
        /// the rightmost, leftmost, topmost, downmost are recalculated everytime a new gate is added
        /// </summary>
        /// <param name="newgate"></param>
        public void AddGate(Gate newgate)
        {
            if (newgate.Left < leftmost) //if there is a new smaller left value
	        {
		        leftmost = newgate.Left;
                if (rightmostleft == 0) //if this is the first one, set rightmost using the first gate
                {
                    rightmostleft = leftmost + newgate.Width;
                }
	        }
            else //if there is a bigger right value
            {
                rightmostleft = newgate.Left + newgate.Width;
            }
            if (newgate.Top < topmost)
	        {
		         topmost = newgate.Top;
                 if (downmosttop == 0)
                 {
                     downmosttop = topmost + newgate.Height;
                 }
	        }
            else
            {
                downmosttop = newgate.Top + newgate.Height;
            }
            width = rightmostleft - leftmost + 50; //extra 30 as offset
            height = downmosttop - topmost + 50;
            gatesinside.Add(newgate);
            //Debug.WriteLine(leftmost.ToString() + " Right: " + rightmostleft.ToString() + " WIDTH: " + newgate.Width.ToString());
        }
        public override Gate Clone()
        {
            throw new NotImplementedException();
        }
        public Gate CloneS(Gate source)
        {
            if (!typeof(Gate).IsSerializable)
            {
                throw new ArgumentException("The type must be serializable.", "source");
            }

            // Don't serialize a null object, simply return the default for that object
            if (Object.ReferenceEquals(source, null))
            {
                return default(Gate);
            }

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new MemoryStream();
            using (stream)
            {
                formatter.Serialize(stream, source);
                stream.Seek(0, SeekOrigin.Begin);
                return (Gate)formatter.Deserialize(stream);
            }
        }
        public override void Draw(System.Drawing.Graphics paper)
        {
            //if this compound gate is selected, set all gates inside compound gate to selected
            bool state = false;
            if (selected)
            {
                state = true;
            }
            else
            {
                state = false;
            }
            foreach (Gate g in gatesinside)
            {
                g.Selected = state;
            }
            
            //draw all the wire inside
            if (wireinside.Count != 0)
            {
                foreach (Wire w in wireinside)
                {
                    w.Draw(paper);
                }
            }

            //draw all the gates inside, then draw the rectangle outside
            if (gatesinside.Count != 0)
            {
                foreach (Gate g in gatesinside)
                {
                   g.Draw(paper);
                }

                Pen newpen = new Pen(Brushes.Red);
                paper.DrawRectangle(newpen, left-2*GAP, top-GAP, width, height); //pin takes up a GAP on the left, and we use another GAP for offset
            }

            
            
        }
        public override void MoveTo(int x, int y)
        {
            //Debug.WriteLine("pins = " + pins.Count);
            left = x;
            top = y;
            for (int i = 0; i < gatesinside.Count; i++)
            {
                gatesinside[i].MoveTo(x + gatesmarginx[i], y + gatesmarginy[i]); //each gate is drawn with respect to the top left
            }
            
        }

        /// <summary>
        /// evaluation is not required for compound gate
        /// </summary>
        /// <returns></returns>
        public override bool Evaluate()
        {
            return false;
        }
        /// <summary>
        /// this is called when the end group is pressed
        /// it calculates the margin of each gate inside the compound gate with respect to top left
        /// </summary>
        public void CalculateMargins()
        {
            for (int i = 0; i < gatesinside.Count; i++)
            {
                if (gatesinside[i].Left != leftmost) //if they are not equal, then there is a margin
                {
                    gatesmarginx.Add(gatesinside[i].Left - leftmost); //gets the margin between leftmost and the left of current gate
                }
                else
                {
                    gatesmarginx.Add(0); //if they are equal, just add 0 to ensure consistency between margin list and gatesinside list
                }
                if (gatesinside[i].Top != topmost)
                {
                    gatesmarginy.Add(gatesinside[i].Top - topmost);
                }
                else
                {
                    gatesmarginy.Add(0);
                }
            }
        }

    }
}
