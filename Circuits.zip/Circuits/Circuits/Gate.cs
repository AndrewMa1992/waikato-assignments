﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
namespace Circuits
{
    [Serializable] //all classes are marked serilizable so that it can be cloned using serialization
    abstract public class Gate
    {
        // width and height of the main part of the gate
        protected int width = 40;
        protected int height = 40;
        private int gap = 10;
        protected int WIDTH { get { return width; } set { width = value; } }
        protected int HEIGHT { get { return height; } set { height = value; } }
        // length of the connector legs sticking out left and right
        protected int GAP { get { return gap; } set { gap = value; } }

        // left is the left-hand edge of the main part of the gate.
        // So the input pins are further left than left.
        protected int left;

        // top is the top of the whole gate
        protected int top;

        /// <summary>
        /// This is the list of all the pins of this gate.
        /// An AND gate always has two input pins (0 and 1)
        /// and one output pin (number 2).
        /// </summary>
        protected List<Pin> pins = new List<Pin>();

        /// <summary>
        /// Indicates whether this gate is the current one selected.
        /// </summary>
        protected bool selected = false;

        /// <summary>
        /// constructor of the gate, details to be implemented by the subclass
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public Gate(int x, int y)
        {
            
        }
        
        public bool Selected
        {
            get { return selected; }
            set { selected = value; }
        }

        public int Left
        {
            get { return left; }
            set { left = value; }
        }

        public int Top
        {
            get { return top; }
            set { top = value; }
        }
        public int Width
        {
            get { return width; }
        }
        public int Height
        {
            get { return height; }
        }

        public List<Pin> Pins
        {
            get { return pins; }
        }

        

        /// <summary>
        /// True if the given (x,y) position is roughly
        /// on top of this gate.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public bool IsMouseOn(int x, int y)
        {
            if (left <= x && x < left + WIDTH
                && top <= y && y < top + HEIGHT)
                return true;
            else
                return false;
        }

        /// <summary>
        /// this is called when the form is painted, the object draws itself in the paper
        /// the color of object depends on the state of the object (selected or not)
        /// </summary>
        /// <param name="paper"></param>
        public abstract void Draw(Graphics paper);

        /// <summary>
        /// objects is moved to x and y from the current position
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public abstract void MoveTo(int x, int y);

        /// <summary>
        /// evaluate the inputs and return value of the output
        /// </summary>
        /// <returns></returns>
        public abstract bool Evaluate();

        /// <summary>
        /// copy itself, the compound gate has a special method since it requires a deep clone of itself
        /// </summary>
        /// <returns></returns>
        public abstract Gate Clone();
    }
}
