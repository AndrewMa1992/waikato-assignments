﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class DoctorReg : Form
    {
        public DoctorReg()
        {
            InitializeComponent();
        }

        private bool news = false;
        private int spec_code = 0;
        private int doct_id = 0;
        private void DoctorReg_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'doctorSingleDataSet.has' table. You can move, or remove it, as needed.
            this.hasTableAdapter.Fill(this.doctorSingleDataSet.has);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.Specialisation' table. You can move, or remove it, as needed.
            this.specialisationTableAdapter.Fill(this.doctorSingleDataSet.Specialisation);
            // TODO: This line of code loads data into the 'dataSpecDataSet.doctorSpec' table. You can move, or remove it, as needed.
            this.doctorSpecTableAdapter.Fill(this.dataSpecDataSet.doctorSpec);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.Doctor' table. You can move, or remove it, as needed.
            this.doctorTableAdapter.Fill(this.doctorSingleDataSet.Doctor);

        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            if (spec_code == 0)
            {
                MessageBox.Show("please select a specilisation");
                return;
            }
            try
            {
                int ID = 0;
                DataRow newrow1 = doctorSingleDataSet.Doctor.NewRow();
                if (doctorSingleDataSet.Tables["Doctor"].Rows.Count != 0)
                {
                    ID = Convert.ToInt16(doctorSingleDataSet.Tables["Doctor"].Rows[doctorSingleDataSet.Tables["Doctor"].Rows.Count - 1].ItemArray[0]) + 1;
                }
                else
                {
                    ID = 1;
                }
                newrow1["d_id"] = ID;
                newrow1["dfname"] = dfnameTextBox.Text;
                newrow1["dlname"] = dlnameTextBox.Text;
                newrow1["d_username"] = d_usernameTextBox.Text;
                newrow1["d_password"] = d_passwordTextBox.Text;
                doctorSingleDataSet.Doctor.Rows.Add(newrow1);


                DataRow newrow2 = doctorSingleDataSet.has.NewRow();
                newrow2["h_doctor_id"] = ID;
                newrow2["h_spec_id"] = spec_code;
                doctorSingleDataSet.has.Rows.Add(newrow2);
                doctorTableAdapter.Update(doctorSingleDataSet.Doctor);
                hasTableAdapter.Update(doctorSingleDataSet.has);
            }
            catch (Exception)
            {
                MessageBox.Show("fail to add data, please try again");
                throw;
            }

        }

        private void cleartext()
        {
            try
            {
                foreach (Control c in this.Controls)
                {
                    if (c is TextBox)
                    {
                        (c as TextBox).Clear();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("fail to clear text");
            }
        }

        private void btnNewSpec_Click(object sender, EventArgs e)
        {
            if (!news)
            {
                nameTextBox.Text = "";
                s_descriptionTextBox.Text = "";
                news = true;
                btnNewSpec.Text = "Save New Specilisation";
            }
            else
            {
                try
                {
                    DataRow newrow2 = doctorSingleDataSet.Specialisation.NewRow();
                    int ID = 0;
                    if (doctorSingleDataSet.Tables["Specialisation"].Rows.Count != 0)
                    {
                        ID = Convert.ToInt16(doctorSingleDataSet.Tables["Specialisation"].Rows[doctorSingleDataSet.Tables["Specialisation"].Rows.Count - 1].ItemArray[0]) + 1;
                    }
                    else
                    {
                        ID = 1;
                    }
                    newrow2["code"] = ID;
                    newrow2["name"] = nameTextBox.Text;
                    newrow2["s_description"] = s_descriptionTextBox.Text;
                    doctorSingleDataSet.Specialisation.Rows.Add(newrow2);
                    specialisationTableAdapter.Update(doctorSingleDataSet.Specialisation);
                    news = false;
                }
                catch (Exception)
                {

                    MessageBox.Show("fail to add specilisation, please try again");
                }

            }
        }

        private void doctorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.doctorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.doctorSingleDataSet);

        }

        private void doctorBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.doctorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.doctorSingleDataSet);

        }


    }
}
