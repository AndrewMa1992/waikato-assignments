﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class DoctorStart : Form
    {
        public DoctorStart()
        {
            InitializeComponent();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            DoctorReg reg = new DoctorReg();
            reg.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int ID = 0;
            bool su = false;
            try
            {
                if (doctorSingleDataSet.Tables["Doctor"].Rows.Count != 0)
                {
                    for (int i = 0; i < doctorSingleDataSet.Tables["Doctor"].Rows.Count; i++)
                    {
                        if (textBox1.Text == doctorSingleDataSet.Tables["Doctor"].Rows[i].ItemArray[3].ToString()) //if the relationship exist in the doctor dateset
                        {
                            if (textBox2.Text == doctorSingleDataSet.Tables["Doctor"].Rows[i].ItemArray[4].ToString())
                            {
                                ID = Convert.ToInt16(doctorSingleDataSet.Tables["Doctor"].Rows[i]["d_id"]);
                                su = true;
                                break;
                            }
                        }
                    }
                    if (su)
                    {
                        Doctor doc = new Doctor();
                        doc.ID = ID;
                        doc.Show();
                    }
                    else
                    {
                        MessageBox.Show("wrong password or mail, try again");
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void doctorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.doctorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.doctorSingleDataSet);

        }

        private void DoctorStart_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'doctorSingleDataSet.Doctor' table. You can move, or remove it, as needed.
            this.doctorTableAdapter.Fill(this.doctorSingleDataSet.Doctor);

        }
    }
}
