﻿namespace hospital2
{
    partial class PatientReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dobLabel1;
            System.Windows.Forms.Label emailLabel1;
            System.Windows.Forms.Label phoneLabel1;
            System.Windows.Forms.Label pfnameLabel1;
            System.Windows.Forms.Label plnameLabel1;
            System.Windows.Forms.Label genderLabel1;
            System.Windows.Forms.Label p_passwordLabel1;
            System.Windows.Forms.Label confirmedLabel;
            System.Windows.Forms.Label notesLabel;
            System.Windows.Forms.Label b_weightLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label i_descriptionLabel;
            System.Windows.Forms.Label amountLabel;
            System.Windows.Forms.Label i_statusLabel;
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.btnReg = new System.Windows.Forms.Button();
            this.bookscheduleDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookscheduleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookscheduleDataSet = new hospital2.bookscheduleDataSet();
            this.dobDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.emailTextBox1 = new System.Windows.Forms.TextBox();
            this.phoneTextBox1 = new System.Windows.Forms.TextBox();
            this.pfnameTextBox1 = new System.Windows.Forms.TextBox();
            this.plnameTextBox1 = new System.Windows.Forms.TextBox();
            this.genderTextBox1 = new System.Windows.Forms.TextBox();
            this.p_passwordTextBox1 = new System.Windows.Forms.TextBox();
            this.bookscheduleTableAdapter = new hospital2.bookscheduleDataSetTableAdapters.bookscheduleTableAdapter();
            this.tableAdapterManager1 = new hospital2.bookscheduleDataSetTableAdapters.TableAdapterManager();
            this.patientDataSet = new hospital2.patientDataSet();
            this.tableAdapterManager = new hospital2.patientDataSetTableAdapters.TableAdapterManager();
            this.patientTableAdapter = new hospital2.patientDataSetTableAdapters.PatientTableAdapter();
            this.patientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.confirmedTextBox = new System.Windows.Forms.TextBox();
            this.notesTextBox = new System.Windows.Forms.TextBox();
            this.b_weightTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.i_descriptionTextBox = new System.Windows.Forms.TextBox();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.i_statusTextBox = new System.Windows.Forms.TextBox();
            this.invoiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.patientSingleDataSet = new hospital2.patientSingleDataSet();
            this.illnessBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.patientBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.patientTableAdapter1 = new hospital2.patientSingleDataSetTableAdapters.PatientTableAdapter();
            this.tableAdapterManager2 = new hospital2.patientSingleDataSetTableAdapters.TableAdapterManager();
            this.bookTableAdapter = new hospital2.patientSingleDataSetTableAdapters.bookTableAdapter();
            this.illnessTableAdapter = new hospital2.patientSingleDataSetTableAdapters.illnessTableAdapter();
            this.invoiceTableAdapter = new hospital2.patientSingleDataSetTableAdapters.InvoiceTableAdapter();
            dobLabel1 = new System.Windows.Forms.Label();
            emailLabel1 = new System.Windows.Forms.Label();
            phoneLabel1 = new System.Windows.Forms.Label();
            pfnameLabel1 = new System.Windows.Forms.Label();
            plnameLabel1 = new System.Windows.Forms.Label();
            genderLabel1 = new System.Windows.Forms.Label();
            p_passwordLabel1 = new System.Windows.Forms.Label();
            confirmedLabel = new System.Windows.Forms.Label();
            notesLabel = new System.Windows.Forms.Label();
            b_weightLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            i_descriptionLabel = new System.Windows.Forms.Label();
            amountLabel = new System.Windows.Forms.Label();
            i_statusLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bookscheduleDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookscheduleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookscheduleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientSingleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.illnessBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dobLabel1
            // 
            dobLabel1.AutoSize = true;
            dobLabel1.Location = new System.Drawing.Point(32, 59);
            dobLabel1.Name = "dobLabel1";
            dobLabel1.Size = new System.Drawing.Size(28, 13);
            dobLabel1.TabIndex = 20;
            dobLabel1.Text = "dob:";
            // 
            // emailLabel1
            // 
            emailLabel1.AutoSize = true;
            emailLabel1.Location = new System.Drawing.Point(32, 84);
            emailLabel1.Name = "emailLabel1";
            emailLabel1.Size = new System.Drawing.Size(34, 13);
            emailLabel1.TabIndex = 22;
            emailLabel1.Text = "email:";
            // 
            // phoneLabel1
            // 
            phoneLabel1.AutoSize = true;
            phoneLabel1.Location = new System.Drawing.Point(32, 110);
            phoneLabel1.Name = "phoneLabel1";
            phoneLabel1.Size = new System.Drawing.Size(40, 13);
            phoneLabel1.TabIndex = 24;
            phoneLabel1.Text = "phone:";
            // 
            // pfnameLabel1
            // 
            pfnameLabel1.AutoSize = true;
            pfnameLabel1.Location = new System.Drawing.Point(32, 136);
            pfnameLabel1.Name = "pfnameLabel1";
            pfnameLabel1.Size = new System.Drawing.Size(45, 13);
            pfnameLabel1.TabIndex = 26;
            pfnameLabel1.Text = "pfname:";
            // 
            // plnameLabel1
            // 
            plnameLabel1.AutoSize = true;
            plnameLabel1.Location = new System.Drawing.Point(32, 162);
            plnameLabel1.Name = "plnameLabel1";
            plnameLabel1.Size = new System.Drawing.Size(44, 13);
            plnameLabel1.TabIndex = 28;
            plnameLabel1.Text = "plname:";
            // 
            // genderLabel1
            // 
            genderLabel1.AutoSize = true;
            genderLabel1.Location = new System.Drawing.Point(32, 188);
            genderLabel1.Name = "genderLabel1";
            genderLabel1.Size = new System.Drawing.Size(43, 13);
            genderLabel1.TabIndex = 30;
            genderLabel1.Text = "gender:";
            // 
            // p_passwordLabel1
            // 
            p_passwordLabel1.AutoSize = true;
            p_passwordLabel1.Location = new System.Drawing.Point(32, 214);
            p_passwordLabel1.Name = "p_passwordLabel1";
            p_passwordLabel1.Size = new System.Drawing.Size(64, 13);
            p_passwordLabel1.TabIndex = 32;
            p_passwordLabel1.Text = "p password:";
            // 
            // confirmedLabel
            // 
            confirmedLabel.AutoSize = true;
            confirmedLabel.Location = new System.Drawing.Point(32, 251);
            confirmedLabel.Name = "confirmedLabel";
            confirmedLabel.Size = new System.Drawing.Size(56, 13);
            confirmedLabel.TabIndex = 41;
            confirmedLabel.Text = "confirmed:";
            // 
            // notesLabel
            // 
            notesLabel.AutoSize = true;
            notesLabel.Location = new System.Drawing.Point(32, 277);
            notesLabel.Name = "notesLabel";
            notesLabel.Size = new System.Drawing.Size(36, 13);
            notesLabel.TabIndex = 43;
            notesLabel.Text = "notes:";
            // 
            // b_weightLabel
            // 
            b_weightLabel.AutoSize = true;
            b_weightLabel.Location = new System.Drawing.Point(32, 303);
            b_weightLabel.Name = "b_weightLabel";
            b_weightLabel.Size = new System.Drawing.Size(50, 13);
            b_weightLabel.TabIndex = 45;
            b_weightLabel.Text = "b weight:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(30, 355);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(36, 13);
            nameLabel.TabIndex = 48;
            nameLabel.Text = "name:";
            // 
            // i_descriptionLabel
            // 
            i_descriptionLabel.AutoSize = true;
            i_descriptionLabel.Location = new System.Drawing.Point(30, 381);
            i_descriptionLabel.Name = "i_descriptionLabel";
            i_descriptionLabel.Size = new System.Drawing.Size(66, 13);
            i_descriptionLabel.TabIndex = 50;
            i_descriptionLabel.Text = "i description:";
            // 
            // amountLabel
            // 
            amountLabel.AutoSize = true;
            amountLabel.Location = new System.Drawing.Point(41, 433);
            amountLabel.Name = "amountLabel";
            amountLabel.Size = new System.Drawing.Size(45, 13);
            amountLabel.TabIndex = 53;
            amountLabel.Text = "amount:";
            // 
            // i_statusLabel
            // 
            i_statusLabel.AutoSize = true;
            i_statusLabel.Location = new System.Drawing.Point(41, 459);
            i_statusLabel.Name = "i_statusLabel";
            i_statusLabel.Size = new System.Drawing.Size(43, 13);
            i_statusLabel.TabIndex = 55;
            i_statusLabel.Text = "i status:";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(353, 55);
            this.monthCalendar1.MaxSelectionCount = 1;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 17;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // btnReg
            // 
            this.btnReg.Location = new System.Drawing.Point(227, 459);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(75, 23);
            this.btnReg.TabIndex = 18;
            this.btnReg.Text = "Register";
            this.btnReg.UseVisualStyleBackColor = true;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // bookscheduleDataGridView
            // 
            this.bookscheduleDataGridView.AllowUserToAddRows = false;
            this.bookscheduleDataGridView.AllowUserToDeleteRows = false;
            this.bookscheduleDataGridView.AutoGenerateColumns = false;
            this.bookscheduleDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookscheduleDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.bookscheduleDataGridView.DataSource = this.bookscheduleBindingSource;
            this.bookscheduleDataGridView.Location = new System.Drawing.Point(344, 262);
            this.bookscheduleDataGridView.Name = "bookscheduleDataGridView";
            this.bookscheduleDataGridView.ReadOnly = true;
            this.bookscheduleDataGridView.Size = new System.Drawing.Size(434, 220);
            this.bookscheduleDataGridView.TabIndex = 18;
            this.bookscheduleDataGridView.Click += new System.EventHandler(this.bookscheduleDataGridView_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "slot_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "slot_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "slot_date";
            this.dataGridViewTextBoxColumn2.HeaderText = "slot_date";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "start";
            this.dataGridViewTextBoxColumn3.HeaderText = "start";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "time_end";
            this.dataGridViewTextBoxColumn4.HeaderText = "time_end";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "doctor";
            this.dataGridViewTextBoxColumn5.HeaderText = "doctor";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn6.HeaderText = "name";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "nurse";
            this.dataGridViewTextBoxColumn7.HeaderText = "nurse";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // bookscheduleBindingSource
            // 
            this.bookscheduleBindingSource.DataMember = "bookschedule";
            this.bookscheduleBindingSource.DataSource = this.bookscheduleDataSet;
            // 
            // bookscheduleDataSet
            // 
            this.bookscheduleDataSet.DataSetName = "bookscheduleDataSet";
            this.bookscheduleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dobDateTimePicker1
            // 
            this.dobDateTimePicker1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.patientBindingSource1, "dob", true));
            this.dobDateTimePicker1.Location = new System.Drawing.Point(102, 55);
            this.dobDateTimePicker1.Name = "dobDateTimePicker1";
            this.dobDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dobDateTimePicker1.TabIndex = 21;
            // 
            // emailTextBox1
            // 
            this.emailTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource1, "email", true));
            this.emailTextBox1.Location = new System.Drawing.Point(102, 81);
            this.emailTextBox1.Name = "emailTextBox1";
            this.emailTextBox1.Size = new System.Drawing.Size(200, 20);
            this.emailTextBox1.TabIndex = 23;
            // 
            // phoneTextBox1
            // 
            this.phoneTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource1, "phone", true));
            this.phoneTextBox1.Location = new System.Drawing.Point(102, 107);
            this.phoneTextBox1.Name = "phoneTextBox1";
            this.phoneTextBox1.Size = new System.Drawing.Size(200, 20);
            this.phoneTextBox1.TabIndex = 25;
            // 
            // pfnameTextBox1
            // 
            this.pfnameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource1, "pfname", true));
            this.pfnameTextBox1.Location = new System.Drawing.Point(102, 133);
            this.pfnameTextBox1.Name = "pfnameTextBox1";
            this.pfnameTextBox1.Size = new System.Drawing.Size(200, 20);
            this.pfnameTextBox1.TabIndex = 27;
            // 
            // plnameTextBox1
            // 
            this.plnameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource1, "plname", true));
            this.plnameTextBox1.Location = new System.Drawing.Point(102, 159);
            this.plnameTextBox1.Name = "plnameTextBox1";
            this.plnameTextBox1.Size = new System.Drawing.Size(200, 20);
            this.plnameTextBox1.TabIndex = 29;
            // 
            // genderTextBox1
            // 
            this.genderTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource1, "gender", true));
            this.genderTextBox1.Location = new System.Drawing.Point(102, 185);
            this.genderTextBox1.Name = "genderTextBox1";
            this.genderTextBox1.Size = new System.Drawing.Size(200, 20);
            this.genderTextBox1.TabIndex = 31;
            // 
            // p_passwordTextBox1
            // 
            this.p_passwordTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource1, "p_password", true));
            this.p_passwordTextBox1.Location = new System.Drawing.Point(102, 211);
            this.p_passwordTextBox1.Name = "p_passwordTextBox1";
            this.p_passwordTextBox1.Size = new System.Drawing.Size(200, 20);
            this.p_passwordTextBox1.TabIndex = 33;
            // 
            // bookscheduleTableAdapter
            // 
            this.bookscheduleTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = hospital2.bookscheduleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // patientDataSet
            // 
            this.patientDataSet.DataSetName = "patientDataSet";
            this.patientDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.bookTableAdapter = null;
            this.tableAdapterManager.illnessTableAdapter = null;
            this.tableAdapterManager.InvoiceTableAdapter = null;
            this.tableAdapterManager.PatientTableAdapter = this.patientTableAdapter;
            this.tableAdapterManager.schedule_slotTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = hospital2.patientDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // patientTableAdapter
            // 
            this.patientTableAdapter.ClearBeforeFill = true;
            // 
            // patientBindingSource
            // 
            this.patientBindingSource.DataMember = "Patient";
            this.patientBindingSource.DataSource = this.patientDataSet;
            // 
            // confirmedTextBox
            // 
            this.confirmedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "confirmed", true));
            this.confirmedTextBox.Location = new System.Drawing.Point(102, 248);
            this.confirmedTextBox.Name = "confirmedTextBox";
            this.confirmedTextBox.Size = new System.Drawing.Size(100, 20);
            this.confirmedTextBox.TabIndex = 42;
            // 
            // notesTextBox
            // 
            this.notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "notes", true));
            this.notesTextBox.Location = new System.Drawing.Point(102, 274);
            this.notesTextBox.Name = "notesTextBox";
            this.notesTextBox.Size = new System.Drawing.Size(100, 20);
            this.notesTextBox.TabIndex = 44;
            // 
            // b_weightTextBox
            // 
            this.b_weightTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "b_weight", true));
            this.b_weightTextBox.Location = new System.Drawing.Point(102, 300);
            this.b_weightTextBox.Name = "b_weightTextBox";
            this.b_weightTextBox.Size = new System.Drawing.Size(100, 20);
            this.b_weightTextBox.TabIndex = 46;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.illnessBindingSource, "name", true));
            this.nameTextBox.Location = new System.Drawing.Point(102, 352);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 49;
            // 
            // i_descriptionTextBox
            // 
            this.i_descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.illnessBindingSource, "i_description", true));
            this.i_descriptionTextBox.Location = new System.Drawing.Point(102, 378);
            this.i_descriptionTextBox.Name = "i_descriptionTextBox";
            this.i_descriptionTextBox.Size = new System.Drawing.Size(100, 20);
            this.i_descriptionTextBox.TabIndex = 51;
            // 
            // amountTextBox
            // 
            this.amountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "amount", true));
            this.amountTextBox.Location = new System.Drawing.Point(102, 430);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(100, 20);
            this.amountTextBox.TabIndex = 54;
            // 
            // i_statusTextBox
            // 
            this.i_statusTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "i_status", true));
            this.i_statusTextBox.Location = new System.Drawing.Point(102, 456);
            this.i_statusTextBox.Name = "i_statusTextBox";
            this.i_statusTextBox.Size = new System.Drawing.Size(100, 20);
            this.i_statusTextBox.TabIndex = 56;
            // 
            // invoiceBindingSource
            // 
            this.invoiceBindingSource.DataMember = "Invoice";
            this.invoiceBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // patientSingleDataSet
            // 
            this.patientSingleDataSet.DataSetName = "patientSingleDataSet";
            this.patientSingleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // illnessBindingSource
            // 
            this.illnessBindingSource.DataMember = "illness";
            this.illnessBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // bookBindingSource
            // 
            this.bookBindingSource.DataMember = "book";
            this.bookBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // patientBindingSource1
            // 
            this.patientBindingSource1.DataMember = "Patient";
            this.patientBindingSource1.DataSource = this.patientSingleDataSet;
            // 
            // patientTableAdapter1
            // 
            this.patientTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.bookTableAdapter = null;
            this.tableAdapterManager2.illnessTableAdapter = null;
            this.tableAdapterManager2.InvoiceTableAdapter = null;
            this.tableAdapterManager2.PatientTableAdapter = this.patientTableAdapter1;
            this.tableAdapterManager2.schedule_slotTableAdapter = null;
            this.tableAdapterManager2.UpdateOrder = hospital2.patientSingleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // bookTableAdapter
            // 
            this.bookTableAdapter.ClearBeforeFill = true;
            // 
            // illnessTableAdapter
            // 
            this.illnessTableAdapter.ClearBeforeFill = true;
            // 
            // invoiceTableAdapter
            // 
            this.invoiceTableAdapter.ClearBeforeFill = true;
            // 
            // PatientReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 543);
            this.Controls.Add(amountLabel);
            this.Controls.Add(this.amountTextBox);
            this.Controls.Add(i_statusLabel);
            this.Controls.Add(this.i_statusTextBox);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(i_descriptionLabel);
            this.Controls.Add(this.i_descriptionTextBox);
            this.Controls.Add(confirmedLabel);
            this.Controls.Add(this.confirmedTextBox);
            this.Controls.Add(notesLabel);
            this.Controls.Add(this.notesTextBox);
            this.Controls.Add(b_weightLabel);
            this.Controls.Add(this.b_weightTextBox);
            this.Controls.Add(dobLabel1);
            this.Controls.Add(this.dobDateTimePicker1);
            this.Controls.Add(emailLabel1);
            this.Controls.Add(this.emailTextBox1);
            this.Controls.Add(phoneLabel1);
            this.Controls.Add(this.phoneTextBox1);
            this.Controls.Add(pfnameLabel1);
            this.Controls.Add(this.pfnameTextBox1);
            this.Controls.Add(plnameLabel1);
            this.Controls.Add(this.plnameTextBox1);
            this.Controls.Add(genderLabel1);
            this.Controls.Add(this.genderTextBox1);
            this.Controls.Add(p_passwordLabel1);
            this.Controls.Add(this.p_passwordTextBox1);
            this.Controls.Add(this.bookscheduleDataGridView);
            this.Controls.Add(this.btnReg);
            this.Controls.Add(this.monthCalendar1);
            this.Name = "PatientReg";
            this.Text = "PatientReg";
            this.Load += new System.EventHandler(this.PatientReg_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bookscheduleDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookscheduleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookscheduleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientSingleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.illnessBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private patientDataSet patientDataSet;
        private patientDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Button btnReg;
        private bookscheduleDataSet bookscheduleDataSet;
        private System.Windows.Forms.BindingSource bookscheduleBindingSource;
        private bookscheduleDataSetTableAdapters.bookscheduleTableAdapter bookscheduleTableAdapter;
        private bookscheduleDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView bookscheduleDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private patientSingleDataSet patientSingleDataSet;
        private System.Windows.Forms.BindingSource patientBindingSource1;
        private patientDataSetTableAdapters.PatientTableAdapter patientTableAdapter;
        private System.Windows.Forms.DateTimePicker dobDateTimePicker1;
        private System.Windows.Forms.TextBox emailTextBox1;
        private System.Windows.Forms.TextBox phoneTextBox1;
        private System.Windows.Forms.TextBox pfnameTextBox1;
        private System.Windows.Forms.TextBox plnameTextBox1;
        private System.Windows.Forms.TextBox genderTextBox1;
        private System.Windows.Forms.TextBox p_passwordTextBox1;
        private System.Windows.Forms.BindingSource patientBindingSource;
        private patientSingleDataSetTableAdapters.PatientTableAdapter patientTableAdapter1;
        private patientSingleDataSetTableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.BindingSource bookBindingSource;
        private patientSingleDataSetTableAdapters.bookTableAdapter bookTableAdapter;
        private System.Windows.Forms.TextBox confirmedTextBox;
        private System.Windows.Forms.TextBox notesTextBox;
        private System.Windows.Forms.TextBox b_weightTextBox;
        private System.Windows.Forms.BindingSource illnessBindingSource;
        private patientSingleDataSetTableAdapters.illnessTableAdapter illnessTableAdapter;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox i_descriptionTextBox;
        private System.Windows.Forms.BindingSource invoiceBindingSource;
        private patientSingleDataSetTableAdapters.InvoiceTableAdapter invoiceTableAdapter;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.TextBox i_statusTextBox;
    }
}