﻿namespace hospital2
{
    partial class NurseReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nfnameLabel;
            System.Windows.Forms.Label nlnameLabel;
            System.Windows.Forms.Label d_usernameLabel;
            System.Windows.Forms.Label d_passwordLabel;
            this.nurseSingleDataSet = new hospital2.nurseSingleDataSet();
            this.nurseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nurseTableAdapter = new hospital2.nurseSingleDataSetTableAdapters.NurseTableAdapter();
            this.tableAdapterManager = new hospital2.nurseSingleDataSetTableAdapters.TableAdapterManager();
            this.nfnameTextBox = new System.Windows.Forms.TextBox();
            this.nlnameTextBox = new System.Windows.Forms.TextBox();
            this.d_usernameTextBox = new System.Windows.Forms.TextBox();
            this.d_passwordTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            nfnameLabel = new System.Windows.Forms.Label();
            nlnameLabel = new System.Windows.Forms.Label();
            d_usernameLabel = new System.Windows.Forms.Label();
            d_passwordLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nurseSingleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // nfnameLabel
            // 
            nfnameLabel.AutoSize = true;
            nfnameLabel.Location = new System.Drawing.Point(58, 48);
            nfnameLabel.Name = "nfnameLabel";
            nfnameLabel.Size = new System.Drawing.Size(45, 13);
            nfnameLabel.TabIndex = 3;
            nfnameLabel.Text = "nfname:";
            // 
            // nlnameLabel
            // 
            nlnameLabel.AutoSize = true;
            nlnameLabel.Location = new System.Drawing.Point(58, 74);
            nlnameLabel.Name = "nlnameLabel";
            nlnameLabel.Size = new System.Drawing.Size(44, 13);
            nlnameLabel.TabIndex = 5;
            nlnameLabel.Text = "nlname:";
            // 
            // d_usernameLabel
            // 
            d_usernameLabel.AutoSize = true;
            d_usernameLabel.Location = new System.Drawing.Point(58, 100);
            d_usernameLabel.Name = "d_usernameLabel";
            d_usernameLabel.Size = new System.Drawing.Size(65, 13);
            d_usernameLabel.TabIndex = 7;
            d_usernameLabel.Text = "d username:";
            // 
            // d_passwordLabel
            // 
            d_passwordLabel.AutoSize = true;
            d_passwordLabel.Location = new System.Drawing.Point(58, 126);
            d_passwordLabel.Name = "d_passwordLabel";
            d_passwordLabel.Size = new System.Drawing.Size(64, 13);
            d_passwordLabel.TabIndex = 9;
            d_passwordLabel.Text = "d password:";
            // 
            // nurseSingleDataSet
            // 
            this.nurseSingleDataSet.DataSetName = "nurseSingleDataSet";
            this.nurseSingleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nurseBindingSource
            // 
            this.nurseBindingSource.DataMember = "Nurse";
            this.nurseBindingSource.DataSource = this.nurseSingleDataSet;
            // 
            // nurseTableAdapter
            // 
            this.nurseTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.NurseTableAdapter = this.nurseTableAdapter;
            this.tableAdapterManager.schedule_slotTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = hospital2.nurseSingleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nfnameTextBox
            // 
            this.nfnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "nfname", true));
            this.nfnameTextBox.Location = new System.Drawing.Point(129, 45);
            this.nfnameTextBox.Name = "nfnameTextBox";
            this.nfnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nfnameTextBox.TabIndex = 4;
            // 
            // nlnameTextBox
            // 
            this.nlnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "nlname", true));
            this.nlnameTextBox.Location = new System.Drawing.Point(129, 71);
            this.nlnameTextBox.Name = "nlnameTextBox";
            this.nlnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nlnameTextBox.TabIndex = 6;
            // 
            // d_usernameTextBox
            // 
            this.d_usernameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "d_username", true));
            this.d_usernameTextBox.Location = new System.Drawing.Point(129, 97);
            this.d_usernameTextBox.Name = "d_usernameTextBox";
            this.d_usernameTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_usernameTextBox.TabIndex = 8;
            // 
            // d_passwordTextBox
            // 
            this.d_passwordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "d_password", true));
            this.d_passwordTextBox.Location = new System.Drawing.Point(129, 123);
            this.d_passwordTextBox.Name = "d_passwordTextBox";
            this.d_passwordTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_passwordTextBox.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(154, 161);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // NurseReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 205);
            this.Controls.Add(this.button1);
            this.Controls.Add(nfnameLabel);
            this.Controls.Add(this.nfnameTextBox);
            this.Controls.Add(nlnameLabel);
            this.Controls.Add(this.nlnameTextBox);
            this.Controls.Add(d_usernameLabel);
            this.Controls.Add(this.d_usernameTextBox);
            this.Controls.Add(d_passwordLabel);
            this.Controls.Add(this.d_passwordTextBox);
            this.Name = "NurseReg";
            this.Text = "NursePatient";
            this.Load += new System.EventHandler(this.NursePatient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nurseSingleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private nurseSingleDataSet nurseSingleDataSet;
        private System.Windows.Forms.BindingSource nurseBindingSource;
        private nurseSingleDataSetTableAdapters.NurseTableAdapter nurseTableAdapter;
        private nurseSingleDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox nfnameTextBox;
        private System.Windows.Forms.TextBox nlnameTextBox;
        private System.Windows.Forms.TextBox d_usernameTextBox;
        private System.Windows.Forms.TextBox d_passwordTextBox;
        private System.Windows.Forms.Button button1;
    }
}