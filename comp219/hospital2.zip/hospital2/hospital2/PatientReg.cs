﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class PatientReg : Form
    {
        public PatientReg()
        {
            InitializeComponent();
        }
        //for data integrity check on patient database
        private DateTime date = new DateTime(1000, 1, 1);
        private string alertempty = "";
        private string alertinvalid = "";
        private bool empty = false;
        private bool invalid = false;

        //store value for book
        private List<int> slot_id_list = new List<int>();
        private int[] bookinput = new int[4];

        private void patientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.patientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.patientDataSet);

        }

        private void PatientReg_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'patientSingleDataSet.Invoice' table. You can move, or remove it, as needed.
            this.invoiceTableAdapter.Fill(this.patientSingleDataSet.Invoice);
            // TODO: This line of code loads data into the 'patientSingleDataSet.illness' table. You can move, or remove it, as needed.
            this.illnessTableAdapter.Fill(this.patientSingleDataSet.illness);
            // TODO: This line of code loads data into the 'patientSingleDataSet.book' table. You can move, or remove it, as needed.
            this.bookTableAdapter.Fill(this.patientSingleDataSet.book);
            // TODO: This line of code loads data into the 'patientSingleDataSet.Patient' table. You can move, or remove it, as needed.
            this.patientTableAdapter1.Fill(this.patientSingleDataSet.Patient);
            // TODO: This line of code loads data into the 'bookscheduleDataSet.bookschedule' table. You can move, or remove it, as needed.
            this.bookscheduleTableAdapter.Fill(this.bookscheduleDataSet.bookschedule);
            // TODO: This line of code loads data into the 'patientDataSet.Patient' table. You can move, or remove it, as needed.
            this.patientTableAdapter.Fill(this.patientDataSet.Patient);

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            date = monthCalendar1.SelectionRange.Start;
            bookscheduleTableAdapter.FillBy(bookscheduleDataSet.bookschedule, date.ToString("dd-MM-yyyy"));
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            bool addmore = true;
            empty = false;
            invalid = false;

            if (bookinput[0] == 0)
            {
                MessageBox.Show("you need to choose an appointment time");
                addmore = false;
            }
            if (addmore)
            {
                try
                {
                    if (patientSingleDataSet.Tables["Patient"].Rows.Count != 0)
                    {
                        bookinput[2] = Convert.ToInt16(patientSingleDataSet.Tables["Patient"].Rows[patientSingleDataSet.Tables["Patient"].Rows.Count - 1].ItemArray[0]) + 1;
                    }
                    else
                    {
                        bookinput[2] = 1;
                    }
                    DataRow newrow = patientSingleDataSet.Tables["patient"].NewRow();
                    newrow["p_id"] = bookinput[2];
                    newrow["dob"] = datacheck(dobDateTimePicker1.Text, "Birthday ");
                    newrow["email"] = datacheck(emailTextBox1.Text, "Email ");
                    if (patientSingleDataSet.Patient.Rows.Count != 0)
                    {
                        for (int i = 0; i < patientSingleDataSet.Patient.Rows.Count; i++)
                        {
                            if (patientDataSet.Patient.Rows[i].ItemArray[2].ToString() == emailTextBox1.Text)
                            {
                                MessageBox.Show("this mail has already been registered, try login?");
                                return;
                            }
                        }
                    }
                    newrow["phone"] = datacheck(phoneTextBox1.Text, "Phone ");
                    newrow["pfname"] = datacheck(pfnameTextBox1.Text, "First name ");
                    newrow["plname"] = datacheck(plnameTextBox1.Text, "Last name ");
                    newrow["gender"] = datacheck(genderTextBox1.Text, "Gender ");
                    newrow["p_password"] = datacheck(p_passwordTextBox1.Text, "Password");
                    patientSingleDataSet.Tables["Patient"].Rows.Add(newrow);


                }
                catch (Exception)
                {
                    if (empty)
                    {
                        MessageBox.Show(alertempty + "cannot be empty, please try again");
                        alertempty = "";
                        empty = true;
                    }
                    if (invalid)
                    {
                        MessageBox.Show(alertinvalid + "are invalid input, please try again");
                        alertinvalid = "";
                        invalid = true;
                    }
                    addmore = false;
                }
            }

            if (addmore == true)
            {
                try
                {
                    if (patientSingleDataSet.Tables["illness"].Rows.Count != 0)
                    {
                        bookinput[3] = Convert.ToInt16(patientSingleDataSet.Tables["illness"].Rows[patientSingleDataSet.Tables["illness"].Rows.Count - 1].ItemArray[0]) + 1;
                    }
                    else
                    {
                        bookinput[3] = 1;
                    }

                    DataRow newrow1 = patientSingleDataSet.Tables["illness"].NewRow();
                    newrow1["code"] = bookinput[3];
                    newrow1["name"] = nameTextBox.Text;
                    newrow1["i_description"] = i_descriptionTextBox.Text;
                    patientSingleDataSet.Tables["illness"].Rows.Add(newrow1);

                }
                catch (Exception)
                {
                    MessageBox.Show("fail to add illness, please try again");
                    addmore = false;
                    throw;
                }
            }

            if (addmore)
            {
                try
                {
                    if (patientSingleDataSet.Tables["Invoice"].Rows.Count != 0)
                    {
                        bookinput[1] = Convert.ToInt16(patientSingleDataSet.Tables["Invoice"].Rows[patientSingleDataSet.Tables["Invoice"].Rows.Count - 1].ItemArray[0]) + 1;
                    }
                    else
                    {
                        bookinput[1] = 1;
                    }

                    DataRow newrow2 = patientSingleDataSet.Invoice.NewRow();
                    newrow2["invoice_id"] = bookinput[1];
                    newrow2["amount"] = 0;
                    newrow2["i_status"] = "";
                    patientSingleDataSet.Invoice.Rows.Add(newrow2);
                }
                catch (Exception)
                {
                    MessageBox.Show("fail to add invoice, please try again");
                    addmore = false;
                    throw;
                }
            }
            if (addmore)
            {
                try
                {
                    DataRow newrow3 = patientSingleDataSet.book.NewRow();
                    newrow3["b_slot_id"] = bookinput[0];
                    newrow3["b_invoice_id"] = bookinput[1];
                    newrow3["b_patient_id"] = bookinput[2];
                    newrow3["b_illness_id"] = bookinput[3];
                    newrow3["confirmed"] = "";
                    newrow3["notes"] = notesTextBox.Text;
                    decimal num = 0;
                    try
                    {
                        if (b_weightTextBox.Text != "")
                        {
                            num = Convert.ToDecimal(b_weightTextBox.Text);
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("please type in a valid weight");
                        return;
                    }
                    if (b_weightTextBox.Text != "")
                    {
                        newrow3["b_weight"] = num;
                    }
                    else
                    {
                        newrow3["b_weight"] = DBNull.Value;
                    }
                    
                    patientSingleDataSet.book.Rows.Add(newrow3);
                }
                catch (Exception)
                {
                    if (invalid)
                    {
                        MessageBox.Show(alertinvalid + "are invalid input, please try again");
                        alertinvalid = "";
                        invalid = true;
                    }
                    MessageBox.Show("fail to add booking, please try again");
                    throw;
                }
            }
            if (addmore)
            {
                try
                {
                    patientTableAdapter1.Update(patientSingleDataSet);

                    illnessTableAdapter.Update(patientSingleDataSet);

                    invoiceTableAdapter.Update(patientSingleDataSet);

                    bookTableAdapter.Update(patientSingleDataSet);
                    MessageBox.Show("successful");
                    this.Close();
                }
                catch (Exception)
                {

                    MessageBox.Show("unsuccessful");
                }

            }
        }

             private dynamic datacheck(string input, string inputtype)
        {
            if (input == "")
            {
                alertempty += inputtype;
                empty = true;
                return DBNull.Value;
            }
            else //input is not empty
            {
                switch (inputtype)
                {
                    case "Email ":
                        try
                        {
                            var email = new System.Net.Mail.MailAddress(input);
                        }
                        catch (Exception)
                        {
                            alertinvalid += inputtype;
                            invalid = true;
                        }
                        break;
                    case "Phone ":
                        bool phone = System.Text.RegularExpressions.Regex.IsMatch(input, "[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]");
                        if (phone)
                        {
                        }
                        else
                        {
                            alertinvalid += inputtype;
                            invalid = true;
                        }
                        break;
                    case "Gender ":
                        if (input.ToLower() == "male" || input.ToLower() == "female")
                        {
                        }
                        else
                        {
                            alertinvalid += inputtype;
                            invalid = true;
                        }
                        break;

                    
                }
                return input;
            }
        }

        private void bookscheduleDataGridView_Click(object sender, EventArgs e)
        {
            try
            {
                int index = bookscheduleDataGridView.CurrentCellAddress.Y;
                //int ID = Convert.ToInt16(dataGridViewSchedule.Rows[index].Cells[0].Value);
                if (index != -1)
                {
                    DateTime comparison = new DateTime(1000, 1, 1);
                    if (date.CompareTo(comparison) != 0) //not changed values
                    {
                        if (bookscheduleDataSet.bookschedule.Rows.Count != 0)
                        {
                            for (int i = 0; i < bookscheduleDataSet.bookschedule.Rows.Count; i++)
                            {
                                if (bookscheduleDataSet.bookschedule.Rows[i].ItemArray[1].ToString() == date.ToString("d/MM/yyyy hh:mm:ss tt"))
                                {
                                    slot_id_list.Add(Convert.ToInt16(bookscheduleDataSet.bookschedule.Rows[i].ItemArray[0]));
                                }
                            }
                            bookinput[0] = slot_id_list[index];
                            slot_id_list.Clear();
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
                MessageBox.Show("fail to transfer data");
            }
        }

    }
}
