﻿namespace hospital2
{
    partial class Doctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dfnameLabel;
            System.Windows.Forms.Label dlnameLabel;
            System.Windows.Forms.Label d_usernameLabel;
            System.Windows.Forms.Label d_passwordLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label s_descriptionLabel;
            System.Windows.Forms.Label slot_dateLabel;
            System.Windows.Forms.Label startLabel;
            System.Windows.Forms.Label time_endLabel;
            System.Windows.Forms.Label label1;
            this.doctorDataSet = new hospital2.doctorDataSet();
            this.doctorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.doctorTableAdapter = new hospital2.doctorDataSetTableAdapters.DoctorTableAdapter();
            this.tableAdapterManager = new hospital2.doctorDataSetTableAdapters.TableAdapterManager();
            this.dfnameTextBox = new System.Windows.Forms.TextBox();
            this.dlnameTextBox = new System.Windows.Forms.TextBox();
            this.d_usernameTextBox = new System.Windows.Forms.TextBox();
            this.d_passwordTextBox = new System.Windows.Forms.TextBox();
            this.dataSpecDataSet = new hospital2.dataSpecDataSet();
            this.doctorSpecBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.doctorSpecTableAdapter = new hospital2.dataSpecDataSetTableAdapters.doctorSpecTableAdapter();
            this.tableAdapterManager1 = new hospital2.dataSpecDataSetTableAdapters.TableAdapterManager();
            this.doctorSpecDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.s_descriptionTextBox = new System.Windows.Forms.TextBox();
            this.txtNurseName = new System.Windows.Forms.TextBox();
            this.overViewDataSet = new hospital2.overViewDataSet();
            this.overViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.overViewTableAdapter = new hospital2.overViewDataSetTableAdapters.OverViewTableAdapter();
            this.tableAdapterManager3 = new hospital2.overViewDataSetTableAdapters.TableAdapterManager();
            this.overViewDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSaveDoc = new System.Windows.Forms.Button();
            this.btnSaveSpec = new System.Windows.Forms.Button();
            this.btnSaveNewSpec = new System.Windows.Forms.Button();
            this.btnsSaveSche = new System.Windows.Forms.Button();
            this.btnNewSch = new System.Windows.Forms.Button();
            this.schedule_slotBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schedule_slotTableAdapter = new hospital2.doctorDataSetTableAdapters.schedule_slotTableAdapter();
            this.schedule_slotDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schedule_slotBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.doctorSingleDataSet = new hospital2.doctorSingleDataSet();
            this.specialisationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.specialisationTableAdapter = new hospital2.doctorSingleDataSetTableAdapters.SpecialisationTableAdapter();
            this.tableAdapterManager2 = new hospital2.doctorSingleDataSetTableAdapters.TableAdapterManager();
            this.hasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hasTableAdapter = new hospital2.doctorSingleDataSetTableAdapters.hasTableAdapter();
            this.doctorBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.doctorTableAdapter1 = new hospital2.doctorSingleDataSetTableAdapters.DoctorTableAdapter();
            this.schedule_slotTableAdapter1 = new hospital2.doctorSingleDataSetTableAdapters.schedule_slotTableAdapter();
            this.slot_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.startTextBox = new System.Windows.Forms.TextBox();
            this.time_endTextBox = new System.Windows.Forms.TextBox();
            dfnameLabel = new System.Windows.Forms.Label();
            dlnameLabel = new System.Windows.Forms.Label();
            d_usernameLabel = new System.Windows.Forms.Label();
            d_passwordLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            s_descriptionLabel = new System.Windows.Forms.Label();
            slot_dateLabel = new System.Windows.Forms.Label();
            startLabel = new System.Windows.Forms.Label();
            time_endLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.doctorDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSpecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSingleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.specialisationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // doctorDataSet
            // 
            this.doctorDataSet.DataSetName = "doctorDataSet";
            this.doctorDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // doctorBindingSource
            // 
            this.doctorBindingSource.DataMember = "Doctor";
            this.doctorBindingSource.DataSource = this.doctorDataSet;
            // 
            // doctorTableAdapter
            // 
            this.doctorTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DoctorTableAdapter = this.doctorTableAdapter;
            this.tableAdapterManager.NurseTableAdapter = null;
            this.tableAdapterManager.schedule_slotTableAdapter = this.schedule_slotTableAdapter;
            this.tableAdapterManager.UpdateOrder = hospital2.doctorDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dfnameLabel
            // 
            dfnameLabel.AutoSize = true;
            dfnameLabel.Location = new System.Drawing.Point(27, 99);
            dfnameLabel.Name = "dfnameLabel";
            dfnameLabel.Size = new System.Drawing.Size(45, 13);
            dfnameLabel.TabIndex = 3;
            dfnameLabel.Text = "dfname:";
            // 
            // dfnameTextBox
            // 
            this.dfnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "dfname", true));
            this.dfnameTextBox.Location = new System.Drawing.Point(98, 96);
            this.dfnameTextBox.Name = "dfnameTextBox";
            this.dfnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.dfnameTextBox.TabIndex = 4;
            // 
            // dlnameLabel
            // 
            dlnameLabel.AutoSize = true;
            dlnameLabel.Location = new System.Drawing.Point(27, 125);
            dlnameLabel.Name = "dlnameLabel";
            dlnameLabel.Size = new System.Drawing.Size(44, 13);
            dlnameLabel.TabIndex = 5;
            dlnameLabel.Text = "dlname:";
            // 
            // dlnameTextBox
            // 
            this.dlnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "dlname", true));
            this.dlnameTextBox.Location = new System.Drawing.Point(98, 122);
            this.dlnameTextBox.Name = "dlnameTextBox";
            this.dlnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.dlnameTextBox.TabIndex = 6;
            // 
            // d_usernameLabel
            // 
            d_usernameLabel.AutoSize = true;
            d_usernameLabel.Location = new System.Drawing.Point(27, 151);
            d_usernameLabel.Name = "d_usernameLabel";
            d_usernameLabel.Size = new System.Drawing.Size(65, 13);
            d_usernameLabel.TabIndex = 7;
            d_usernameLabel.Text = "d username:";
            // 
            // d_usernameTextBox
            // 
            this.d_usernameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "d_username", true));
            this.d_usernameTextBox.Location = new System.Drawing.Point(98, 148);
            this.d_usernameTextBox.Name = "d_usernameTextBox";
            this.d_usernameTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_usernameTextBox.TabIndex = 8;
            // 
            // d_passwordLabel
            // 
            d_passwordLabel.AutoSize = true;
            d_passwordLabel.Location = new System.Drawing.Point(27, 177);
            d_passwordLabel.Name = "d_passwordLabel";
            d_passwordLabel.Size = new System.Drawing.Size(64, 13);
            d_passwordLabel.TabIndex = 9;
            d_passwordLabel.Text = "d password:";
            // 
            // d_passwordTextBox
            // 
            this.d_passwordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "d_password", true));
            this.d_passwordTextBox.Location = new System.Drawing.Point(98, 174);
            this.d_passwordTextBox.Name = "d_passwordTextBox";
            this.d_passwordTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_passwordTextBox.TabIndex = 10;
            // 
            // dataSpecDataSet
            // 
            this.dataSpecDataSet.DataSetName = "dataSpecDataSet";
            this.dataSpecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // doctorSpecBindingSource
            // 
            this.doctorSpecBindingSource.DataMember = "doctorSpec";
            this.doctorSpecBindingSource.DataSource = this.dataSpecDataSet;
            // 
            // doctorSpecTableAdapter
            // 
            this.doctorSpecTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = hospital2.dataSpecDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // doctorSpecDataGridView
            // 
            this.doctorSpecDataGridView.AllowUserToAddRows = false;
            this.doctorSpecDataGridView.AllowUserToDeleteRows = false;
            this.doctorSpecDataGridView.AutoGenerateColumns = false;
            this.doctorSpecDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.doctorSpecDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn4});
            this.doctorSpecDataGridView.DataSource = this.doctorSpecBindingSource;
            this.doctorSpecDataGridView.Location = new System.Drawing.Point(232, 45);
            this.doctorSpecDataGridView.Name = "doctorSpecDataGridView";
            this.doctorSpecDataGridView.ReadOnly = true;
            this.doctorSpecDataGridView.Size = new System.Drawing.Size(195, 200);
            this.doctorSpecDataGridView.TabIndex = 10;
            this.doctorSpecDataGridView.Click += new System.EventHandler(this.doctorSpecDataGridView_Click);
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn5.HeaderText = "name";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "spec_doctor_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "spec_doctor_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "specid";
            this.dataGridViewTextBoxColumn4.HeaderText = "specid";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(242, 290);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(36, 13);
            nameLabel.TabIndex = 12;
            nameLabel.Text = "name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.specialisationBindingSource, "name", true));
            this.nameTextBox.Location = new System.Drawing.Point(317, 287);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 13;
            // 
            // s_descriptionLabel
            // 
            s_descriptionLabel.AutoSize = true;
            s_descriptionLabel.Location = new System.Drawing.Point(242, 316);
            s_descriptionLabel.Name = "s_descriptionLabel";
            s_descriptionLabel.Size = new System.Drawing.Size(69, 13);
            s_descriptionLabel.TabIndex = 14;
            s_descriptionLabel.Text = "s description:";
            // 
            // s_descriptionTextBox
            // 
            this.s_descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.specialisationBindingSource, "s_description", true));
            this.s_descriptionTextBox.Location = new System.Drawing.Point(317, 313);
            this.s_descriptionTextBox.Name = "s_descriptionTextBox";
            this.s_descriptionTextBox.Size = new System.Drawing.Size(100, 20);
            this.s_descriptionTextBox.TabIndex = 15;
            // 
            // slot_dateLabel
            // 
            slot_dateLabel.AutoSize = true;
            slot_dateLabel.Location = new System.Drawing.Point(444, 294);
            slot_dateLabel.Name = "slot_dateLabel";
            slot_dateLabel.Size = new System.Drawing.Size(50, 13);
            slot_dateLabel.TabIndex = 21;
            slot_dateLabel.Text = "slot date:";
            // 
            // startLabel
            // 
            startLabel.AutoSize = true;
            startLabel.Location = new System.Drawing.Point(444, 319);
            startLabel.Name = "startLabel";
            startLabel.Size = new System.Drawing.Size(30, 13);
            startLabel.TabIndex = 23;
            startLabel.Text = "start:";
            // 
            // time_endLabel
            // 
            time_endLabel.AutoSize = true;
            time_endLabel.Location = new System.Drawing.Point(444, 345);
            time_endLabel.Name = "time_endLabel";
            time_endLabel.Size = new System.Drawing.Size(50, 13);
            time_endLabel.TabIndex = 25;
            time_endLabel.Text = "time end:";
            // 
            // txtNurseName
            // 
            this.txtNurseName.Location = new System.Drawing.Point(674, 372);
            this.txtNurseName.Name = "txtNurseName";
            this.txtNurseName.Size = new System.Drawing.Size(200, 20);
            this.txtNurseName.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(444, 379);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(35, 13);
            label1.TabIndex = 28;
            label1.Text = "Nurse";
            // 
            // overViewDataSet
            // 
            this.overViewDataSet.DataSetName = "overViewDataSet";
            this.overViewDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // overViewBindingSource
            // 
            this.overViewBindingSource.DataMember = "OverView";
            this.overViewBindingSource.DataSource = this.overViewDataSet;
            // 
            // overViewTableAdapter
            // 
            this.overViewTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager3
            // 
            this.tableAdapterManager3.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager3.Connection = null;
            this.tableAdapterManager3.UpdateOrder = hospital2.overViewDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // overViewDataGridView
            // 
            this.overViewDataGridView.AllowUserToAddRows = false;
            this.overViewDataGridView.AllowUserToDeleteRows = false;
            this.overViewDataGridView.AutoGenerateColumns = false;
            this.overViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.overViewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn30});
            this.overViewDataGridView.DataSource = this.overViewBindingSource;
            this.overViewDataGridView.Location = new System.Drawing.Point(12, 442);
            this.overViewDataGridView.Name = "overViewDataGridView";
            this.overViewDataGridView.ReadOnly = true;
            this.overViewDataGridView.Size = new System.Drawing.Size(888, 220);
            this.overViewDataGridView.TabIndex = 28;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Patient";
            this.dataGridViewTextBoxColumn16.HeaderText = "Patient";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn18.HeaderText = "Date";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "StartTime";
            this.dataGridViewTextBoxColumn19.HeaderText = "StartTime";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "EndTime";
            this.dataGridViewTextBoxColumn20.HeaderText = "EndTime";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Illness";
            this.dataGridViewTextBoxColumn30.HeaderText = "Illness";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            // 
            // btnSaveDoc
            // 
            this.btnSaveDoc.Location = new System.Drawing.Point(123, 222);
            this.btnSaveDoc.Name = "btnSaveDoc";
            this.btnSaveDoc.Size = new System.Drawing.Size(75, 23);
            this.btnSaveDoc.TabIndex = 29;
            this.btnSaveDoc.Text = "Save Doctor";
            this.btnSaveDoc.UseVisualStyleBackColor = true;
            this.btnSaveDoc.Click += new System.EventHandler(this.btnSaveDoc_Click);
            // 
            // btnSaveSpec
            // 
            this.btnSaveSpec.Location = new System.Drawing.Point(281, 346);
            this.btnSaveSpec.Name = "btnSaveSpec";
            this.btnSaveSpec.Size = new System.Drawing.Size(136, 23);
            this.btnSaveSpec.TabIndex = 30;
            this.btnSaveSpec.Text = "Save Specilisation";
            this.btnSaveSpec.UseVisualStyleBackColor = true;
            // 
            // btnSaveNewSpec
            // 
            this.btnSaveNewSpec.Location = new System.Drawing.Point(281, 390);
            this.btnSaveNewSpec.Name = "btnSaveNewSpec";
            this.btnSaveNewSpec.Size = new System.Drawing.Size(136, 23);
            this.btnSaveNewSpec.TabIndex = 31;
            this.btnSaveNewSpec.Text = "Make New Sepcilisation";
            this.btnSaveNewSpec.UseVisualStyleBackColor = true;
            this.btnSaveNewSpec.Click += new System.EventHandler(this.btnSaveNewSpec_Click);
            // 
            // btnsSaveSche
            // 
            this.btnsSaveSche.Location = new System.Drawing.Point(799, 398);
            this.btnsSaveSche.Name = "btnsSaveSche";
            this.btnsSaveSche.Size = new System.Drawing.Size(75, 23);
            this.btnsSaveSche.TabIndex = 32;
            this.btnsSaveSche.Text = "Save Schedule";
            this.btnsSaveSche.UseVisualStyleBackColor = true;
            this.btnsSaveSche.Click += new System.EventHandler(this.btnsSaveSche_Click);
            // 
            // btnNewSch
            // 
            this.btnNewSch.Location = new System.Drawing.Point(704, 398);
            this.btnNewSch.Name = "btnNewSch";
            this.btnNewSch.Size = new System.Drawing.Size(75, 23);
            this.btnNewSch.TabIndex = 33;
            this.btnNewSch.Text = "New Schedule";
            this.btnNewSch.UseVisualStyleBackColor = true;
            this.btnNewSch.Click += new System.EventHandler(this.btnNewSch_Click);
            // 
            // schedule_slotBindingSource
            // 
            this.schedule_slotBindingSource.DataMember = "schedule_slot";
            this.schedule_slotBindingSource.DataSource = this.doctorDataSet;
            // 
            // schedule_slotTableAdapter
            // 
            this.schedule_slotTableAdapter.ClearBeforeFill = true;
            // 
            // schedule_slotDataGridView
            // 
            this.schedule_slotDataGridView.AllowUserToAddRows = false;
            this.schedule_slotDataGridView.AllowUserToDeleteRows = false;
            this.schedule_slotDataGridView.AutoGenerateColumns = false;
            this.schedule_slotDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.schedule_slotDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.schedule_slotDataGridView.DataSource = this.schedule_slotBindingSource;
            this.schedule_slotDataGridView.Location = new System.Drawing.Point(470, 45);
            this.schedule_slotDataGridView.Name = "schedule_slotDataGridView";
            this.schedule_slotDataGridView.ReadOnly = true;
            this.schedule_slotDataGridView.Size = new System.Drawing.Size(404, 200);
            this.schedule_slotDataGridView.TabIndex = 33;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "slot_id";
            this.dataGridViewTextBoxColumn2.HeaderText = "slot_id";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "slot";
            this.dataGridViewTextBoxColumn3.HeaderText = "slot";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "slot2";
            this.dataGridViewTextBoxColumn6.HeaderText = "slot2";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "slot_date";
            this.dataGridViewTextBoxColumn7.HeaderText = "slot_date";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "start";
            this.dataGridViewTextBoxColumn8.HeaderText = "start";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "time_end";
            this.dataGridViewTextBoxColumn9.HeaderText = "time_end";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "s_doctor_id";
            this.dataGridViewTextBoxColumn10.HeaderText = "s_doctor_id";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "s_nurse_id";
            this.dataGridViewTextBoxColumn11.HeaderText = "s_nurse_id";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // schedule_slotBindingSource1
            // 
            this.schedule_slotBindingSource1.DataMember = "schedule_slot";
            this.schedule_slotBindingSource1.DataSource = this.doctorSingleDataSet;
            // 
            // doctorSingleDataSet
            // 
            this.doctorSingleDataSet.DataSetName = "doctorSingleDataSet";
            this.doctorSingleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // specialisationBindingSource
            // 
            this.specialisationBindingSource.DataMember = "Specialisation";
            this.specialisationBindingSource.DataSource = this.doctorSingleDataSet;
            // 
            // specialisationTableAdapter
            // 
            this.specialisationTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.DoctorTableAdapter = null;
            this.tableAdapterManager2.hasTableAdapter = null;
            this.tableAdapterManager2.schedule_slotTableAdapter = null;
            this.tableAdapterManager2.SpecialisationTableAdapter = this.specialisationTableAdapter;
            this.tableAdapterManager2.UpdateOrder = hospital2.doctorSingleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // hasBindingSource
            // 
            this.hasBindingSource.DataMember = "has";
            this.hasBindingSource.DataSource = this.doctorSingleDataSet;
            // 
            // hasTableAdapter
            // 
            this.hasTableAdapter.ClearBeforeFill = true;
            // 
            // doctorBindingSource1
            // 
            this.doctorBindingSource1.DataMember = "Doctor";
            this.doctorBindingSource1.DataSource = this.doctorSingleDataSet;
            // 
            // doctorTableAdapter1
            // 
            this.doctorTableAdapter1.ClearBeforeFill = true;
            // 
            // schedule_slotTableAdapter1
            // 
            this.schedule_slotTableAdapter1.ClearBeforeFill = true;
            // 
            // slot_dateDateTimePicker
            // 
            this.slot_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.schedule_slotBindingSource1, "slot_date", true));
            this.slot_dateDateTimePicker.Location = new System.Drawing.Point(674, 294);
            this.slot_dateDateTimePicker.Name = "slot_dateDateTimePicker";
            this.slot_dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.slot_dateDateTimePicker.TabIndex = 40;
            // 
            // startTextBox
            // 
            this.startTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.schedule_slotBindingSource1, "start", true));
            this.startTextBox.Location = new System.Drawing.Point(674, 320);
            this.startTextBox.Name = "startTextBox";
            this.startTextBox.Size = new System.Drawing.Size(200, 20);
            this.startTextBox.TabIndex = 42;
            // 
            // time_endTextBox
            // 
            this.time_endTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.schedule_slotBindingSource1, "time_end", true));
            this.time_endTextBox.Location = new System.Drawing.Point(674, 346);
            this.time_endTextBox.Name = "time_endTextBox";
            this.time_endTextBox.Size = new System.Drawing.Size(200, 20);
            this.time_endTextBox.TabIndex = 44;
            // 
            // Doctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 868);
            this.Controls.Add(this.slot_dateDateTimePicker);
            this.Controls.Add(this.startTextBox);
            this.Controls.Add(this.time_endTextBox);
            this.Controls.Add(this.schedule_slotDataGridView);
            this.Controls.Add(this.btnNewSch);
            this.Controls.Add(this.btnsSaveSche);
            this.Controls.Add(this.btnSaveNewSpec);
            this.Controls.Add(this.btnSaveSpec);
            this.Controls.Add(this.btnSaveDoc);
            this.Controls.Add(this.overViewDataGridView);
            this.Controls.Add(label1);
            this.Controls.Add(this.txtNurseName);
            this.Controls.Add(slot_dateLabel);
            this.Controls.Add(startLabel);
            this.Controls.Add(time_endLabel);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(s_descriptionLabel);
            this.Controls.Add(this.s_descriptionTextBox);
            this.Controls.Add(this.doctorSpecDataGridView);
            this.Controls.Add(dfnameLabel);
            this.Controls.Add(this.dfnameTextBox);
            this.Controls.Add(dlnameLabel);
            this.Controls.Add(this.dlnameTextBox);
            this.Controls.Add(d_usernameLabel);
            this.Controls.Add(this.d_usernameTextBox);
            this.Controls.Add(d_passwordLabel);
            this.Controls.Add(this.d_passwordTextBox);
            this.Name = "Doctor";
            this.Text = "Doctor";
            this.Load += new System.EventHandler(this.Doctor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.doctorDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSpecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSingleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.specialisationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private doctorDataSet doctorDataSet;
        private System.Windows.Forms.BindingSource doctorBindingSource;
        private doctorDataSetTableAdapters.DoctorTableAdapter doctorTableAdapter;
        private doctorDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox dfnameTextBox;
        private System.Windows.Forms.TextBox dlnameTextBox;
        private System.Windows.Forms.TextBox d_usernameTextBox;
        private System.Windows.Forms.TextBox d_passwordTextBox;
        private dataSpecDataSet dataSpecDataSet;
        private System.Windows.Forms.BindingSource doctorSpecBindingSource;
        private dataSpecDataSetTableAdapters.doctorSpecTableAdapter doctorSpecTableAdapter;
        private dataSpecDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView doctorSpecDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private doctorSingleDataSet doctorSingleDataSet;
        private System.Windows.Forms.BindingSource specialisationBindingSource;
        private doctorSingleDataSetTableAdapters.SpecialisationTableAdapter specialisationTableAdapter;
        private doctorSingleDataSetTableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox s_descriptionTextBox;
        private System.Windows.Forms.TextBox txtNurseName;
        private overViewDataSet overViewDataSet;
        private System.Windows.Forms.BindingSource overViewBindingSource;
        private overViewDataSetTableAdapters.OverViewTableAdapter overViewTableAdapter;
        private overViewDataSetTableAdapters.TableAdapterManager tableAdapterManager3;
        private System.Windows.Forms.DataGridView overViewDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.Button btnSaveDoc;
        private System.Windows.Forms.Button btnSaveSpec;
        private System.Windows.Forms.Button btnSaveNewSpec;
        private System.Windows.Forms.Button btnsSaveSche;
        private System.Windows.Forms.Button btnNewSch;
        private System.Windows.Forms.BindingSource hasBindingSource;
        private doctorSingleDataSetTableAdapters.hasTableAdapter hasTableAdapter;
        private System.Windows.Forms.BindingSource doctorBindingSource1;
        private doctorSingleDataSetTableAdapters.DoctorTableAdapter doctorTableAdapter1;
        private doctorDataSetTableAdapters.schedule_slotTableAdapter schedule_slotTableAdapter;
        private System.Windows.Forms.BindingSource schedule_slotBindingSource;
        private System.Windows.Forms.DataGridView schedule_slotDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.BindingSource schedule_slotBindingSource1;
        private doctorSingleDataSetTableAdapters.schedule_slotTableAdapter schedule_slotTableAdapter1;
        private System.Windows.Forms.DateTimePicker slot_dateDateTimePicker;
        private System.Windows.Forms.TextBox startTextBox;
        private System.Windows.Forms.TextBox time_endTextBox;
    }
}