﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class Patient : Form
    {
        public Patient()
        {
            InitializeComponent();
        }
        //for data integrity check on patient database
        private DateTime date = new DateTime(1000, 1, 1);
        private string alertempty = "";
        private string alertinvalid = "";
        private bool empty = false;
        private bool invalid = false;

        //store value for book
        private List<int> slot_id_list = new List<int>();
        private int[] bookinput = new int[4];

        public int patientID = 0;
        public int illID = 0;
        public int InvoID = 0;
        public int slotID = 0;
        private void Patient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'overViewDataSet.OverView' table. You can move, or remove it, as needed.
            this.overViewTableAdapter.FillByp(this.overViewDataSet.OverView,patientID);
            // TODO: This line of code loads data into the 'patientSingleDataSet.book' table. You can move, or remove it, as needed.
            this.bookTableAdapter.FillBy(this.patientSingleDataSet.book,patientID);
            // TODO: This line of code loads data into the 'patientSingleDataSet.illness' table. You can move, or remove it, as needed.
            this.illnessTableAdapter.FillBy(this.patientSingleDataSet.illness,illID);
            // TODO: This line of code loads data into the 'patientSingleDataSet.Invoice' table. You can move, or remove it, as needed.
            this.invoiceTableAdapter.FillBy(this.patientSingleDataSet.Invoice,InvoID);
            // TODO: This line of code loads data into the 'patientSingleDataSet.Patient' table. You can move, or remove it, as needed.
            this.patientTableAdapter.FillBy(this.patientSingleDataSet.Patient,patientID);

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            this.Validate();
            try
            {
                datacheck(dobDateTimePicker.Text, "Birthday ");
                datacheck(dobDateTimePicker.Text, "Phone ");
                datacheck(dobDateTimePicker.Text, "Gender ");
                patientBindingSource.EndEdit();
                patientTableAdapter.Update(patientSingleDataSet.Patient);

            }
            catch (Exception ex)
            {

                if (empty)
                {
                    MessageBox.Show(alertempty + "cannot be empty, please try again");
                    alertempty = "";
                    empty = true;
                }
                if (invalid)
                {
                    MessageBox.Show(alertinvalid + "are invalid input, please try again");
                    alertinvalid = "";
                    invalid = true;
                }
            }
            try
            {
                illnessBindingSource.EndEdit();
                illnessTableAdapter.Update(patientSingleDataSet.illness);
            }
            catch (Exception)
            {

                MessageBox.Show("fail to add illness, please try again");
            }
            try
            {
                invoiceBindingSource.EndEdit();
                invoiceTableAdapter.Update(patientSingleDataSet.Invoice);
            }
            catch (Exception)
            {

                MessageBox.Show("fail to add invoice, please try again");
            }
            //try
            //{
            //    bookBindingSource.EndEdit();
            //    bookTableAdapter1.Update(patientSingleDataSet.book);
            //}
            //catch (Exception)
            //{

            //    throw;
            //}
            this.patientTableAdapter.FillBy(this.patientSingleDataSet.Patient, patientID);

            this.illnessTableAdapter.FillBy(this.patientSingleDataSet.illness, illID);

            this.invoiceTableAdapter.FillBy(this.patientSingleDataSet.Invoice, InvoID);

            this.bookTableAdapter.Fill(this.patientSingleDataSet.book);
            overViewTableAdapter.Fill(overViewDataSet.OverView);
        }

        private void datacheck(string input, string inputtype)
        {
            if (input == "")
            {
                alertempty += inputtype;
                empty = true;
            }
            else //input is not empty
            {
                switch (inputtype)
                {
                    case "Email ":
                        try
                        {
                            var email = new System.Net.Mail.MailAddress(input);
                        }
                        catch (Exception)
                        {
                            alertinvalid += inputtype;
                            invalid = true;
                        }
                        break;
                    case "Phone ":
                        bool phone = System.Text.RegularExpressions.Regex.IsMatch(input, "[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]");
                        if (phone)
                        {
                        }
                        else
                        {
                            alertinvalid += inputtype;
                            invalid = true;
                        }
                        break;
                    case "Gender ":
                        if (input.ToLower() == "male" || input.ToLower() == "female")
                        {
                        }
                        else
                        {
                            alertinvalid += inputtype;
                            invalid = true;
                        }
                        break;


                }
            }
        }

        private dynamic dbnull(string input)
        {
            if (input == "")
            {
                return DBNull.Value;
            }
            else
            {
                return input;
            }
        }

        private void patientBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.patientBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.patientSingleDataSet);

        }
    }
}
