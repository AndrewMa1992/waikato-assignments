﻿namespace hospital2
{
    partial class Nurse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nfnameLabel;
            System.Windows.Forms.Label nlnameLabel;
            System.Windows.Forms.Label d_usernameLabel;
            System.Windows.Forms.Label d_passwordLabel;
            System.Windows.Forms.Label slot_dateLabel;
            System.Windows.Forms.Label startLabel;
            System.Windows.Forms.Label time_endLabel;
            System.Windows.Forms.Label label1;
            this.overViewDataGridView = new System.Windows.Forms.DataGridView();
            this.btnSaveSch = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tableAdapterManager = new hospital2.nurseSingleDataSetTableAdapters.TableAdapterManager();
            this.nurseSingleDataSet = new hospital2.nurseSingleDataSet();
            this.nurseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nurseTableAdapter = new hospital2.nurseSingleDataSetTableAdapters.NurseTableAdapter();
            this.nfnameTextBox = new System.Windows.Forms.TextBox();
            this.nlnameTextBox = new System.Windows.Forms.TextBox();
            this.d_usernameTextBox = new System.Windows.Forms.TextBox();
            this.d_passwordTextBox = new System.Windows.Forms.TextBox();
            this.schedule_slotDataGridView = new System.Windows.Forms.DataGridView();
            this.schedule_slotBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.schedule_slotTableAdapter1 = new hospital2.nurseSingleDataSetTableAdapters.schedule_slotTableAdapter();
            this.slot_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.startTextBox = new System.Windows.Forms.TextBox();
            this.time_endTextBox = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schedule_slotBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nurseDataSet = new hospital2.nurseDataSet();
            this.tableAdapterManager2 = new hospital2.nurseDataSetTableAdapters.TableAdapterManager();
            this.schedule_slotTableAdapter = new hospital2.nurseDataSetTableAdapters.schedule_slotTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.overViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.overViewDataSet = new hospital2.overViewDataSet();
            this.overViewTableAdapter = new hospital2.overViewDataSetTableAdapters.OverViewTableAdapter();
            this.tableAdapterManager1 = new hospital2.overViewDataSetTableAdapters.TableAdapterManager();
            nfnameLabel = new System.Windows.Forms.Label();
            nlnameLabel = new System.Windows.Forms.Label();
            d_usernameLabel = new System.Windows.Forms.Label();
            d_passwordLabel = new System.Windows.Forms.Label();
            slot_dateLabel = new System.Windows.Forms.Label();
            startLabel = new System.Windows.Forms.Label();
            time_endLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseSingleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // nfnameLabel
            // 
            nfnameLabel.AutoSize = true;
            nfnameLabel.Location = new System.Drawing.Point(41, 36);
            nfnameLabel.Name = "nfnameLabel";
            nfnameLabel.Size = new System.Drawing.Size(45, 13);
            nfnameLabel.TabIndex = 3;
            nfnameLabel.Text = "nfname:";
            // 
            // nlnameLabel
            // 
            nlnameLabel.AutoSize = true;
            nlnameLabel.Location = new System.Drawing.Point(41, 62);
            nlnameLabel.Name = "nlnameLabel";
            nlnameLabel.Size = new System.Drawing.Size(44, 13);
            nlnameLabel.TabIndex = 5;
            nlnameLabel.Text = "nlname:";
            // 
            // d_usernameLabel
            // 
            d_usernameLabel.AutoSize = true;
            d_usernameLabel.Location = new System.Drawing.Point(41, 88);
            d_usernameLabel.Name = "d_usernameLabel";
            d_usernameLabel.Size = new System.Drawing.Size(65, 13);
            d_usernameLabel.TabIndex = 7;
            d_usernameLabel.Text = "d username:";
            // 
            // d_passwordLabel
            // 
            d_passwordLabel.AutoSize = true;
            d_passwordLabel.Location = new System.Drawing.Point(41, 114);
            d_passwordLabel.Name = "d_passwordLabel";
            d_passwordLabel.Size = new System.Drawing.Size(64, 13);
            d_passwordLabel.TabIndex = 9;
            d_passwordLabel.Text = "d password:";
            // 
            // slot_dateLabel
            // 
            slot_dateLabel.AutoSize = true;
            slot_dateLabel.Location = new System.Drawing.Point(609, 268);
            slot_dateLabel.Name = "slot_dateLabel";
            slot_dateLabel.Size = new System.Drawing.Size(50, 13);
            slot_dateLabel.TabIndex = 18;
            slot_dateLabel.Text = "slot date:";
            // 
            // startLabel
            // 
            startLabel.AutoSize = true;
            startLabel.Location = new System.Drawing.Point(609, 293);
            startLabel.Name = "startLabel";
            startLabel.Size = new System.Drawing.Size(30, 13);
            startLabel.TabIndex = 20;
            startLabel.Text = "start:";
            // 
            // time_endLabel
            // 
            time_endLabel.AutoSize = true;
            time_endLabel.Location = new System.Drawing.Point(609, 319);
            time_endLabel.Name = "time_endLabel";
            time_endLabel.Size = new System.Drawing.Size(50, 13);
            time_endLabel.TabIndex = 22;
            time_endLabel.Text = "time end:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(609, 346);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(39, 13);
            label1.TabIndex = 24;
            label1.Text = "Doctor";
            // 
            // overViewDataGridView
            // 
            this.overViewDataGridView.AllowUserToAddRows = false;
            this.overViewDataGridView.AllowUserToDeleteRows = false;
            this.overViewDataGridView.AutoGenerateColumns = false;
            this.overViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.overViewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20});
            this.overViewDataGridView.DataSource = this.overViewBindingSource;
            this.overViewDataGridView.Location = new System.Drawing.Point(44, 172);
            this.overViewDataGridView.Name = "overViewDataGridView";
            this.overViewDataGridView.ReadOnly = true;
            this.overViewDataGridView.Size = new System.Drawing.Size(526, 220);
            this.overViewDataGridView.TabIndex = 10;
            // 
            // btnSaveSch
            // 
            this.btnSaveSch.Location = new System.Drawing.Point(1019, 395);
            this.btnSaveSch.Name = "btnSaveSch";
            this.btnSaveSch.Size = new System.Drawing.Size(140, 23);
            this.btnSaveSch.TabIndex = 11;
            this.btnSaveSch.Text = "Save Schedule";
            this.btnSaveSch.UseVisualStyleBackColor = true;
            this.btnSaveSch.Click += new System.EventHandler(this.W);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(612, 395);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Add New Schedule";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(674, 346);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 20);
            this.textBox1.TabIndex = 25;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.NurseTableAdapter = null;
            this.tableAdapterManager.schedule_slotTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = hospital2.nurseSingleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nurseSingleDataSet
            // 
            this.nurseSingleDataSet.DataSetName = "nurseSingleDataSet";
            this.nurseSingleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nurseBindingSource
            // 
            this.nurseBindingSource.DataMember = "Nurse";
            this.nurseBindingSource.DataSource = this.nurseSingleDataSet;
            // 
            // nurseTableAdapter
            // 
            this.nurseTableAdapter.ClearBeforeFill = true;
            // 
            // nfnameTextBox
            // 
            this.nfnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "nfname", true));
            this.nfnameTextBox.Location = new System.Drawing.Point(133, 36);
            this.nfnameTextBox.Name = "nfnameTextBox";
            this.nfnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nfnameTextBox.TabIndex = 39;
            // 
            // nlnameTextBox
            // 
            this.nlnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "nlname", true));
            this.nlnameTextBox.Location = new System.Drawing.Point(133, 62);
            this.nlnameTextBox.Name = "nlnameTextBox";
            this.nlnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nlnameTextBox.TabIndex = 41;
            // 
            // d_usernameTextBox
            // 
            this.d_usernameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "d_username", true));
            this.d_usernameTextBox.Location = new System.Drawing.Point(133, 88);
            this.d_usernameTextBox.Name = "d_usernameTextBox";
            this.d_usernameTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_usernameTextBox.TabIndex = 43;
            // 
            // d_passwordTextBox
            // 
            this.d_passwordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nurseBindingSource, "d_password", true));
            this.d_passwordTextBox.Location = new System.Drawing.Point(133, 114);
            this.d_passwordTextBox.Name = "d_passwordTextBox";
            this.d_passwordTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_passwordTextBox.TabIndex = 45;
            // 
            // schedule_slotDataGridView
            // 
            this.schedule_slotDataGridView.AllowUserToAddRows = false;
            this.schedule_slotDataGridView.AllowUserToDeleteRows = false;
            this.schedule_slotDataGridView.AutoGenerateColumns = false;
            this.schedule_slotDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.schedule_slotDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28});
            this.schedule_slotDataGridView.DataSource = this.schedule_slotBindingSource;
            this.schedule_slotDataGridView.Location = new System.Drawing.Point(592, 12);
            this.schedule_slotDataGridView.Name = "schedule_slotDataGridView";
            this.schedule_slotDataGridView.ReadOnly = true;
            this.schedule_slotDataGridView.Size = new System.Drawing.Size(567, 220);
            this.schedule_slotDataGridView.TabIndex = 45;
            // 
            // schedule_slotBindingSource1
            // 
            this.schedule_slotBindingSource1.DataMember = "schedule_slot";
            this.schedule_slotBindingSource1.DataSource = this.nurseSingleDataSet;
            // 
            // schedule_slotTableAdapter1
            // 
            this.schedule_slotTableAdapter1.ClearBeforeFill = true;
            // 
            // slot_dateDateTimePicker
            // 
            this.slot_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.schedule_slotBindingSource1, "slot_date", true));
            this.slot_dateDateTimePicker.Location = new System.Drawing.Point(674, 268);
            this.slot_dateDateTimePicker.Name = "slot_dateDateTimePicker";
            this.slot_dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.slot_dateDateTimePicker.TabIndex = 52;
            // 
            // startTextBox
            // 
            this.startTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.schedule_slotBindingSource1, "start", true));
            this.startTextBox.Location = new System.Drawing.Point(674, 294);
            this.startTextBox.Name = "startTextBox";
            this.startTextBox.Size = new System.Drawing.Size(200, 20);
            this.startTextBox.TabIndex = 54;
            // 
            // time_endTextBox
            // 
            this.time_endTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.schedule_slotBindingSource1, "time_end", true));
            this.time_endTextBox.Location = new System.Drawing.Point(674, 320);
            this.time_endTextBox.Name = "time_endTextBox";
            this.time_endTextBox.Size = new System.Drawing.Size(200, 20);
            this.time_endTextBox.TabIndex = 56;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "slot_id";
            this.dataGridViewTextBoxColumn21.HeaderText = "slot_id";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "slot";
            this.dataGridViewTextBoxColumn22.HeaderText = "slot";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "slot2";
            this.dataGridViewTextBoxColumn23.HeaderText = "slot2";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "slot_date";
            this.dataGridViewTextBoxColumn24.HeaderText = "slot_date";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "start";
            this.dataGridViewTextBoxColumn25.HeaderText = "start";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "time_end";
            this.dataGridViewTextBoxColumn26.HeaderText = "time_end";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "s_doctor_id";
            this.dataGridViewTextBoxColumn27.HeaderText = "s_doctor_id";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "s_nurse_id";
            this.dataGridViewTextBoxColumn28.HeaderText = "s_nurse_id";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            // 
            // schedule_slotBindingSource
            // 
            this.schedule_slotBindingSource.DataMember = "schedule_slot";
            this.schedule_slotBindingSource.DataSource = this.nurseDataSet;
            // 
            // nurseDataSet
            // 
            this.nurseDataSet.DataSetName = "nurseDataSet";
            this.nurseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.Connection = null;
            this.tableAdapterManager2.DoctorTableAdapter = null;
            this.tableAdapterManager2.NurseTableAdapter = null;
            this.tableAdapterManager2.schedule_slotTableAdapter = null;
            this.tableAdapterManager2.UpdateOrder = hospital2.nurseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // schedule_slotTableAdapter
            // 
            this.schedule_slotTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "p_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "p_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Birthday";
            this.dataGridViewTextBoxColumn2.HeaderText = "Birthday";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn3.HeaderText = "Email";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn4.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Patient";
            this.dataGridViewTextBoxColumn5.HeaderText = "Patient";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Gender";
            this.dataGridViewTextBoxColumn6.HeaderText = "Gender";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn7.HeaderText = "Date";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "StartTime";
            this.dataGridViewTextBoxColumn8.HeaderText = "StartTime";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "EndTime";
            this.dataGridViewTextBoxColumn9.HeaderText = "EndTime";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "d_id";
            this.dataGridViewTextBoxColumn10.HeaderText = "d_id";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "doctor";
            this.dataGridViewTextBoxColumn11.HeaderText = "doctor";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Specialisation";
            this.dataGridViewTextBoxColumn12.HeaderText = "Specialisation";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "n_id";
            this.dataGridViewTextBoxColumn13.HeaderText = "n_id";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "nurse";
            this.dataGridViewTextBoxColumn14.HeaderText = "nurse";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "invoice_id";
            this.dataGridViewTextBoxColumn15.HeaderText = "invoice_id";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Bill";
            this.dataGridViewTextBoxColumn16.HeaderText = "Bill";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "BillStatus";
            this.dataGridViewTextBoxColumn17.HeaderText = "BillStatus";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "code";
            this.dataGridViewTextBoxColumn18.HeaderText = "code";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Illness";
            this.dataGridViewTextBoxColumn19.HeaderText = "Illness";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "IllnessDescription";
            this.dataGridViewTextBoxColumn20.HeaderText = "IllnessDescription";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            // 
            // overViewBindingSource
            // 
            this.overViewBindingSource.DataMember = "OverView";
            this.overViewBindingSource.DataSource = this.overViewDataSet;
            // 
            // overViewDataSet
            // 
            this.overViewDataSet.DataSetName = "overViewDataSet";
            this.overViewDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // overViewTableAdapter
            // 
            this.overViewTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = hospital2.overViewDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // Nurse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1228, 465);
            this.Controls.Add(this.slot_dateDateTimePicker);
            this.Controls.Add(this.startTextBox);
            this.Controls.Add(this.time_endTextBox);
            this.Controls.Add(this.schedule_slotDataGridView);
            this.Controls.Add(this.nfnameTextBox);
            this.Controls.Add(this.nlnameTextBox);
            this.Controls.Add(this.d_usernameTextBox);
            this.Controls.Add(this.d_passwordTextBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(label1);
            this.Controls.Add(slot_dateLabel);
            this.Controls.Add(startLabel);
            this.Controls.Add(time_endLabel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSaveSch);
            this.Controls.Add(this.overViewDataGridView);
            this.Controls.Add(nfnameLabel);
            this.Controls.Add(nlnameLabel);
            this.Controls.Add(d_usernameLabel);
            this.Controls.Add(d_passwordLabel);
            this.Name = "Nurse";
            this.Text = "Nurse";
            this.Load += new System.EventHandler(this.Nurse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseSingleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schedule_slotBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nurseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private nurseSingleDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private overViewDataSet overViewDataSet;
        private System.Windows.Forms.BindingSource overViewBindingSource;
        private overViewDataSetTableAdapters.OverViewTableAdapter overViewTableAdapter;
        private overViewDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView overViewDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private nurseDataSet nurseDataSet;
        private System.Windows.Forms.Button btnSaveSch;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private nurseDataSetTableAdapters.TableAdapterManager tableAdapterManager2;
        private nurseSingleDataSet nurseSingleDataSet;
        private System.Windows.Forms.BindingSource nurseBindingSource;
        private nurseSingleDataSetTableAdapters.NurseTableAdapter nurseTableAdapter;
        private System.Windows.Forms.TextBox nfnameTextBox;
        private System.Windows.Forms.TextBox nlnameTextBox;
        private System.Windows.Forms.TextBox d_usernameTextBox;
        private System.Windows.Forms.TextBox d_passwordTextBox;
        private System.Windows.Forms.BindingSource schedule_slotBindingSource;
        private nurseDataSetTableAdapters.schedule_slotTableAdapter schedule_slotTableAdapter;
        private System.Windows.Forms.DataGridView schedule_slotDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.BindingSource schedule_slotBindingSource1;
        private nurseSingleDataSetTableAdapters.schedule_slotTableAdapter schedule_slotTableAdapter1;
        private System.Windows.Forms.DateTimePicker slot_dateDateTimePicker;
        private System.Windows.Forms.TextBox startTextBox;
        private System.Windows.Forms.TextBox time_endTextBox;
    }
}