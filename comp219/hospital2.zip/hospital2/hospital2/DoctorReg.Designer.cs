﻿namespace hospital2
{
    partial class DoctorReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dfnameLabel;
            System.Windows.Forms.Label dlnameLabel;
            System.Windows.Forms.Label d_usernameLabel;
            System.Windows.Forms.Label d_passwordLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label s_descriptionLabel;
            this.btnReg = new System.Windows.Forms.Button();
            this.btnNewSpec = new System.Windows.Forms.Button();
            this.dfnameTextBox = new System.Windows.Forms.TextBox();
            this.doctorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.doctorSingleDataSet = new hospital2.doctorSingleDataSet();
            this.dlnameTextBox = new System.Windows.Forms.TextBox();
            this.d_usernameTextBox = new System.Windows.Forms.TextBox();
            this.d_passwordTextBox = new System.Windows.Forms.TextBox();
            this.dataSpecDataSet = new hospital2.dataSpecDataSet();
            this.doctorSpecBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.doctorSpecTableAdapter = new hospital2.dataSpecDataSetTableAdapters.doctorSpecTableAdapter();
            this.tableAdapterManager1 = new hospital2.dataSpecDataSetTableAdapters.TableAdapterManager();
            this.doctorSpecDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.doctorTableAdapter = new hospital2.doctorSingleDataSetTableAdapters.DoctorTableAdapter();
            this.tableAdapterManager = new hospital2.doctorSingleDataSetTableAdapters.TableAdapterManager();
            this.specialisationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.specialisationTableAdapter = new hospital2.doctorSingleDataSetTableAdapters.SpecialisationTableAdapter();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.s_descriptionTextBox = new System.Windows.Forms.TextBox();
            this.hasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hasTableAdapter = new hospital2.doctorSingleDataSetTableAdapters.hasTableAdapter();
            dfnameLabel = new System.Windows.Forms.Label();
            dlnameLabel = new System.Windows.Forms.Label();
            d_usernameLabel = new System.Windows.Forms.Label();
            d_passwordLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            s_descriptionLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSingleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSpecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.specialisationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dfnameLabel
            // 
            dfnameLabel.AutoSize = true;
            dfnameLabel.Location = new System.Drawing.Point(60, 43);
            dfnameLabel.Name = "dfnameLabel";
            dfnameLabel.Size = new System.Drawing.Size(45, 13);
            dfnameLabel.TabIndex = 3;
            dfnameLabel.Text = "dfname:";
            // 
            // dlnameLabel
            // 
            dlnameLabel.AutoSize = true;
            dlnameLabel.Location = new System.Drawing.Point(60, 69);
            dlnameLabel.Name = "dlnameLabel";
            dlnameLabel.Size = new System.Drawing.Size(44, 13);
            dlnameLabel.TabIndex = 5;
            dlnameLabel.Text = "dlname:";
            // 
            // d_usernameLabel
            // 
            d_usernameLabel.AutoSize = true;
            d_usernameLabel.Location = new System.Drawing.Point(60, 95);
            d_usernameLabel.Name = "d_usernameLabel";
            d_usernameLabel.Size = new System.Drawing.Size(65, 13);
            d_usernameLabel.TabIndex = 7;
            d_usernameLabel.Text = "d username:";
            // 
            // d_passwordLabel
            // 
            d_passwordLabel.AutoSize = true;
            d_passwordLabel.Location = new System.Drawing.Point(60, 121);
            d_passwordLabel.Name = "d_passwordLabel";
            d_passwordLabel.Size = new System.Drawing.Size(64, 13);
            d_passwordLabel.TabIndex = 9;
            d_passwordLabel.Text = "d password:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(63, 416);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(36, 13);
            nameLabel.TabIndex = 24;
            nameLabel.Text = "name:";
            // 
            // s_descriptionLabel
            // 
            s_descriptionLabel.AutoSize = true;
            s_descriptionLabel.Location = new System.Drawing.Point(63, 442);
            s_descriptionLabel.Name = "s_descriptionLabel";
            s_descriptionLabel.Size = new System.Drawing.Size(69, 13);
            s_descriptionLabel.TabIndex = 26;
            s_descriptionLabel.Text = "s description:";
            // 
            // btnReg
            // 
            this.btnReg.Location = new System.Drawing.Point(331, 432);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(75, 23);
            this.btnReg.TabIndex = 11;
            this.btnReg.Text = "Register";
            this.btnReg.UseVisualStyleBackColor = true;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // btnNewSpec
            // 
            this.btnNewSpec.Location = new System.Drawing.Point(270, 403);
            this.btnNewSpec.Name = "btnNewSpec";
            this.btnNewSpec.Size = new System.Drawing.Size(136, 23);
            this.btnNewSpec.TabIndex = 12;
            this.btnNewSpec.Text = "New Specilisation";
            this.btnNewSpec.UseVisualStyleBackColor = true;
            this.btnNewSpec.Click += new System.EventHandler(this.btnNewSpec_Click);
            // 
            // dfnameTextBox
            // 
            this.dfnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "dfname", true));
            this.dfnameTextBox.Location = new System.Drawing.Point(306, 43);
            this.dfnameTextBox.Name = "dfnameTextBox";
            this.dfnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.dfnameTextBox.TabIndex = 16;
            // 
            // doctorBindingSource
            // 
            this.doctorBindingSource.DataMember = "Doctor";
            this.doctorBindingSource.DataSource = this.doctorSingleDataSet;
            // 
            // doctorSingleDataSet
            // 
            this.doctorSingleDataSet.DataSetName = "doctorSingleDataSet";
            this.doctorSingleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dlnameTextBox
            // 
            this.dlnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "dlname", true));
            this.dlnameTextBox.Location = new System.Drawing.Point(306, 69);
            this.dlnameTextBox.Name = "dlnameTextBox";
            this.dlnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.dlnameTextBox.TabIndex = 18;
            // 
            // d_usernameTextBox
            // 
            this.d_usernameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "d_username", true));
            this.d_usernameTextBox.Location = new System.Drawing.Point(306, 95);
            this.d_usernameTextBox.Name = "d_usernameTextBox";
            this.d_usernameTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_usernameTextBox.TabIndex = 20;
            // 
            // d_passwordTextBox
            // 
            this.d_passwordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.doctorBindingSource, "d_password", true));
            this.d_passwordTextBox.Location = new System.Drawing.Point(306, 121);
            this.d_passwordTextBox.Name = "d_passwordTextBox";
            this.d_passwordTextBox.Size = new System.Drawing.Size(100, 20);
            this.d_passwordTextBox.TabIndex = 22;
            // 
            // dataSpecDataSet
            // 
            this.dataSpecDataSet.DataSetName = "dataSpecDataSet";
            this.dataSpecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // doctorSpecBindingSource
            // 
            this.doctorSpecBindingSource.DataMember = "doctorSpec";
            this.doctorSpecBindingSource.DataSource = this.dataSpecDataSet;
            // 
            // doctorSpecTableAdapter
            // 
            this.doctorSpecTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = hospital2.dataSpecDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // doctorSpecDataGridView
            // 
            this.doctorSpecDataGridView.AutoGenerateColumns = false;
            this.doctorSpecDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.doctorSpecDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn1});
            this.doctorSpecDataGridView.DataSource = this.doctorSpecBindingSource;
            this.doctorSpecDataGridView.Location = new System.Drawing.Point(63, 161);
            this.doctorSpecDataGridView.Name = "doctorSpecDataGridView";
            this.doctorSpecDataGridView.Size = new System.Drawing.Size(343, 220);
            this.doctorSpecDataGridView.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn5.HeaderText = "name";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "specid";
            this.dataGridViewTextBoxColumn4.HeaderText = "specid";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "spec_doctor_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "spec_doctor_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // doctorTableAdapter
            // 
            this.doctorTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DoctorTableAdapter = this.doctorTableAdapter;
            this.tableAdapterManager.hasTableAdapter = null;
            this.tableAdapterManager.schedule_slotTableAdapter = null;
            this.tableAdapterManager.SpecialisationTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = hospital2.doctorSingleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // specialisationBindingSource
            // 
            this.specialisationBindingSource.DataMember = "Specialisation";
            this.specialisationBindingSource.DataSource = this.doctorSingleDataSet;
            // 
            // specialisationTableAdapter
            // 
            this.specialisationTableAdapter.ClearBeforeFill = true;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.specialisationBindingSource, "name", true));
            this.nameTextBox.Location = new System.Drawing.Point(138, 413);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 25;
            // 
            // s_descriptionTextBox
            // 
            this.s_descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.specialisationBindingSource, "s_description", true));
            this.s_descriptionTextBox.Location = new System.Drawing.Point(138, 439);
            this.s_descriptionTextBox.Name = "s_descriptionTextBox";
            this.s_descriptionTextBox.Size = new System.Drawing.Size(100, 20);
            this.s_descriptionTextBox.TabIndex = 27;
            // 
            // hasBindingSource
            // 
            this.hasBindingSource.DataMember = "has";
            this.hasBindingSource.DataSource = this.doctorSingleDataSet;
            // 
            // hasTableAdapter
            // 
            this.hasTableAdapter.ClearBeforeFill = true;
            // 
            // DoctorReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 522);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(s_descriptionLabel);
            this.Controls.Add(this.s_descriptionTextBox);
            this.Controls.Add(this.doctorSpecDataGridView);
            this.Controls.Add(this.dfnameTextBox);
            this.Controls.Add(this.dlnameTextBox);
            this.Controls.Add(this.d_usernameTextBox);
            this.Controls.Add(this.d_passwordTextBox);
            this.Controls.Add(this.btnNewSpec);
            this.Controls.Add(this.btnReg);
            this.Controls.Add(dfnameLabel);
            this.Controls.Add(dlnameLabel);
            this.Controls.Add(d_usernameLabel);
            this.Controls.Add(d_passwordLabel);
            this.Name = "DoctorReg";
            this.Text = "DoctorReg";
            this.Load += new System.EventHandler(this.DoctorReg_Load);
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSingleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSpecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorSpecDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.specialisationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hasBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReg;
        private System.Windows.Forms.Button btnNewSpec;
        private doctorSingleDataSet doctorSingleDataSet;
        private System.Windows.Forms.BindingSource doctorBindingSource;
        private doctorSingleDataSetTableAdapters.DoctorTableAdapter doctorTableAdapter;
        private doctorSingleDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox dfnameTextBox;
        private System.Windows.Forms.TextBox dlnameTextBox;
        private System.Windows.Forms.TextBox d_usernameTextBox;
        private System.Windows.Forms.TextBox d_passwordTextBox;
        private dataSpecDataSet dataSpecDataSet;
        private System.Windows.Forms.BindingSource doctorSpecBindingSource;
        private dataSpecDataSetTableAdapters.doctorSpecTableAdapter doctorSpecTableAdapter;
        private dataSpecDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView doctorSpecDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource specialisationBindingSource;
        private doctorSingleDataSetTableAdapters.SpecialisationTableAdapter specialisationTableAdapter;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox s_descriptionTextBox;
        private System.Windows.Forms.BindingSource hasBindingSource;
        private doctorSingleDataSetTableAdapters.hasTableAdapter hasTableAdapter;
    }
}