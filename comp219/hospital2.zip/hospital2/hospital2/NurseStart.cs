﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class NurseStart : Form
    {
        public NurseStart()
        {
            InitializeComponent();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            NurseReg nur = new NurseReg();
            nur.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            int ID = 0;
            bool su = false;
            try
            {
                if (nurseSingleDataSet.Tables["Nurse"].Rows.Count != 0)
                {
                    for (int i = 0; i < nurseSingleDataSet.Tables["Nurse"].Rows.Count; i++)
                    {
                        if (textBox1.Text == nurseSingleDataSet.Tables["Nurse"].Rows[i].ItemArray[3].ToString()) //if the relationship exist in the nurse dateset
                        {
                            if (textBox2.Text == nurseSingleDataSet.Tables["Nurse"].Rows[i].ItemArray[4].ToString())
                            {
                                ID = Convert.ToInt16(nurseSingleDataSet.Tables["Nurse"].Rows[i]["n_id"]);
                                su = true;
                                break;
                            }
                        }
                    }
                    if (su)
                    {
                        Nurse nur = new Nurse();
                        nur.ID = ID;
                        nur.Show();
                    }
                    else
                    {
                        MessageBox.Show("wrong password or mail, try again");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void doctorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.doctorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.doctorSingleDataSet);

        }

        private void NurseStart_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nurseSingleDataSet.Nurse' table. You can move, or remove it, as needed.
            this.nurseTableAdapter.Fill(this.nurseSingleDataSet.Nurse);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.Doctor' table. You can move, or remove it, as needed.
            this.doctorTableAdapter.Fill(this.doctorSingleDataSet.Doctor);

        }
    }
}
