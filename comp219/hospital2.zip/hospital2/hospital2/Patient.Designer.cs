﻿namespace hospital2
{
    partial class Patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dobLabel;
            System.Windows.Forms.Label emailLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label pfnameLabel;
            System.Windows.Forms.Label plnameLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label p_passwordLabel;
            System.Windows.Forms.Label amountLabel;
            System.Windows.Forms.Label i_statusLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label i_descriptionLabel;
            System.Windows.Forms.Label confirmedLabel;
            System.Windows.Forms.Label notesLabel;
            System.Windows.Forms.Label b_weightLabel;
            this.btnsave = new System.Windows.Forms.Button();
            this.patientSingleDataSet = new hospital2.patientSingleDataSet();
            this.patientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.patientTableAdapter = new hospital2.patientSingleDataSetTableAdapters.PatientTableAdapter();
            this.tableAdapterManager = new hospital2.patientSingleDataSetTableAdapters.TableAdapterManager();
            this.bookTableAdapter = new hospital2.patientSingleDataSetTableAdapters.bookTableAdapter();
            this.illnessTableAdapter = new hospital2.patientSingleDataSetTableAdapters.illnessTableAdapter();
            this.invoiceTableAdapter = new hospital2.patientSingleDataSetTableAdapters.InvoiceTableAdapter();
            this.dobDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.pfnameTextBox = new System.Windows.Forms.TextBox();
            this.plnameTextBox = new System.Windows.Forms.TextBox();
            this.genderTextBox = new System.Windows.Forms.TextBox();
            this.p_passwordTextBox = new System.Windows.Forms.TextBox();
            this.invoiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.i_statusTextBox = new System.Windows.Forms.TextBox();
            this.illnessBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.i_descriptionTextBox = new System.Windows.Forms.TextBox();
            this.bookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.confirmedTextBox = new System.Windows.Forms.TextBox();
            this.notesTextBox = new System.Windows.Forms.TextBox();
            this.b_weightTextBox = new System.Windows.Forms.TextBox();
            this.overViewDataSet = new hospital2.overViewDataSet();
            this.overViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.overViewTableAdapter = new hospital2.overViewDataSetTableAdapters.OverViewTableAdapter();
            this.tableAdapterManager1 = new hospital2.overViewDataSetTableAdapters.TableAdapterManager();
            this.overViewDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            dobLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            pfnameLabel = new System.Windows.Forms.Label();
            plnameLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            p_passwordLabel = new System.Windows.Forms.Label();
            amountLabel = new System.Windows.Forms.Label();
            i_statusLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            i_descriptionLabel = new System.Windows.Forms.Label();
            confirmedLabel = new System.Windows.Forms.Label();
            notesLabel = new System.Windows.Forms.Label();
            b_weightLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.patientSingleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.illnessBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dobLabel
            // 
            dobLabel.AutoSize = true;
            dobLabel.Location = new System.Drawing.Point(40, 54);
            dobLabel.Name = "dobLabel";
            dobLabel.Size = new System.Drawing.Size(28, 13);
            dobLabel.TabIndex = 3;
            dobLabel.Text = "dob:";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(40, 79);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(34, 13);
            emailLabel.TabIndex = 5;
            emailLabel.Text = "email:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(40, 105);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(40, 13);
            phoneLabel.TabIndex = 7;
            phoneLabel.Text = "phone:";
            // 
            // pfnameLabel
            // 
            pfnameLabel.AutoSize = true;
            pfnameLabel.Location = new System.Drawing.Point(40, 131);
            pfnameLabel.Name = "pfnameLabel";
            pfnameLabel.Size = new System.Drawing.Size(45, 13);
            pfnameLabel.TabIndex = 9;
            pfnameLabel.Text = "pfname:";
            // 
            // plnameLabel
            // 
            plnameLabel.AutoSize = true;
            plnameLabel.Location = new System.Drawing.Point(40, 157);
            plnameLabel.Name = "plnameLabel";
            plnameLabel.Size = new System.Drawing.Size(44, 13);
            plnameLabel.TabIndex = 11;
            plnameLabel.Text = "plname:";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Location = new System.Drawing.Point(40, 183);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(43, 13);
            genderLabel.TabIndex = 13;
            genderLabel.Text = "gender:";
            // 
            // p_passwordLabel
            // 
            p_passwordLabel.AutoSize = true;
            p_passwordLabel.Location = new System.Drawing.Point(40, 209);
            p_passwordLabel.Name = "p_passwordLabel";
            p_passwordLabel.Size = new System.Drawing.Size(64, 13);
            p_passwordLabel.TabIndex = 15;
            p_passwordLabel.Text = "p password:";
            // 
            // amountLabel
            // 
            amountLabel.AutoSize = true;
            amountLabel.Location = new System.Drawing.Point(364, 50);
            amountLabel.Name = "amountLabel";
            amountLabel.Size = new System.Drawing.Size(45, 13);
            amountLabel.TabIndex = 18;
            amountLabel.Text = "amount:";
            // 
            // i_statusLabel
            // 
            i_statusLabel.AutoSize = true;
            i_statusLabel.Location = new System.Drawing.Point(364, 76);
            i_statusLabel.Name = "i_statusLabel";
            i_statusLabel.Size = new System.Drawing.Size(43, 13);
            i_statusLabel.TabIndex = 20;
            i_statusLabel.Text = "i status:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(353, 108);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(36, 13);
            nameLabel.TabIndex = 23;
            nameLabel.Text = "name:";
            // 
            // i_descriptionLabel
            // 
            i_descriptionLabel.AutoSize = true;
            i_descriptionLabel.Location = new System.Drawing.Point(353, 134);
            i_descriptionLabel.Name = "i_descriptionLabel";
            i_descriptionLabel.Size = new System.Drawing.Size(66, 13);
            i_descriptionLabel.TabIndex = 25;
            i_descriptionLabel.Text = "i description:";
            // 
            // confirmedLabel
            // 
            confirmedLabel.AutoSize = true;
            confirmedLabel.Location = new System.Drawing.Point(355, 160);
            confirmedLabel.Name = "confirmedLabel";
            confirmedLabel.Size = new System.Drawing.Size(56, 13);
            confirmedLabel.TabIndex = 34;
            confirmedLabel.Text = "confirmed:";
            // 
            // notesLabel
            // 
            notesLabel.AutoSize = true;
            notesLabel.Location = new System.Drawing.Point(355, 186);
            notesLabel.Name = "notesLabel";
            notesLabel.Size = new System.Drawing.Size(36, 13);
            notesLabel.TabIndex = 36;
            notesLabel.Text = "notes:";
            // 
            // b_weightLabel
            // 
            b_weightLabel.AutoSize = true;
            b_weightLabel.Location = new System.Drawing.Point(355, 212);
            b_weightLabel.Name = "b_weightLabel";
            b_weightLabel.Size = new System.Drawing.Size(50, 13);
            b_weightLabel.TabIndex = 38;
            b_weightLabel.Text = "b weight:";
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(594, 262);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 40;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // patientSingleDataSet
            // 
            this.patientSingleDataSet.DataSetName = "patientSingleDataSet";
            this.patientSingleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // patientBindingSource
            // 
            this.patientBindingSource.DataMember = "Patient";
            this.patientBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // patientTableAdapter
            // 
            this.patientTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.bookTableAdapter = this.bookTableAdapter;
            this.tableAdapterManager.illnessTableAdapter = this.illnessTableAdapter;
            this.tableAdapterManager.InvoiceTableAdapter = this.invoiceTableAdapter;
            this.tableAdapterManager.PatientTableAdapter = this.patientTableAdapter;
            this.tableAdapterManager.schedule_slotTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = hospital2.patientSingleDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // bookTableAdapter
            // 
            this.bookTableAdapter.ClearBeforeFill = true;
            // 
            // illnessTableAdapter
            // 
            this.illnessTableAdapter.ClearBeforeFill = true;
            // 
            // invoiceTableAdapter
            // 
            this.invoiceTableAdapter.ClearBeforeFill = true;
            // 
            // dobDateTimePicker
            // 
            this.dobDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.patientBindingSource, "dob", true));
            this.dobDateTimePicker.Location = new System.Drawing.Point(117, 54);
            this.dobDateTimePicker.Name = "dobDateTimePicker";
            this.dobDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dobDateTimePicker.TabIndex = 44;
            // 
            // emailTextBox
            // 
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource, "email", true));
            this.emailTextBox.Location = new System.Drawing.Point(117, 80);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(200, 20);
            this.emailTextBox.TabIndex = 46;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource, "phone", true));
            this.phoneTextBox.Location = new System.Drawing.Point(117, 106);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(200, 20);
            this.phoneTextBox.TabIndex = 48;
            // 
            // pfnameTextBox
            // 
            this.pfnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource, "pfname", true));
            this.pfnameTextBox.Location = new System.Drawing.Point(117, 132);
            this.pfnameTextBox.Name = "pfnameTextBox";
            this.pfnameTextBox.Size = new System.Drawing.Size(200, 20);
            this.pfnameTextBox.TabIndex = 50;
            // 
            // plnameTextBox
            // 
            this.plnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource, "plname", true));
            this.plnameTextBox.Location = new System.Drawing.Point(117, 158);
            this.plnameTextBox.Name = "plnameTextBox";
            this.plnameTextBox.Size = new System.Drawing.Size(200, 20);
            this.plnameTextBox.TabIndex = 52;
            // 
            // genderTextBox
            // 
            this.genderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource, "gender", true));
            this.genderTextBox.Location = new System.Drawing.Point(117, 184);
            this.genderTextBox.Name = "genderTextBox";
            this.genderTextBox.Size = new System.Drawing.Size(200, 20);
            this.genderTextBox.TabIndex = 54;
            // 
            // p_passwordTextBox
            // 
            this.p_passwordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.patientBindingSource, "p_password", true));
            this.p_passwordTextBox.Location = new System.Drawing.Point(117, 210);
            this.p_passwordTextBox.Name = "p_passwordTextBox";
            this.p_passwordTextBox.Size = new System.Drawing.Size(200, 20);
            this.p_passwordTextBox.TabIndex = 56;
            // 
            // invoiceBindingSource
            // 
            this.invoiceBindingSource.DataMember = "Invoice";
            this.invoiceBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // amountTextBox
            // 
            this.amountTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "amount", true));
            this.amountTextBox.Location = new System.Drawing.Point(531, 50);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(100, 20);
            this.amountTextBox.TabIndex = 59;
            // 
            // i_statusTextBox
            // 
            this.i_statusTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoiceBindingSource, "i_status", true));
            this.i_statusTextBox.Location = new System.Drawing.Point(531, 76);
            this.i_statusTextBox.Name = "i_statusTextBox";
            this.i_statusTextBox.Size = new System.Drawing.Size(100, 20);
            this.i_statusTextBox.TabIndex = 61;
            // 
            // illnessBindingSource
            // 
            this.illnessBindingSource.DataMember = "illness";
            this.illnessBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.illnessBindingSource, "name", true));
            this.nameTextBox.Location = new System.Drawing.Point(531, 108);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 64;
            // 
            // i_descriptionTextBox
            // 
            this.i_descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.illnessBindingSource, "i_description", true));
            this.i_descriptionTextBox.Location = new System.Drawing.Point(531, 134);
            this.i_descriptionTextBox.Name = "i_descriptionTextBox";
            this.i_descriptionTextBox.Size = new System.Drawing.Size(100, 20);
            this.i_descriptionTextBox.TabIndex = 66;
            // 
            // bookBindingSource
            // 
            this.bookBindingSource.DataMember = "book";
            this.bookBindingSource.DataSource = this.patientSingleDataSet;
            // 
            // confirmedTextBox
            // 
            this.confirmedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "confirmed", true));
            this.confirmedTextBox.Location = new System.Drawing.Point(531, 160);
            this.confirmedTextBox.Name = "confirmedTextBox";
            this.confirmedTextBox.Size = new System.Drawing.Size(100, 20);
            this.confirmedTextBox.TabIndex = 75;
            // 
            // notesTextBox
            // 
            this.notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "notes", true));
            this.notesTextBox.Location = new System.Drawing.Point(531, 186);
            this.notesTextBox.Name = "notesTextBox";
            this.notesTextBox.Size = new System.Drawing.Size(100, 20);
            this.notesTextBox.TabIndex = 77;
            // 
            // b_weightTextBox
            // 
            this.b_weightTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "b_weight", true));
            this.b_weightTextBox.Location = new System.Drawing.Point(531, 212);
            this.b_weightTextBox.Name = "b_weightTextBox";
            this.b_weightTextBox.Size = new System.Drawing.Size(100, 20);
            this.b_weightTextBox.TabIndex = 79;
            // 
            // overViewDataSet
            // 
            this.overViewDataSet.DataSetName = "overViewDataSet";
            this.overViewDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // overViewBindingSource
            // 
            this.overViewBindingSource.DataMember = "OverView";
            this.overViewBindingSource.DataSource = this.overViewDataSet;
            // 
            // overViewTableAdapter
            // 
            this.overViewTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = hospital2.overViewDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // overViewDataGridView
            // 
            this.overViewDataGridView.AutoGenerateColumns = false;
            this.overViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.overViewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20});
            this.overViewDataGridView.DataSource = this.overViewBindingSource;
            this.overViewDataGridView.Location = new System.Drawing.Point(43, 300);
            this.overViewDataGridView.Name = "overViewDataGridView";
            this.overViewDataGridView.Size = new System.Drawing.Size(626, 220);
            this.overViewDataGridView.TabIndex = 79;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "p_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "p_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Birthday";
            this.dataGridViewTextBoxColumn2.HeaderText = "Birthday";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn3.HeaderText = "Email";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn4.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Patient";
            this.dataGridViewTextBoxColumn5.HeaderText = "Patient";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Gender";
            this.dataGridViewTextBoxColumn6.HeaderText = "Gender";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn7.HeaderText = "Date";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "StartTime";
            this.dataGridViewTextBoxColumn8.HeaderText = "StartTime";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "EndTime";
            this.dataGridViewTextBoxColumn9.HeaderText = "EndTime";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "d_id";
            this.dataGridViewTextBoxColumn10.HeaderText = "d_id";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "doctor";
            this.dataGridViewTextBoxColumn11.HeaderText = "doctor";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Specialisation";
            this.dataGridViewTextBoxColumn12.HeaderText = "Specialisation";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "n_id";
            this.dataGridViewTextBoxColumn13.HeaderText = "n_id";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "nurse";
            this.dataGridViewTextBoxColumn14.HeaderText = "nurse";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "invoice_id";
            this.dataGridViewTextBoxColumn15.HeaderText = "invoice_id";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Bill";
            this.dataGridViewTextBoxColumn16.HeaderText = "Bill";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "BillStatus";
            this.dataGridViewTextBoxColumn17.HeaderText = "BillStatus";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "code";
            this.dataGridViewTextBoxColumn18.HeaderText = "code";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Illness";
            this.dataGridViewTextBoxColumn19.HeaderText = "Illness";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "IllnessDescription";
            this.dataGridViewTextBoxColumn20.HeaderText = "IllnessDescription";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // Patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 596);
            this.Controls.Add(this.overViewDataGridView);
            this.Controls.Add(this.confirmedTextBox);
            this.Controls.Add(this.notesTextBox);
            this.Controls.Add(this.b_weightTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.i_descriptionTextBox);
            this.Controls.Add(this.amountTextBox);
            this.Controls.Add(this.i_statusTextBox);
            this.Controls.Add(this.dobDateTimePicker);
            this.Controls.Add(this.emailTextBox);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.pfnameTextBox);
            this.Controls.Add(this.plnameTextBox);
            this.Controls.Add(this.genderTextBox);
            this.Controls.Add(this.p_passwordTextBox);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(confirmedLabel);
            this.Controls.Add(notesLabel);
            this.Controls.Add(b_weightLabel);
            this.Controls.Add(nameLabel);
            this.Controls.Add(i_descriptionLabel);
            this.Controls.Add(amountLabel);
            this.Controls.Add(i_statusLabel);
            this.Controls.Add(dobLabel);
            this.Controls.Add(emailLabel);
            this.Controls.Add(phoneLabel);
            this.Controls.Add(pfnameLabel);
            this.Controls.Add(plnameLabel);
            this.Controls.Add(genderLabel);
            this.Controls.Add(p_passwordLabel);
            this.Name = "Patient";
            this.Text = "Patient";
            this.Load += new System.EventHandler(this.Patient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.patientSingleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.illnessBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.overViewDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsave;
        private patientSingleDataSet patientSingleDataSet;
        private System.Windows.Forms.BindingSource patientBindingSource;
        private patientSingleDataSetTableAdapters.PatientTableAdapter patientTableAdapter;
        private patientSingleDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private patientSingleDataSetTableAdapters.InvoiceTableAdapter invoiceTableAdapter;
        private System.Windows.Forms.DateTimePicker dobDateTimePicker;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox pfnameTextBox;
        private System.Windows.Forms.TextBox plnameTextBox;
        private System.Windows.Forms.TextBox genderTextBox;
        private System.Windows.Forms.TextBox p_passwordTextBox;
        private System.Windows.Forms.BindingSource invoiceBindingSource;
        private patientSingleDataSetTableAdapters.illnessTableAdapter illnessTableAdapter;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.TextBox i_statusTextBox;
        private System.Windows.Forms.BindingSource illnessBindingSource;
        private patientSingleDataSetTableAdapters.bookTableAdapter bookTableAdapter;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox i_descriptionTextBox;
        private System.Windows.Forms.BindingSource bookBindingSource;
        private System.Windows.Forms.TextBox confirmedTextBox;
        private System.Windows.Forms.TextBox notesTextBox;
        private System.Windows.Forms.TextBox b_weightTextBox;
        private overViewDataSet overViewDataSet;
        private System.Windows.Forms.BindingSource overViewBindingSource;
        private overViewDataSetTableAdapters.OverViewTableAdapter overViewTableAdapter;
        private overViewDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.DataGridView overViewDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
    }
}