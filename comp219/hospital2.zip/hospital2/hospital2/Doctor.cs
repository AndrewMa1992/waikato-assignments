﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class Doctor : Form
    {
        public Doctor()
        {
            InitializeComponent();
        }

        public int ID = 2;
        private bool newsche = false;

        private bool newspec_click = false;
        private int spec_code = 0;
        private int doct_id = 0;

        private void doctorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.doctorBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.doctorDataSet);

        }

        private void Doctor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'doctorSingleDataSet.schedule_slot' table. You can move, or remove it, as needed.
            this.schedule_slotTableAdapter1.Fill(this.doctorSingleDataSet.schedule_slot);
            // TODO: This line of code loads data into the 'doctorDataSet.schedule_slot' table. You can move, or remove it, as needed.
            this.schedule_slotTableAdapter.Fill(this.doctorDataSet.schedule_slot);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.Doctor' table. You can move, or remove it, as needed.
            this.doctorTableAdapter1.Fill(this.doctorSingleDataSet.Doctor);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.has' table. You can move, or remove it, as needed.
            this.hasTableAdapter.Fill(this.doctorSingleDataSet.has);
            // TODO: This line of code loads data into the 'overViewDataSet.OverView' table. You can move, or remove it, as needed.
            this.overViewTableAdapter.Fill(this.overViewDataSet.OverView);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.schedule_slot' table. You can move, or remove it, as needed.
            this.schedule_slotTableAdapter1.Fill(this.doctorSingleDataSet.schedule_slot);
            // TODO: This line of code loads data into the 'doctorDataSet.schedule_slot' table. You can move, or remove it, as needed.
            this.schedule_slotTableAdapter.Fill(this.doctorDataSet.schedule_slot);
            // TODO: This line of code loads data into the 'doctorSingleDataSet.Specialisation' table. You can move, or remove it, as needed.
            this.specialisationTableAdapter.Fill(this.doctorSingleDataSet.Specialisation);
            // TODO: This line of code loads data into the 'dataSpecDataSet.doctorSpec' table. You can move, or remove it, as needed.
            this.doctorSpecTableAdapter.Fill(this.dataSpecDataSet.doctorSpec);
            // TODO: This line of code loads data into the 'overViewDataSet.OverView' table. You can move, or remove it, as needed.
            this.overViewTableAdapter.Fill(this.overViewDataSet.OverView);
            // TODO: This line of code loads data into the 'doctorDataSet.Doctor' table. You can move, or remove it, as needed.
            this.doctorTableAdapter.Fill(this.doctorDataSet.Doctor);

            doctorSpecTableAdapter.FillBy(dataSpecDataSet.doctorSpec, ID);
            overViewTableAdapter.FillByd(overViewDataSet.OverView, ID);
            schedule_slotTableAdapter.FillBy(doctorDataSet.schedule_slot, ID);

        }

        private void doctorSpecDataGridView_Click(object sender, EventArgs e)
        {
            int index = doctorSpecDataGridView.CurrentCellAddress.Y;
            int ID = Convert.ToInt16(doctorSpecDataGridView.Rows[index].Cells[1].Value);
            spec_code = ID;
            specialisationTableAdapter.FillBy(doctorSingleDataSet.Specialisation, ID);
        }

        private void btnSaveDoc_Click(object sender, EventArgs e)
        {
            doctorBindingSource1.EndEdit();
            doctorTableAdapter1.Update(doctorSingleDataSet.Doctor);
            doctorTableAdapter.Fill(doctorDataSet.Doctor);
        }

        private void btnSaveNewSpec_Click(object sender, EventArgs e)
        {
            if (newspec_click)
            {
                bool have = false;
                if (doct_id != 0 && spec_code != 0)
                {
                    for (int i = 0; i < doctorSingleDataSet.has.Rows.Count; i++)
                    {
                        if (doct_id == Convert.ToInt16(doctorSingleDataSet.has.Rows[i].ItemArray[0]))
                        {
                            if (spec_code == Convert.ToInt16(doctorSingleDataSet.has.Rows[i].ItemArray[1]))
                            {
                                MessageBox.Show("you have already had this specilisation");
                                have = true;
                                newspec_click = false;
                                spec_code = 0;
                                btnSaveNewSpec.Text = "Add New Specilisation";
                            }
                        }
                    }
                }

                if (!have)
                {
                    try
                    {
                        DataRow newrow1 = doctorSingleDataSet.Specialisation.NewRow();
                        int ID = 0;
                        if (doctorSingleDataSet.Tables["Specialisation"].Rows.Count != 0)
                        {
                            ID = Convert.ToInt16(doctorSingleDataSet.Tables["Specialisation"].Rows[doctorSingleDataSet.Tables["Specialisation"].Rows.Count - 1].ItemArray[0]) + 1;
                        }
                        else
                        {
                            ID = 1;
                        }
                        newrow1["code"] = ID;
                        newrow1["name"] = nameTextBox.Text;
                        newrow1["s_description"] = s_descriptionTextBox.Text;
                        doctorSingleDataSet.Specialisation.Rows.Add(newrow1);
                        specialisationTableAdapter.Update(doctorSingleDataSet.Specialisation);

                        DataRow newrow2 = doctorSingleDataSet.has.NewRow();
                        newrow2["h_doctor_id"] = doct_id;
                        newrow2["h_spec_id"] = spec_code;
                        doctorSingleDataSet.has.Rows.Add(newrow2);
                        hasTableAdapter.Update(doctorSingleDataSet.has);
                        doctorSpecTableAdapter.Fill(dataSpecDataSet.doctorSpec);
                        newspec_click = false;
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                }
            }
            else
            {
                btnSaveNewSpec.Text = "Save New Specilisation";
                btnSaveNewSpec.Text = "";
                s_descriptionTextBox.Text = "";
                newspec_click = true;
            }
        }

        private void btnsSaveSche_Click(object sender, EventArgs e)
        {
            schedule_slotBindingSource1.EndEdit();
            schedule_slotTableAdapter1.Update(doctorSingleDataSet.schedule_slot);
            schedule_slotTableAdapter.Fill(doctorDataSet.schedule_slot);
        }

        private void btnNewSch_Click(object sender, EventArgs e)
        {
            if (doct_id == 0)
            {
                MessageBox.Show("you must select a doctor");
                return;
            }

            if (!newsche)
            {
                startTextBox.Text = "";
                time_endTextBox.Text = "";
                txtNurseName.Text = "";
                newsche = true;
            }
            else
            {
                try
                {
                    int ID = 0;
                    string date1 = slot_dateDateTimePicker.Text;
                    int count = 1;
                    DataRow newrow1 = doctorSingleDataSet.Tables["schedule_slot"].NewRow();
                    if (doctorSingleDataSet.Tables["schedule_slot"].Rows.Count != 0)
                    {
                        ID = Convert.ToInt16(doctorSingleDataSet.Tables["schedule_slot"].Rows[doctorSingleDataSet.Tables["schedule_slot"].Rows.Count - 1].ItemArray[0]) + 1;
                    }
                    else
                    {
                        ID = 1;
                    }
                    newrow1["slot_id"] = ID;


                    if (doctorSingleDataSet.schedule_slot.Rows.Count != 0)
                    {
                        for (int i = 0; i < doctorSingleDataSet.schedule_slot.Rows.Count; i++)
                        {
                            if (date1 == doctorSingleDataSet.schedule_slot.Rows[i].ItemArray[3].ToString())
                            {
                                if (startTextBox.Text == doctorSingleDataSet.schedule_slot.Rows[i].ItemArray[4].ToString())
                                {
                                    if (time_endTextBox.Text == doctorSingleDataSet.schedule_slot.Rows[i].ItemArray[5].ToString())
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                    }
                    //"d/MM/yyyy hh:mm:ss tt"
                    newrow1["slot"] = count;
                    newrow1["slot2"] = 0;
                    newrow1["slot_date"] = date1.ToString();
                    newrow1["start"] = startTextBox.Text;
                    newrow1["time_end"] = time_endTextBox.Text;
                    newrow1["s_doctor_id"] = doct_id;
                    newrow1["s_nurse_id"] = DBNull.Value;
                    doctorSingleDataSet.schedule_slot.Rows.Add(newrow1);
                    schedule_slotTableAdapter1.Update(doctorSingleDataSet.schedule_slot);
                    schedule_slotTableAdapter.Fill(doctorDataSet.schedule_slot);

                    newsche = true;
                    btnNewSch.Text = "Save";
                    slot_dateDateTimePicker.Enabled = true;
                }
                catch (Exception)
                {

                    throw;
                }

            }
        }

        private void schedule_slotDataGridView_Click(object sender, EventArgs e)
        {
            try
            {
                int index = schedule_slotDataGridView.CurrentCellAddress.Y;
                int ID = Convert.ToInt16(schedule_slotDataGridView.Rows[index].Cells[3].Value);
                if (schedule_slotDataGridView.Rows[index].Cells[4].Value != DBNull.Value)
                {
                    int Nurse = Convert.ToInt16(schedule_slotDataGridView.Rows[index].Cells[4].Value);
                    string nursefirst = "";
                    string nurselast = "";
                    if (doctorDataSet.Nurse.Rows.Count != 0)
                    {
                        for (int i = 0; i < doctorDataSet.Nurse.Rows.Count; i++)
                        {
                            if (Nurse == Convert.ToInt16(doctorDataSet.Nurse.Rows[i].ItemArray[0]))
                            {
                                nursefirst = doctorDataSet.Nurse.Rows[i].ItemArray[1].ToString();
                                nurselast = doctorDataSet.Nurse.Rows[i].ItemArray[2].ToString();
                                txtNurseName.Text = nursefirst + "  " + nurselast;
                            }
                        }
                    }
                }
                else
                {
                    txtNurseName.Text = "";
                }
                schedule_slotTableAdapter1.FillBy(doctorSingleDataSet.schedule_slot, ID);

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
