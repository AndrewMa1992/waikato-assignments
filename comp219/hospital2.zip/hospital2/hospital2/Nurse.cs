﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class Nurse : Form
    {
        public Nurse()
        {
            InitializeComponent();
        }
        public int ID = 0;
        private bool newsche = false;

        private bool newspec_click = false;
        private int spec_code = 0;

        private void Nurse_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nurseSingleDataSet.schedule_slot' table. You can move, or remove it, as needed.
            this.schedule_slotTableAdapter1.Fill(this.nurseSingleDataSet.schedule_slot);
            // TODO: This line of code loads data into the 'nurseDataSet.schedule_slot' table. You can move, or remove it, as needed.
            this.schedule_slotTableAdapter.Fill(this.nurseDataSet.schedule_slot);
            // TODO: This line of code loads data into the 'nurseSingleDataSet.Nurse' table. You can move, or remove it, as needed.
            this.nurseTableAdapter.Fill(this.nurseSingleDataSet.Nurse);
            // TODO: This line of code loads data into the 'nurseSingleDataSet.schedule_slot' table. You can move, or remove it, as needed.

            overViewTableAdapter.FillByn(overViewDataSet.OverView, ID);
            nurseTableAdapter.FillBy(nurseSingleDataSet.Nurse, ID);
            //int? a = ID;
            //schedule_slotTableAdapter.FillBy(nurseSingleDataSet.schedule_slot, a);
        }

        private void schedule_slotDataGridView_Click(object sender, EventArgs e)
        {
            try
            {
                int index = schedule_slotDataGridView.CurrentCellAddress.Y;
                int ID = Convert.ToInt16(schedule_slotDataGridView.Rows[index].Cells[3].Value);
                if (schedule_slotDataGridView.Rows[index].Cells[4].Value != DBNull.Value)
                {
                    int Nurse = Convert.ToInt16(schedule_slotDataGridView.Rows[index].Cells[4].Value);
                    string nursefirst = "";
                    string nurselast = "";
                    if (nurseDataSet.Nurse.Rows.Count != 0)
                    {
                        for (int i = 0; i < nurseDataSet.Nurse.Rows.Count; i++)
                        {
                            if (Nurse == Convert.ToInt16(nurseDataSet.Nurse.Rows[i].ItemArray[0]))
                            {
                                nursefirst = nurseDataSet.Nurse.Rows[i].ItemArray[1].ToString();
                                nurselast = nurseDataSet.Nurse.Rows[i].ItemArray[2].ToString();
                                textBox1.Text = nursefirst + "  " + nurselast;
                            }
                        }
                    }
                }
                else
                {
                    textBox1.Text = "";
                }
                schedule_slotTableAdapter1.FillBy(nurseSingleDataSet.schedule_slot, ID);

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!newsche)
            {
                startTextBox.Text = "";
                time_endTextBox.Text = "";
                textBox1.Text = "";
                newsche = true;
            }
            else
            {
                try
                {
                    int ID = 0;
                    string date1 = slot_dateDateTimePicker.Text;
                    int count = 1;
                    DataRow newrow1 = nurseSingleDataSet.Tables["schedule_slot"].NewRow();
                    if (nurseSingleDataSet.Tables["schedule_slot"].Rows.Count != 0)
                    {
                        ID = Convert.ToInt16(nurseSingleDataSet.Tables["schedule_slot"].Rows[nurseSingleDataSet.Tables["schedule_slot"].Rows.Count - 1].ItemArray[0]) + 1;
                    }
                    else
                    {
                        ID = 1;
                    }
                    newrow1["slot_id"] = ID;


                    if (nurseSingleDataSet.schedule_slot.Rows.Count != 0)
                    {
                        for (int i = 0; i < nurseSingleDataSet.schedule_slot.Rows.Count; i++)
                        {
                            if (date1 == nurseSingleDataSet.schedule_slot.Rows[i].ItemArray[3].ToString())
                            {
                                if (startTextBox.Text == nurseSingleDataSet.schedule_slot.Rows[i].ItemArray[4].ToString())
                                {
                                    if (time_endTextBox.Text == nurseSingleDataSet.schedule_slot.Rows[i].ItemArray[5].ToString())
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                    }
                    //"d/MM/yyyy hh:mm:ss tt"
                    newrow1["slot"] = count;
                    newrow1["slot2"] = 0;
                    newrow1["slot_date"] = date1.ToString();
                    newrow1["start"] = startTextBox.Text;
                    newrow1["time_end"] = time_endTextBox.Text;
                    newrow1["s_nurse_id"] = ID;
                    newrow1["s_nurse_id"] = DBNull.Value;
                    nurseSingleDataSet.schedule_slot.Rows.Add(newrow1);
                    schedule_slotTableAdapter1.Update(nurseSingleDataSet.schedule_slot);
                    schedule_slotTableAdapter.Fill(nurseDataSet.schedule_slot);

                    newsche = true;
                    button1.Text = "Save";
                    slot_dateDateTimePicker.Enabled = true;
                }
                catch (Exception)
                {

                    throw;
                }
            }


        }


        private void W(object sender, EventArgs e)
        {
            schedule_slotBindingSource1.EndEdit();
            schedule_slotTableAdapter1.Update(nurseSingleDataSet.schedule_slot);
            schedule_slotTableAdapter.Fill(nurseDataSet.schedule_slot);
        }
    }
}
