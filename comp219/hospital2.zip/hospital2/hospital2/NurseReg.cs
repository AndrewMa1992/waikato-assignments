﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital2
{
    public partial class NurseReg : Form
    {
        public NurseReg()
        {
            InitializeComponent();
        }

        private void nurseBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.nurseBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.nurseSingleDataSet);

        }

        private void NursePatient_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nurseSingleDataSet.Nurse' table. You can move, or remove it, as needed.
            this.nurseTableAdapter.Fill(this.nurseSingleDataSet.Nurse);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool su = false;
            try
            {
                int ID = 0;
                DataRow newrow1 = nurseSingleDataSet.Nurse.NewRow();
                if (nurseSingleDataSet.Tables["Nurse"].Rows.Count != 0)
                {
                    ID = Convert.ToInt16(nurseSingleDataSet.Tables["Nurse"].Rows[nurseSingleDataSet.Tables["Nurse"].Rows.Count - 1].ItemArray[0]) + 1;
                }
                else
                {
                    ID = 1;
                }
                newrow1["n_id"] = ID;
                newrow1["nfname"] = nfnameTextBox.Text;
                newrow1["nlname"] = nlnameTextBox.Text;
                newrow1["d_username"] = d_usernameTextBox.Text;
                newrow1["d_password"] = d_passwordTextBox.Text;
                nurseSingleDataSet.Nurse.Rows.Add(newrow1);
                nurseTableAdapter.Update(nurseSingleDataSet.Nurse);
            }
            catch (Exception)
            {
                MessageBox.Show("fail to add data, please try again");
                throw;
            }
            if (su)
            {
                MessageBox.Show("Successful. Please Login in");
            }
        }
    }
}
