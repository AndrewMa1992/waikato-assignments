﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace assignment2
{
    class Cube : Contents
    {
        public Cube(Color putcolor):base()
        {
            insidecolor = putcolor;
        }
        public override void Draw()
        {
            if (this.boundedBox != null)
            {
                this.boundedBox.BackColor = insidecolor;
            }
            
            
        }
    }
}
