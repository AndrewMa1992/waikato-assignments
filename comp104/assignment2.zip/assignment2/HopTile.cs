﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace assignment2
{
    class HopTile:Contents
    {

        private int value = 0;
        public int Value { get { return value; } }
        public enum stateofHopTiles { High, Low }
        /// <summary>
        /// state of the hop tiles, high or low
        /// </summary>
        private stateofHopTiles state;
        public stateofHopTiles State { get { return state; } set { state = value; } }

        private List<Cube> cubesInside;
        public List<Cube> Cubes { get { return cubesInside; } set { cubesInside = value; } }

        /// <summary>
        /// cards been placed in the slots on the user's side
        /// </summary>
        private List<Card> cardsOnPlayer;
        public List<Card> CardsOnPlayer { get { return cardsOnPlayer; } set { cardsOnPlayer = value; } }

        /// <summary>
        /// cards been placed in the slots on the PC's side
        /// </summary>
        private List<Card> cardsOnPC;
        public List<Card> CardsOnPC { get { return cardsOnPC; } set { cardsOnPC = value; } }

        public HopTile(stateofHopTiles putstate,int num,PictureBox pictbox, Label lab):base()
        {
            value = num;
            state = putstate;
            boundedBox = pictbox;
            boundedLabel = lab;
            cubesInside = new List<Cube>();
            cardsOnPlayer = new List<Card>();
            cardsOnPC = new List<Card>();
           
        }
        public override void Draw()
        {
            string StringState = state.ToString("F");
            this.boundedLabel.Text = StringState;
            this.boundedBox.BackColor = Color.LightGray;
            foreach (Cube item in cubesInside)
            {
                item.Draw();
            }
            foreach (Card item in cardsOnPC)
            {
                item.Draw();
            }
            foreach (Card item in cardsOnPlayer)
            {
                item.Draw();
            }
        }
    }
}
