﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace assignment2
{
    public class Card : Contents
    {
        protected int number = 0;
        public int Value { get { return number; } set { number = value; } }

        public Card(Color putcolor, int num) : base()
        {
            number = num;
            insidecolor = putcolor;
        }
        
        public Card(Color putcolor, int num, PictureBox pictbox, Label lab)
            : base()
        {
            number = num;
            insidecolor = putcolor;
            boundedBox = pictbox;
            boundedLabel = lab;
        }
        public override void Draw()
        {
            this.boundedBox.BackColor = insidecolor;
            this.boundedLabel.Text = number.ToString();
        }
    }
}
