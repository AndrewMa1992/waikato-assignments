﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace assignment2
{
    class TrophyCard:Contents
    {
        private int numberOfCubesNeeded = 0;
        public int NumberOfCubesNeeded { get { return numberOfCubesNeeded; } set { numberOfCubesNeeded = value; } }

        private int numberOwned = 0;
        public int NumberOwned { get { return numberOwned; } set { numberOwned = value; } }

        private Label boundedLabelOwn;
        public Label BoundedLabelOwn { get { return boundedLabelOwn; } set { boundedLabelOwn = value; } }
        public TrophyCard(int num, Color putcolor):base()
        {
            numberOfCubesNeeded = num;
            insidecolor = putcolor;
            
        }
        public override void Draw()
        {
            this.boundedBox.BackColor = insidecolor;
            this.boundedLabel.Text = numberOfCubesNeeded.ToString();
            this.boundedLabelOwn.Text = numberOwned.ToString();
        }
    }
}
