﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    class Computer : Player
    {
        public Computer()
            : base()
        {
            name = "Computer";
        }
    }
}
