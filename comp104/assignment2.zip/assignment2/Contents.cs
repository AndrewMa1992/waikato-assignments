﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace assignment2
{
    public abstract class Contents
    {
        /// <summary>
        /// bounded picturebox of each instance. so that when the Draw() of he instance is called, it changes the back color of the pic box to represend the color of the card or cube
        /// </summary>
        protected PictureBox boundedBox;
        public PictureBox BoundedBox { get { return boundedBox; } set { boundedBox = value; } }

        /// <summary>
        /// bounded label of each instance, when Draw(), it changes the in respond to the value of the card
        /// </summary>
        protected Label boundedLabel;
        public Label BoundedLabel { get { return boundedLabel; } set { boundedLabel = value; } }

        protected Color insidecolor = Color.Black;

        public Color Colour { get { return insidecolor; } set { insidecolor = value; } }
        public Contents()
        {
            
        }
        public abstract void Draw();
    }
}
