﻿namespace assignment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TrophyLabelOwn5 = new System.Windows.Forms.Label();
            this.TrophyLabel5 = new System.Windows.Forms.Label();
            this.Trophy5 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn4 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn3 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn2 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TrophyLabel4 = new System.Windows.Forms.Label();
            this.TrophyLabel3 = new System.Windows.Forms.Label();
            this.TrophyLabel2 = new System.Windows.Forms.Label();
            this.TrophyLabel1 = new System.Windows.Forms.Label();
            this.Trophy1 = new System.Windows.Forms.PictureBox();
            this.Trophy4 = new System.Windows.Forms.PictureBox();
            this.Trophy3 = new System.Windows.Forms.PictureBox();
            this.Trophy2 = new System.Windows.Forms.PictureBox();
            this.btnReshuffle = new System.Windows.Forms.Button();
            this.computerDeckLabel8 = new System.Windows.Forms.Label();
            this.computerDeckLabel7 = new System.Windows.Forms.Label();
            this.computerDeckLabel6 = new System.Windows.Forms.Label();
            this.computerDeckLabel5 = new System.Windows.Forms.Label();
            this.computerDeckLabel4 = new System.Windows.Forms.Label();
            this.computerDeckLabel3 = new System.Windows.Forms.Label();
            this.computerDeckLabel2 = new System.Windows.Forms.Label();
            this.computerDeckLabel1 = new System.Windows.Forms.Label();
            this.computerDeck1 = new System.Windows.Forms.PictureBox();
            this.computerDeck2 = new System.Windows.Forms.PictureBox();
            this.computerDeck3 = new System.Windows.Forms.PictureBox();
            this.computerDeck4 = new System.Windows.Forms.PictureBox();
            this.computerDeck5 = new System.Windows.Forms.PictureBox();
            this.computerDeck6 = new System.Windows.Forms.PictureBox();
            this.computerDeck7 = new System.Windows.Forms.PictureBox();
            this.computerDeck8 = new System.Windows.Forms.PictureBox();
            this.humanDeckLabel5 = new System.Windows.Forms.Label();
            this.humanDeck5 = new System.Windows.Forms.PictureBox();
            this.HopTile3_Cubes3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes2 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile3_Cubes2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_Cubes2 = new System.Windows.Forms.PictureBox();
            this.HopTile2_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile1_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile1_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile3_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile3_hLabel3 = new System.Windows.Forms.Label();
            this.HopTile3_hLabel2 = new System.Windows.Forms.Label();
            this.HopTile2_hLabel2 = new System.Windows.Forms.Label();
            this.HopTile2_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel4 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel3 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel2 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel4 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel3 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel2 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile3_cLabel3 = new System.Windows.Forms.Label();
            this.HopTile3_cLabel2 = new System.Windows.Forms.Label();
            this.HopTile3_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile2_cLabel2 = new System.Windows.Forms.Label();
            this.HopTile2_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile1_cLabel1 = new System.Windows.Forms.Label();
            this.HopTileLabel4 = new System.Windows.Forms.Label();
            this.HopTileLabel2 = new System.Windows.Forms.Label();
            this.HopTileLabel3 = new System.Windows.Forms.Label();
            this.HopTileLabel1 = new System.Windows.Forms.Label();
            this.humanDeckLabel8 = new System.Windows.Forms.Label();
            this.humanDeckLabel7 = new System.Windows.Forms.Label();
            this.humanDeckLabel6 = new System.Windows.Forms.Label();
            this.humanDeckLabel4 = new System.Windows.Forms.Label();
            this.humanDeckLabel3 = new System.Windows.Forms.Label();
            this.humanDeckLabel2 = new System.Windows.Forms.Label();
            this.humanDeckLabel1 = new System.Windows.Forms.Label();
            this.humanDeckl1 = new System.Windows.Forms.Label();
            this.HopTile1_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_c2 = new System.Windows.Forms.PictureBox();
            this.HopTile2_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile1_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_h2 = new System.Windows.Forms.PictureBox();
            this.HopTile2_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile3_h3 = new System.Windows.Forms.PictureBox();
            this.HopTile3_h2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile3_c3 = new System.Windows.Forms.PictureBox();
            this.HopTile3_c2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h2 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c2 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile4 = new System.Windows.Forms.PictureBox();
            this.HopTile3 = new System.Windows.Forms.PictureBox();
            this.HopTile2 = new System.Windows.Forms.PictureBox();
            this.HopTile1 = new System.Windows.Forms.PictureBox();
            this.humanDeck1 = new System.Windows.Forms.PictureBox();
            this.humanDeck2 = new System.Windows.Forms.PictureBox();
            this.humanDeck3 = new System.Windows.Forms.PictureBox();
            this.humanDeck4 = new System.Windows.Forms.PictureBox();
            this.humanDeck6 = new System.Windows.Forms.PictureBox();
            this.humanDeck7 = new System.Windows.Forms.PictureBox();
            this.humanDeck8 = new System.Windows.Forms.PictureBox();
            this.CubeshumanTextBox = new System.Windows.Forms.TextBox();
            this.ThreeForOne = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DeckTextBox = new System.Windows.Forms.TextBox();
            this.CubeTextBox = new System.Windows.Forms.TextBox();
            this.GraveyardTextBox = new System.Windows.Forms.TextBox();
            this.CubesComputerTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck8)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TrophyLabelOwn5
            // 
            this.TrophyLabelOwn5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabelOwn5.AutoSize = true;
            this.TrophyLabelOwn5.Location = new System.Drawing.Point(1166, 438);
            this.TrophyLabelOwn5.Name = "TrophyLabelOwn5";
            this.TrophyLabelOwn5.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn5.TabIndex = 256;
            this.TrophyLabelOwn5.Text = "1";
            // 
            // TrophyLabel5
            // 
            this.TrophyLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabel5.AutoSize = true;
            this.TrophyLabel5.Location = new System.Drawing.Point(1044, 401);
            this.TrophyLabel5.Name = "TrophyLabel5";
            this.TrophyLabel5.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel5.TabIndex = 255;
            this.TrophyLabel5.Text = "1";
            // 
            // Trophy5
            // 
            this.Trophy5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Trophy5.Location = new System.Drawing.Point(1047, 401);
            this.Trophy5.Name = "Trophy5";
            this.Trophy5.Size = new System.Drawing.Size(100, 50);
            this.Trophy5.TabIndex = 254;
            this.Trophy5.TabStop = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1138, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 20);
            this.label5.TabIndex = 253;
            this.label5.Text = "Own";
            // 
            // TrophyLabelOwn4
            // 
            this.TrophyLabelOwn4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabelOwn4.AutoSize = true;
            this.TrophyLabelOwn4.Location = new System.Drawing.Point(1166, 367);
            this.TrophyLabelOwn4.Name = "TrophyLabelOwn4";
            this.TrophyLabelOwn4.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn4.TabIndex = 252;
            this.TrophyLabelOwn4.Text = "1";
            // 
            // TrophyLabelOwn3
            // 
            this.TrophyLabelOwn3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabelOwn3.AutoSize = true;
            this.TrophyLabelOwn3.Location = new System.Drawing.Point(1166, 290);
            this.TrophyLabelOwn3.Name = "TrophyLabelOwn3";
            this.TrophyLabelOwn3.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn3.TabIndex = 251;
            this.TrophyLabelOwn3.Text = "1";
            // 
            // TrophyLabelOwn2
            // 
            this.TrophyLabelOwn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabelOwn2.AutoSize = true;
            this.TrophyLabelOwn2.Location = new System.Drawing.Point(1166, 214);
            this.TrophyLabelOwn2.Name = "TrophyLabelOwn2";
            this.TrophyLabelOwn2.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn2.TabIndex = 250;
            this.TrophyLabelOwn2.Text = "1";
            // 
            // TrophyLabelOwn1
            // 
            this.TrophyLabelOwn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabelOwn1.AutoSize = true;
            this.TrophyLabelOwn1.Location = new System.Drawing.Point(1166, 148);
            this.TrophyLabelOwn1.Name = "TrophyLabelOwn1";
            this.TrophyLabelOwn1.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn1.TabIndex = 249;
            this.TrophyLabelOwn1.Text = "1";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1043, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 20);
            this.label6.TabIndex = 248;
            this.label6.Text = "Trophies";
            // 
            // TrophyLabel4
            // 
            this.TrophyLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabel4.AutoSize = true;
            this.TrophyLabel4.Location = new System.Drawing.Point(1044, 330);
            this.TrophyLabel4.Name = "TrophyLabel4";
            this.TrophyLabel4.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel4.TabIndex = 247;
            this.TrophyLabel4.Text = "1";
            // 
            // TrophyLabel3
            // 
            this.TrophyLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabel3.AutoSize = true;
            this.TrophyLabel3.Location = new System.Drawing.Point(1044, 253);
            this.TrophyLabel3.Name = "TrophyLabel3";
            this.TrophyLabel3.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel3.TabIndex = 246;
            this.TrophyLabel3.Text = "1";
            // 
            // TrophyLabel2
            // 
            this.TrophyLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabel2.AutoSize = true;
            this.TrophyLabel2.Location = new System.Drawing.Point(1044, 177);
            this.TrophyLabel2.Name = "TrophyLabel2";
            this.TrophyLabel2.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel2.TabIndex = 245;
            this.TrophyLabel2.Text = "1";
            // 
            // TrophyLabel1
            // 
            this.TrophyLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TrophyLabel1.AutoSize = true;
            this.TrophyLabel1.Location = new System.Drawing.Point(1044, 111);
            this.TrophyLabel1.Name = "TrophyLabel1";
            this.TrophyLabel1.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel1.TabIndex = 244;
            this.TrophyLabel1.Text = "1";
            // 
            // Trophy1
            // 
            this.Trophy1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Trophy1.Location = new System.Drawing.Point(1047, 111);
            this.Trophy1.Name = "Trophy1";
            this.Trophy1.Size = new System.Drawing.Size(100, 50);
            this.Trophy1.TabIndex = 243;
            this.Trophy1.TabStop = false;
            // 
            // Trophy4
            // 
            this.Trophy4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Trophy4.Location = new System.Drawing.Point(1047, 330);
            this.Trophy4.Name = "Trophy4";
            this.Trophy4.Size = new System.Drawing.Size(100, 50);
            this.Trophy4.TabIndex = 242;
            this.Trophy4.TabStop = false;
            // 
            // Trophy3
            // 
            this.Trophy3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Trophy3.Location = new System.Drawing.Point(1047, 253);
            this.Trophy3.Name = "Trophy3";
            this.Trophy3.Size = new System.Drawing.Size(100, 50);
            this.Trophy3.TabIndex = 241;
            this.Trophy3.TabStop = false;
            // 
            // Trophy2
            // 
            this.Trophy2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Trophy2.Location = new System.Drawing.Point(1047, 177);
            this.Trophy2.Name = "Trophy2";
            this.Trophy2.Size = new System.Drawing.Size(100, 50);
            this.Trophy2.TabIndex = 240;
            this.Trophy2.TabStop = false;
            // 
            // btnReshuffle
            // 
            this.btnReshuffle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReshuffle.Enabled = false;
            this.btnReshuffle.Location = new System.Drawing.Point(1051, 539);
            this.btnReshuffle.Name = "btnReshuffle";
            this.btnReshuffle.Size = new System.Drawing.Size(96, 23);
            this.btnReshuffle.TabIndex = 239;
            this.btnReshuffle.Text = "Finish Reshuffle";
            this.btnReshuffle.UseVisualStyleBackColor = true;
            this.btnReshuffle.Click += new System.EventHandler(this.btnReshuffle_Click);
            // 
            // computerDeckLabel8
            // 
            this.computerDeckLabel8.AutoSize = true;
            this.computerDeckLabel8.Location = new System.Drawing.Point(701, 55);
            this.computerDeckLabel8.Name = "computerDeckLabel8";
            this.computerDeckLabel8.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel8.TabIndex = 204;
            this.computerDeckLabel8.Text = "1";
            // 
            // computerDeckLabel7
            // 
            this.computerDeckLabel7.AutoSize = true;
            this.computerDeckLabel7.Location = new System.Drawing.Point(603, 55);
            this.computerDeckLabel7.Name = "computerDeckLabel7";
            this.computerDeckLabel7.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel7.TabIndex = 203;
            this.computerDeckLabel7.Text = "1";
            // 
            // computerDeckLabel6
            // 
            this.computerDeckLabel6.AutoSize = true;
            this.computerDeckLabel6.Location = new System.Drawing.Point(507, 55);
            this.computerDeckLabel6.Name = "computerDeckLabel6";
            this.computerDeckLabel6.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel6.TabIndex = 202;
            this.computerDeckLabel6.Text = "1";
            // 
            // computerDeckLabel5
            // 
            this.computerDeckLabel5.AutoSize = true;
            this.computerDeckLabel5.Location = new System.Drawing.Point(409, 55);
            this.computerDeckLabel5.Name = "computerDeckLabel5";
            this.computerDeckLabel5.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel5.TabIndex = 201;
            this.computerDeckLabel5.Text = "1";
            // 
            // computerDeckLabel4
            // 
            this.computerDeckLabel4.AutoSize = true;
            this.computerDeckLabel4.Location = new System.Drawing.Point(319, 55);
            this.computerDeckLabel4.Name = "computerDeckLabel4";
            this.computerDeckLabel4.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel4.TabIndex = 200;
            this.computerDeckLabel4.Text = "1";
            // 
            // computerDeckLabel3
            // 
            this.computerDeckLabel3.AutoSize = true;
            this.computerDeckLabel3.Location = new System.Drawing.Point(221, 55);
            this.computerDeckLabel3.Name = "computerDeckLabel3";
            this.computerDeckLabel3.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel3.TabIndex = 199;
            this.computerDeckLabel3.Text = "1";
            // 
            // computerDeckLabel2
            // 
            this.computerDeckLabel2.AutoSize = true;
            this.computerDeckLabel2.Location = new System.Drawing.Point(125, 55);
            this.computerDeckLabel2.Name = "computerDeckLabel2";
            this.computerDeckLabel2.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel2.TabIndex = 198;
            this.computerDeckLabel2.Text = "1";
            // 
            // computerDeckLabel1
            // 
            this.computerDeckLabel1.AutoSize = true;
            this.computerDeckLabel1.Location = new System.Drawing.Point(27, 55);
            this.computerDeckLabel1.Name = "computerDeckLabel1";
            this.computerDeckLabel1.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel1.TabIndex = 197;
            this.computerDeckLabel1.Text = "1";
            // 
            // computerDeck1
            // 
            this.computerDeck1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck1.Location = new System.Drawing.Point(28, 41);
            this.computerDeck1.Name = "computerDeck1";
            this.computerDeck1.Size = new System.Drawing.Size(90, 120);
            this.computerDeck1.TabIndex = 163;
            this.computerDeck1.TabStop = false;
            // 
            // computerDeck2
            // 
            this.computerDeck2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck2.Location = new System.Drawing.Point(123, 41);
            this.computerDeck2.Name = "computerDeck2";
            this.computerDeck2.Size = new System.Drawing.Size(90, 120);
            this.computerDeck2.TabIndex = 162;
            this.computerDeck2.TabStop = false;
            // 
            // computerDeck3
            // 
            this.computerDeck3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck3.Location = new System.Drawing.Point(218, 41);
            this.computerDeck3.Name = "computerDeck3";
            this.computerDeck3.Size = new System.Drawing.Size(90, 120);
            this.computerDeck3.TabIndex = 161;
            this.computerDeck3.TabStop = false;
            // 
            // computerDeck4
            // 
            this.computerDeck4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck4.Location = new System.Drawing.Point(313, 41);
            this.computerDeck4.Name = "computerDeck4";
            this.computerDeck4.Size = new System.Drawing.Size(90, 120);
            this.computerDeck4.TabIndex = 160;
            this.computerDeck4.TabStop = false;
            // 
            // computerDeck5
            // 
            this.computerDeck5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck5.Location = new System.Drawing.Point(408, 41);
            this.computerDeck5.Name = "computerDeck5";
            this.computerDeck5.Size = new System.Drawing.Size(90, 120);
            this.computerDeck5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.computerDeck5.TabIndex = 159;
            this.computerDeck5.TabStop = false;
            // 
            // computerDeck6
            // 
            this.computerDeck6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck6.Location = new System.Drawing.Point(503, 41);
            this.computerDeck6.Name = "computerDeck6";
            this.computerDeck6.Size = new System.Drawing.Size(90, 120);
            this.computerDeck6.TabIndex = 158;
            this.computerDeck6.TabStop = false;
            // 
            // computerDeck7
            // 
            this.computerDeck7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck7.Location = new System.Drawing.Point(598, 41);
            this.computerDeck7.Name = "computerDeck7";
            this.computerDeck7.Size = new System.Drawing.Size(90, 120);
            this.computerDeck7.TabIndex = 157;
            this.computerDeck7.TabStop = false;
            // 
            // computerDeck8
            // 
            this.computerDeck8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck8.Location = new System.Drawing.Point(693, 41);
            this.computerDeck8.Name = "computerDeck8";
            this.computerDeck8.Size = new System.Drawing.Size(90, 120);
            this.computerDeck8.TabIndex = 156;
            this.computerDeck8.TabStop = false;
            // 
            // humanDeckLabel5
            // 
            this.humanDeckLabel5.AutoSize = true;
            this.humanDeckLabel5.Location = new System.Drawing.Point(409, 453);
            this.humanDeckLabel5.Name = "humanDeckLabel5";
            this.humanDeckLabel5.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel5.TabIndex = 294;
            this.humanDeckLabel5.Text = "1";
            // 
            // humanDeck5
            // 
            this.humanDeck5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck5.Location = new System.Drawing.Point(409, 442);
            this.humanDeck5.Name = "humanDeck5";
            this.humanDeck5.Size = new System.Drawing.Size(90, 120);
            this.humanDeck5.TabIndex = 260;
            this.humanDeck5.TabStop = false;
            // 
            // HopTile3_Cubes3
            // 
            this.HopTile3_Cubes3.Location = new System.Drawing.Point(503, 275);
            this.HopTile3_Cubes3.Name = "HopTile3_Cubes3";
            this.HopTile3_Cubes3.Size = new System.Drawing.Size(30, 30);
            this.HopTile3_Cubes3.TabIndex = 331;
            this.HopTile3_Cubes3.TabStop = false;
            // 
            // HopTile4_Cubes4
            // 
            this.HopTile4_Cubes4.Location = new System.Drawing.Point(731, 275);
            this.HopTile4_Cubes4.Name = "HopTile4_Cubes4";
            this.HopTile4_Cubes4.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes4.TabIndex = 330;
            this.HopTile4_Cubes4.TabStop = false;
            // 
            // HopTile4_Cubes3
            // 
            this.HopTile4_Cubes3.Location = new System.Drawing.Point(695, 275);
            this.HopTile4_Cubes3.Name = "HopTile4_Cubes3";
            this.HopTile4_Cubes3.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes3.TabIndex = 329;
            this.HopTile4_Cubes3.TabStop = false;
            // 
            // HopTile4_Cubes2
            // 
            this.HopTile4_Cubes2.Location = new System.Drawing.Point(657, 275);
            this.HopTile4_Cubes2.Name = "HopTile4_Cubes2";
            this.HopTile4_Cubes2.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes2.TabIndex = 328;
            this.HopTile4_Cubes2.TabStop = false;
            // 
            // HopTile4_Cubes1
            // 
            this.HopTile4_Cubes1.Location = new System.Drawing.Point(621, 275);
            this.HopTile4_Cubes1.Name = "HopTile4_Cubes1";
            this.HopTile4_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes1.TabIndex = 327;
            this.HopTile4_Cubes1.TabStop = false;
            // 
            // HopTile3_Cubes2
            // 
            this.HopTile3_Cubes2.Location = new System.Drawing.Point(466, 275);
            this.HopTile3_Cubes2.Name = "HopTile3_Cubes2";
            this.HopTile3_Cubes2.Size = new System.Drawing.Size(30, 30);
            this.HopTile3_Cubes2.TabIndex = 326;
            this.HopTile3_Cubes2.TabStop = false;
            // 
            // HopTile3_Cubes1
            // 
            this.HopTile3_Cubes1.Location = new System.Drawing.Point(430, 275);
            this.HopTile3_Cubes1.Name = "HopTile3_Cubes1";
            this.HopTile3_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile3_Cubes1.TabIndex = 325;
            this.HopTile3_Cubes1.TabStop = false;
            // 
            // HopTile2_Cubes2
            // 
            this.HopTile2_Cubes2.Location = new System.Drawing.Point(271, 275);
            this.HopTile2_Cubes2.Name = "HopTile2_Cubes2";
            this.HopTile2_Cubes2.Size = new System.Drawing.Size(30, 30);
            this.HopTile2_Cubes2.TabIndex = 324;
            this.HopTile2_Cubes2.TabStop = false;
            // 
            // HopTile2_Cubes1
            // 
            this.HopTile2_Cubes1.Location = new System.Drawing.Point(235, 275);
            this.HopTile2_Cubes1.Name = "HopTile2_Cubes1";
            this.HopTile2_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile2_Cubes1.TabIndex = 323;
            this.HopTile2_Cubes1.TabStop = false;
            // 
            // HopTile1_Cubes1
            // 
            this.HopTile1_Cubes1.Location = new System.Drawing.Point(44, 275);
            this.HopTile1_Cubes1.Name = "HopTile1_Cubes1";
            this.HopTile1_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile1_Cubes1.TabIndex = 322;
            this.HopTile1_Cubes1.TabStop = false;
            // 
            // HopTile1_hLabel1
            // 
            this.HopTile1_hLabel1.AutoSize = true;
            this.HopTile1_hLabel1.Location = new System.Drawing.Point(25, 353);
            this.HopTile1_hLabel1.Name = "HopTile1_hLabel1";
            this.HopTile1_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile1_hLabel1.TabIndex = 321;
            this.HopTile1_hLabel1.Text = "1";
            // 
            // HopTile3_hLabel1
            // 
            this.HopTile3_hLabel1.AutoSize = true;
            this.HopTile3_hLabel1.Location = new System.Drawing.Point(412, 353);
            this.HopTile3_hLabel1.Name = "HopTile3_hLabel1";
            this.HopTile3_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_hLabel1.TabIndex = 320;
            this.HopTile3_hLabel1.Text = "1";
            // 
            // HopTile3_hLabel3
            // 
            this.HopTile3_hLabel3.AutoSize = true;
            this.HopTile3_hLabel3.Location = new System.Drawing.Point(484, 353);
            this.HopTile3_hLabel3.Name = "HopTile3_hLabel3";
            this.HopTile3_hLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_hLabel3.TabIndex = 319;
            this.HopTile3_hLabel3.Text = "1";
            // 
            // HopTile3_hLabel2
            // 
            this.HopTile3_hLabel2.AutoSize = true;
            this.HopTile3_hLabel2.Location = new System.Drawing.Point(447, 353);
            this.HopTile3_hLabel2.Name = "HopTile3_hLabel2";
            this.HopTile3_hLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_hLabel2.TabIndex = 318;
            this.HopTile3_hLabel2.Text = "1";
            // 
            // HopTile2_hLabel2
            // 
            this.HopTile2_hLabel2.AutoSize = true;
            this.HopTile2_hLabel2.Location = new System.Drawing.Point(254, 353);
            this.HopTile2_hLabel2.Name = "HopTile2_hLabel2";
            this.HopTile2_hLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_hLabel2.TabIndex = 317;
            this.HopTile2_hLabel2.Text = "1";
            // 
            // HopTile2_hLabel1
            // 
            this.HopTile2_hLabel1.AutoSize = true;
            this.HopTile2_hLabel1.Location = new System.Drawing.Point(217, 353);
            this.HopTile2_hLabel1.Name = "HopTile2_hLabel1";
            this.HopTile2_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_hLabel1.TabIndex = 316;
            this.HopTile2_hLabel1.Text = "1";
            // 
            // HopTile4_hLabel4
            // 
            this.HopTile4_hLabel4.AutoSize = true;
            this.HopTile4_hLabel4.Location = new System.Drawing.Point(708, 353);
            this.HopTile4_hLabel4.Name = "HopTile4_hLabel4";
            this.HopTile4_hLabel4.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel4.TabIndex = 315;
            this.HopTile4_hLabel4.Text = "1";
            // 
            // HopTile4_hLabel3
            // 
            this.HopTile4_hLabel3.AutoSize = true;
            this.HopTile4_hLabel3.Location = new System.Drawing.Point(671, 353);
            this.HopTile4_hLabel3.Name = "HopTile4_hLabel3";
            this.HopTile4_hLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel3.TabIndex = 314;
            this.HopTile4_hLabel3.Text = "1";
            // 
            // HopTile4_hLabel2
            // 
            this.HopTile4_hLabel2.AutoSize = true;
            this.HopTile4_hLabel2.Location = new System.Drawing.Point(638, 353);
            this.HopTile4_hLabel2.Name = "HopTile4_hLabel2";
            this.HopTile4_hLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel2.TabIndex = 313;
            this.HopTile4_hLabel2.Text = "1";
            // 
            // HopTile4_hLabel1
            // 
            this.HopTile4_hLabel1.AutoSize = true;
            this.HopTile4_hLabel1.Location = new System.Drawing.Point(601, 353);
            this.HopTile4_hLabel1.Name = "HopTile4_hLabel1";
            this.HopTile4_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel1.TabIndex = 312;
            this.HopTile4_hLabel1.Text = "1";
            // 
            // HopTile4_cLabel4
            // 
            this.HopTile4_cLabel4.AutoSize = true;
            this.HopTile4_cLabel4.Location = new System.Drawing.Point(708, 181);
            this.HopTile4_cLabel4.Name = "HopTile4_cLabel4";
            this.HopTile4_cLabel4.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel4.TabIndex = 311;
            this.HopTile4_cLabel4.Text = "1";
            // 
            // HopTile4_cLabel3
            // 
            this.HopTile4_cLabel3.AutoSize = true;
            this.HopTile4_cLabel3.Location = new System.Drawing.Point(671, 181);
            this.HopTile4_cLabel3.Name = "HopTile4_cLabel3";
            this.HopTile4_cLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel3.TabIndex = 310;
            this.HopTile4_cLabel3.Text = "1";
            // 
            // HopTile4_cLabel2
            // 
            this.HopTile4_cLabel2.AutoSize = true;
            this.HopTile4_cLabel2.Location = new System.Drawing.Point(638, 181);
            this.HopTile4_cLabel2.Name = "HopTile4_cLabel2";
            this.HopTile4_cLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel2.TabIndex = 309;
            this.HopTile4_cLabel2.Text = "1";
            // 
            // HopTile4_cLabel1
            // 
            this.HopTile4_cLabel1.AutoSize = true;
            this.HopTile4_cLabel1.Location = new System.Drawing.Point(601, 181);
            this.HopTile4_cLabel1.Name = "HopTile4_cLabel1";
            this.HopTile4_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel1.TabIndex = 308;
            this.HopTile4_cLabel1.Text = "1";
            // 
            // HopTile3_cLabel3
            // 
            this.HopTile3_cLabel3.AutoSize = true;
            this.HopTile3_cLabel3.Location = new System.Drawing.Point(484, 181);
            this.HopTile3_cLabel3.Name = "HopTile3_cLabel3";
            this.HopTile3_cLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_cLabel3.TabIndex = 307;
            this.HopTile3_cLabel3.Text = "1";
            // 
            // HopTile3_cLabel2
            // 
            this.HopTile3_cLabel2.AutoSize = true;
            this.HopTile3_cLabel2.Location = new System.Drawing.Point(447, 181);
            this.HopTile3_cLabel2.Name = "HopTile3_cLabel2";
            this.HopTile3_cLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_cLabel2.TabIndex = 306;
            this.HopTile3_cLabel2.Text = "1";
            // 
            // HopTile3_cLabel1
            // 
            this.HopTile3_cLabel1.AutoSize = true;
            this.HopTile3_cLabel1.Location = new System.Drawing.Point(412, 181);
            this.HopTile3_cLabel1.Name = "HopTile3_cLabel1";
            this.HopTile3_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_cLabel1.TabIndex = 305;
            this.HopTile3_cLabel1.Text = "1";
            // 
            // HopTile2_cLabel2
            // 
            this.HopTile2_cLabel2.AutoSize = true;
            this.HopTile2_cLabel2.Location = new System.Drawing.Point(252, 181);
            this.HopTile2_cLabel2.Name = "HopTile2_cLabel2";
            this.HopTile2_cLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_cLabel2.TabIndex = 304;
            this.HopTile2_cLabel2.Text = "1";
            // 
            // HopTile2_cLabel1
            // 
            this.HopTile2_cLabel1.AutoSize = true;
            this.HopTile2_cLabel1.Location = new System.Drawing.Point(215, 181);
            this.HopTile2_cLabel1.Name = "HopTile2_cLabel1";
            this.HopTile2_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_cLabel1.TabIndex = 303;
            this.HopTile2_cLabel1.Text = "1";
            // 
            // HopTile1_cLabel1
            // 
            this.HopTile1_cLabel1.AutoSize = true;
            this.HopTile1_cLabel1.Location = new System.Drawing.Point(27, 181);
            this.HopTile1_cLabel1.Name = "HopTile1_cLabel1";
            this.HopTile1_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile1_cLabel1.TabIndex = 302;
            this.HopTile1_cLabel1.Text = "1";
            // 
            // HopTileLabel4
            // 
            this.HopTileLabel4.AutoSize = true;
            this.HopTileLabel4.Location = new System.Drawing.Point(601, 243);
            this.HopTileLabel4.Name = "HopTileLabel4";
            this.HopTileLabel4.Size = new System.Drawing.Size(27, 13);
            this.HopTileLabel4.TabIndex = 301;
            this.HopTileLabel4.Text = "Low";
            // 
            // HopTileLabel2
            // 
            this.HopTileLabel2.AutoSize = true;
            this.HopTileLabel2.Location = new System.Drawing.Point(219, 243);
            this.HopTileLabel2.Name = "HopTileLabel2";
            this.HopTileLabel2.Size = new System.Drawing.Size(27, 13);
            this.HopTileLabel2.TabIndex = 300;
            this.HopTileLabel2.Text = "Low";
            // 
            // HopTileLabel3
            // 
            this.HopTileLabel3.AutoSize = true;
            this.HopTileLabel3.Location = new System.Drawing.Point(412, 243);
            this.HopTileLabel3.Name = "HopTileLabel3";
            this.HopTileLabel3.Size = new System.Drawing.Size(29, 13);
            this.HopTileLabel3.TabIndex = 299;
            this.HopTileLabel3.Text = "High";
            // 
            // HopTileLabel1
            // 
            this.HopTileLabel1.AutoSize = true;
            this.HopTileLabel1.Location = new System.Drawing.Point(29, 243);
            this.HopTileLabel1.Name = "HopTileLabel1";
            this.HopTileLabel1.Size = new System.Drawing.Size(29, 13);
            this.HopTileLabel1.TabIndex = 298;
            this.HopTileLabel1.Text = "High";
            // 
            // humanDeckLabel8
            // 
            this.humanDeckLabel8.AutoSize = true;
            this.humanDeckLabel8.Location = new System.Drawing.Point(701, 453);
            this.humanDeckLabel8.Name = "humanDeckLabel8";
            this.humanDeckLabel8.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel8.TabIndex = 297;
            this.humanDeckLabel8.Text = "1";
            // 
            // humanDeckLabel7
            // 
            this.humanDeckLabel7.AutoSize = true;
            this.humanDeckLabel7.Location = new System.Drawing.Point(603, 453);
            this.humanDeckLabel7.Name = "humanDeckLabel7";
            this.humanDeckLabel7.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel7.TabIndex = 296;
            this.humanDeckLabel7.Text = "1";
            // 
            // humanDeckLabel6
            // 
            this.humanDeckLabel6.AutoSize = true;
            this.humanDeckLabel6.Location = new System.Drawing.Point(507, 453);
            this.humanDeckLabel6.Name = "humanDeckLabel6";
            this.humanDeckLabel6.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel6.TabIndex = 295;
            this.humanDeckLabel6.Text = "1";
            // 
            // humanDeckLabel4
            // 
            this.humanDeckLabel4.AutoSize = true;
            this.humanDeckLabel4.Location = new System.Drawing.Point(317, 453);
            this.humanDeckLabel4.Name = "humanDeckLabel4";
            this.humanDeckLabel4.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel4.TabIndex = 293;
            this.humanDeckLabel4.Text = "1";
            // 
            // humanDeckLabel3
            // 
            this.humanDeckLabel3.AutoSize = true;
            this.humanDeckLabel3.Location = new System.Drawing.Point(219, 453);
            this.humanDeckLabel3.Name = "humanDeckLabel3";
            this.humanDeckLabel3.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel3.TabIndex = 292;
            this.humanDeckLabel3.Text = "1";
            // 
            // humanDeckLabel2
            // 
            this.humanDeckLabel2.AutoSize = true;
            this.humanDeckLabel2.Location = new System.Drawing.Point(123, 453);
            this.humanDeckLabel2.Name = "humanDeckLabel2";
            this.humanDeckLabel2.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel2.TabIndex = 291;
            this.humanDeckLabel2.Text = "1";
            // 
            // humanDeckLabel1
            // 
            this.humanDeckLabel1.AutoSize = true;
            this.humanDeckLabel1.Location = new System.Drawing.Point(25, 453);
            this.humanDeckLabel1.Name = "humanDeckLabel1";
            this.humanDeckLabel1.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel1.TabIndex = 290;
            this.humanDeckLabel1.Text = "1";
            // 
            // humanDeckl1
            // 
            this.humanDeckl1.AutoSize = true;
            this.humanDeckl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.humanDeckl1.Location = new System.Drawing.Point(40, 453);
            this.humanDeckl1.Name = "humanDeckl1";
            this.humanDeckl1.Size = new System.Drawing.Size(0, 20);
            this.humanDeckl1.TabIndex = 289;
            // 
            // HopTile1_c1
            // 
            this.HopTile1_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile1_c1.Location = new System.Drawing.Point(28, 181);
            this.HopTile1_c1.Name = "HopTile1_c1";
            this.HopTile1_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile1_c1.TabIndex = 288;
            this.HopTile1_c1.TabStop = false;
            // 
            // HopTile2_c2
            // 
            this.HopTile2_c2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_c2.Location = new System.Drawing.Point(252, 181);
            this.HopTile2_c2.Name = "HopTile2_c2";
            this.HopTile2_c2.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_c2.TabIndex = 287;
            this.HopTile2_c2.TabStop = false;
            // 
            // HopTile2_c1
            // 
            this.HopTile2_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_c1.Location = new System.Drawing.Point(215, 181);
            this.HopTile2_c1.Name = "HopTile2_c1";
            this.HopTile2_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_c1.TabIndex = 286;
            this.HopTile2_c1.TabStop = false;
            // 
            // HopTile1_h1
            // 
            this.HopTile1_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile1_h1.Location = new System.Drawing.Point(28, 353);
            this.HopTile1_h1.Name = "HopTile1_h1";
            this.HopTile1_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile1_h1.TabIndex = 285;
            this.HopTile1_h1.TabStop = false;
            // 
            // HopTile2_h2
            // 
            this.HopTile2_h2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_h2.Location = new System.Drawing.Point(255, 353);
            this.HopTile2_h2.Name = "HopTile2_h2";
            this.HopTile2_h2.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_h2.TabIndex = 284;
            this.HopTile2_h2.TabStop = false;
            // 
            // HopTile2_h1
            // 
            this.HopTile2_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_h1.Location = new System.Drawing.Point(218, 353);
            this.HopTile2_h1.Name = "HopTile2_h1";
            this.HopTile2_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_h1.TabIndex = 283;
            this.HopTile2_h1.TabStop = false;
            // 
            // HopTile3_h3
            // 
            this.HopTile3_h3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_h3.Location = new System.Drawing.Point(485, 353);
            this.HopTile3_h3.Name = "HopTile3_h3";
            this.HopTile3_h3.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_h3.TabIndex = 282;
            this.HopTile3_h3.TabStop = false;
            // 
            // HopTile3_h2
            // 
            this.HopTile3_h2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_h2.Location = new System.Drawing.Point(448, 353);
            this.HopTile3_h2.Name = "HopTile3_h2";
            this.HopTile3_h2.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_h2.TabIndex = 281;
            this.HopTile3_h2.TabStop = false;
            // 
            // HopTile3_h1
            // 
            this.HopTile3_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_h1.Location = new System.Drawing.Point(411, 353);
            this.HopTile3_h1.Name = "HopTile3_h1";
            this.HopTile3_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_h1.TabIndex = 280;
            this.HopTile3_h1.TabStop = false;
            // 
            // HopTile3_c3
            // 
            this.HopTile3_c3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_c3.Location = new System.Drawing.Point(485, 181);
            this.HopTile3_c3.Name = "HopTile3_c3";
            this.HopTile3_c3.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_c3.TabIndex = 279;
            this.HopTile3_c3.TabStop = false;
            // 
            // HopTile3_c2
            // 
            this.HopTile3_c2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_c2.Location = new System.Drawing.Point(448, 181);
            this.HopTile3_c2.Name = "HopTile3_c2";
            this.HopTile3_c2.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_c2.TabIndex = 278;
            this.HopTile3_c2.TabStop = false;
            // 
            // HopTile3_c1
            // 
            this.HopTile3_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_c1.Location = new System.Drawing.Point(411, 181);
            this.HopTile3_c1.Name = "HopTile3_c1";
            this.HopTile3_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_c1.TabIndex = 277;
            this.HopTile3_c1.TabStop = false;
            // 
            // HopTile4_h4
            // 
            this.HopTile4_h4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h4.Location = new System.Drawing.Point(709, 353);
            this.HopTile4_h4.Name = "HopTile4_h4";
            this.HopTile4_h4.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h4.TabIndex = 276;
            this.HopTile4_h4.TabStop = false;
            // 
            // HopTile4_h3
            // 
            this.HopTile4_h3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h3.Location = new System.Drawing.Point(672, 353);
            this.HopTile4_h3.Name = "HopTile4_h3";
            this.HopTile4_h3.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h3.TabIndex = 275;
            this.HopTile4_h3.TabStop = false;
            // 
            // HopTile4_h2
            // 
            this.HopTile4_h2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h2.Location = new System.Drawing.Point(635, 353);
            this.HopTile4_h2.Name = "HopTile4_h2";
            this.HopTile4_h2.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h2.TabIndex = 274;
            this.HopTile4_h2.TabStop = false;
            // 
            // HopTile4_h1
            // 
            this.HopTile4_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h1.Location = new System.Drawing.Point(598, 353);
            this.HopTile4_h1.Name = "HopTile4_h1";
            this.HopTile4_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h1.TabIndex = 273;
            this.HopTile4_h1.TabStop = false;
            // 
            // HopTile4_c4
            // 
            this.HopTile4_c4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c4.Location = new System.Drawing.Point(709, 181);
            this.HopTile4_c4.Name = "HopTile4_c4";
            this.HopTile4_c4.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c4.TabIndex = 272;
            this.HopTile4_c4.TabStop = false;
            // 
            // HopTile4_c3
            // 
            this.HopTile4_c3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c3.Location = new System.Drawing.Point(672, 181);
            this.HopTile4_c3.Name = "HopTile4_c3";
            this.HopTile4_c3.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c3.TabIndex = 271;
            this.HopTile4_c3.TabStop = false;
            // 
            // HopTile4_c2
            // 
            this.HopTile4_c2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c2.Location = new System.Drawing.Point(635, 181);
            this.HopTile4_c2.Name = "HopTile4_c2";
            this.HopTile4_c2.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c2.TabIndex = 270;
            this.HopTile4_c2.TabStop = false;
            // 
            // HopTile4_c1
            // 
            this.HopTile4_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c1.Location = new System.Drawing.Point(598, 181);
            this.HopTile4_c1.Name = "HopTile4_c1";
            this.HopTile4_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c1.TabIndex = 269;
            this.HopTile4_c1.TabStop = false;
            // 
            // HopTile4
            // 
            this.HopTile4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4.Location = new System.Drawing.Point(598, 230);
            this.HopTile4.Name = "HopTile4";
            this.HopTile4.Size = new System.Drawing.Size(184, 117);
            this.HopTile4.TabIndex = 268;
            this.HopTile4.TabStop = false;
            // 
            // HopTile3
            // 
            this.HopTile3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3.Location = new System.Drawing.Point(408, 230);
            this.HopTile3.Name = "HopTile3";
            this.HopTile3.Size = new System.Drawing.Size(184, 117);
            this.HopTile3.TabIndex = 267;
            this.HopTile3.TabStop = false;
            // 
            // HopTile2
            // 
            this.HopTile2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2.Location = new System.Drawing.Point(218, 230);
            this.HopTile2.Name = "HopTile2";
            this.HopTile2.Size = new System.Drawing.Size(184, 117);
            this.HopTile2.TabIndex = 266;
            this.HopTile2.TabStop = false;
            // 
            // HopTile1
            // 
            this.HopTile1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile1.Location = new System.Drawing.Point(28, 230);
            this.HopTile1.Name = "HopTile1";
            this.HopTile1.Size = new System.Drawing.Size(184, 117);
            this.HopTile1.TabIndex = 265;
            this.HopTile1.TabStop = false;
            // 
            // humanDeck1
            // 
            this.humanDeck1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck1.Location = new System.Drawing.Point(27, 442);
            this.humanDeck1.Name = "humanDeck1";
            this.humanDeck1.Size = new System.Drawing.Size(90, 120);
            this.humanDeck1.TabIndex = 264;
            this.humanDeck1.TabStop = false;
            // 
            // humanDeck2
            // 
            this.humanDeck2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck2.Location = new System.Drawing.Point(123, 442);
            this.humanDeck2.Name = "humanDeck2";
            this.humanDeck2.Size = new System.Drawing.Size(90, 120);
            this.humanDeck2.TabIndex = 263;
            this.humanDeck2.TabStop = false;
            // 
            // humanDeck3
            // 
            this.humanDeck3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck3.Location = new System.Drawing.Point(218, 442);
            this.humanDeck3.Name = "humanDeck3";
            this.humanDeck3.Size = new System.Drawing.Size(90, 120);
            this.humanDeck3.TabIndex = 262;
            this.humanDeck3.TabStop = false;
            // 
            // humanDeck4
            // 
            this.humanDeck4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck4.Location = new System.Drawing.Point(313, 442);
            this.humanDeck4.Name = "humanDeck4";
            this.humanDeck4.Size = new System.Drawing.Size(90, 120);
            this.humanDeck4.TabIndex = 261;
            this.humanDeck4.TabStop = false;
            // 
            // humanDeck6
            // 
            this.humanDeck6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck6.Location = new System.Drawing.Point(503, 442);
            this.humanDeck6.Name = "humanDeck6";
            this.humanDeck6.Size = new System.Drawing.Size(90, 120);
            this.humanDeck6.TabIndex = 259;
            this.humanDeck6.TabStop = false;
            // 
            // humanDeck7
            // 
            this.humanDeck7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck7.Location = new System.Drawing.Point(599, 442);
            this.humanDeck7.Name = "humanDeck7";
            this.humanDeck7.Size = new System.Drawing.Size(89, 120);
            this.humanDeck7.TabIndex = 258;
            this.humanDeck7.TabStop = false;
            // 
            // humanDeck8
            // 
            this.humanDeck8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck8.Location = new System.Drawing.Point(693, 442);
            this.humanDeck8.Name = "humanDeck8";
            this.humanDeck8.Size = new System.Drawing.Size(90, 120);
            this.humanDeck8.TabIndex = 257;
            this.humanDeck8.TabStop = false;
            // 
            // CubeshumanTextBox
            // 
            this.CubeshumanTextBox.AcceptsReturn = true;
            this.CubeshumanTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CubeshumanTextBox.Enabled = false;
            this.CubeshumanTextBox.Location = new System.Drawing.Point(867, 453);
            this.CubeshumanTextBox.Multiline = true;
            this.CubeshumanTextBox.Name = "CubeshumanTextBox";
            this.CubeshumanTextBox.Size = new System.Drawing.Size(56, 116);
            this.CubeshumanTextBox.TabIndex = 332;
            // 
            // ThreeForOne
            // 
            this.ThreeForOne.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ThreeForOne.Location = new System.Drawing.Point(1051, 510);
            this.ThreeForOne.Name = "ThreeForOne";
            this.ThreeForOne.Size = new System.Drawing.Size(96, 23);
            this.ThreeForOne.TabIndex = 333;
            this.ThreeForOne.Text = "3 For 1";
            this.ThreeForOne.UseVisualStyleBackColor = true;
            this.ThreeForOne.Click += new System.EventHandler(this.ThreeForOne_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1205, 25);
            this.toolStrip1.TabIndex = 334;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(51, 22);
            this.toolStripDropDownButton1.Text = "Game";
            this.toolStripDropDownButton1.ToolTipText = "Start";
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.startToolStripMenuItem.Text = "Start";
            this.startToolStripMenuItem.Click += new System.EventHandler(this.startToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(864, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 335;
            this.label1.Text = "Deck No.";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(867, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 336;
            this.label2.Text = "No. of Cubes";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(867, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 337;
            this.label3.Text = "Graveyard";
            // 
            // DeckTextBox
            // 
            this.DeckTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.DeckTextBox.Location = new System.Drawing.Point(867, 81);
            this.DeckTextBox.Name = "DeckTextBox";
            this.DeckTextBox.Size = new System.Drawing.Size(81, 20);
            this.DeckTextBox.TabIndex = 338;
            // 
            // CubeTextBox
            // 
            this.CubeTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CubeTextBox.Location = new System.Drawing.Point(867, 145);
            this.CubeTextBox.Name = "CubeTextBox";
            this.CubeTextBox.Size = new System.Drawing.Size(81, 20);
            this.CubeTextBox.TabIndex = 339;
            // 
            // GraveyardTextBox
            // 
            this.GraveyardTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.GraveyardTextBox.Location = new System.Drawing.Point(867, 201);
            this.GraveyardTextBox.Name = "GraveyardTextBox";
            this.GraveyardTextBox.Size = new System.Drawing.Size(81, 20);
            this.GraveyardTextBox.TabIndex = 340;
            // 
            // CubesComputerTextBox
            // 
            this.CubesComputerTextBox.AcceptsReturn = true;
            this.CubesComputerTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CubesComputerTextBox.Enabled = false;
            this.CubesComputerTextBox.Location = new System.Drawing.Point(867, 264);
            this.CubesComputerTextBox.Multiline = true;
            this.CubesComputerTextBox.Name = "CubesComputerTextBox";
            this.CubesComputerTextBox.Size = new System.Drawing.Size(56, 116);
            this.CubesComputerTextBox.TabIndex = 341;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.FloralWhite;
            this.groupBox1.Location = new System.Drawing.Point(15, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(796, 551);
            this.groupBox1.TabIndex = 342;
            this.groupBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1205, 613);
            this.Controls.Add(this.CubesComputerTextBox);
            this.Controls.Add(this.GraveyardTextBox);
            this.Controls.Add(this.CubeTextBox);
            this.Controls.Add(this.DeckTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.ThreeForOne);
            this.Controls.Add(this.CubeshumanTextBox);
            this.Controls.Add(this.humanDeckLabel5);
            this.Controls.Add(this.humanDeck5);
            this.Controls.Add(this.HopTile3_Cubes3);
            this.Controls.Add(this.HopTile4_Cubes4);
            this.Controls.Add(this.HopTile4_Cubes3);
            this.Controls.Add(this.HopTile4_Cubes2);
            this.Controls.Add(this.HopTile4_Cubes1);
            this.Controls.Add(this.HopTile3_Cubes2);
            this.Controls.Add(this.HopTile3_Cubes1);
            this.Controls.Add(this.HopTile2_Cubes2);
            this.Controls.Add(this.HopTile2_Cubes1);
            this.Controls.Add(this.HopTile1_Cubes1);
            this.Controls.Add(this.HopTile1_hLabel1);
            this.Controls.Add(this.HopTile3_hLabel1);
            this.Controls.Add(this.HopTile3_hLabel3);
            this.Controls.Add(this.HopTile3_hLabel2);
            this.Controls.Add(this.HopTile2_hLabel2);
            this.Controls.Add(this.HopTile2_hLabel1);
            this.Controls.Add(this.HopTile4_hLabel4);
            this.Controls.Add(this.HopTile4_hLabel3);
            this.Controls.Add(this.HopTile4_hLabel2);
            this.Controls.Add(this.HopTile4_hLabel1);
            this.Controls.Add(this.HopTile4_cLabel4);
            this.Controls.Add(this.HopTile4_cLabel3);
            this.Controls.Add(this.HopTile4_cLabel2);
            this.Controls.Add(this.HopTile4_cLabel1);
            this.Controls.Add(this.HopTile3_cLabel3);
            this.Controls.Add(this.HopTile3_cLabel2);
            this.Controls.Add(this.HopTile3_cLabel1);
            this.Controls.Add(this.HopTile2_cLabel2);
            this.Controls.Add(this.HopTile2_cLabel1);
            this.Controls.Add(this.HopTile1_cLabel1);
            this.Controls.Add(this.HopTileLabel4);
            this.Controls.Add(this.HopTileLabel2);
            this.Controls.Add(this.HopTileLabel3);
            this.Controls.Add(this.HopTileLabel1);
            this.Controls.Add(this.humanDeckLabel8);
            this.Controls.Add(this.humanDeckLabel7);
            this.Controls.Add(this.humanDeckLabel6);
            this.Controls.Add(this.humanDeckLabel4);
            this.Controls.Add(this.humanDeckLabel3);
            this.Controls.Add(this.humanDeckLabel2);
            this.Controls.Add(this.humanDeckLabel1);
            this.Controls.Add(this.humanDeckl1);
            this.Controls.Add(this.HopTile1_c1);
            this.Controls.Add(this.HopTile2_c2);
            this.Controls.Add(this.HopTile2_c1);
            this.Controls.Add(this.HopTile1_h1);
            this.Controls.Add(this.HopTile2_h2);
            this.Controls.Add(this.HopTile2_h1);
            this.Controls.Add(this.HopTile3_h3);
            this.Controls.Add(this.HopTile3_h2);
            this.Controls.Add(this.HopTile3_h1);
            this.Controls.Add(this.HopTile3_c3);
            this.Controls.Add(this.HopTile3_c2);
            this.Controls.Add(this.HopTile3_c1);
            this.Controls.Add(this.HopTile4_h4);
            this.Controls.Add(this.HopTile4_h3);
            this.Controls.Add(this.HopTile4_h2);
            this.Controls.Add(this.HopTile4_h1);
            this.Controls.Add(this.HopTile4_c4);
            this.Controls.Add(this.HopTile4_c3);
            this.Controls.Add(this.HopTile4_c2);
            this.Controls.Add(this.HopTile4_c1);
            this.Controls.Add(this.HopTile4);
            this.Controls.Add(this.HopTile3);
            this.Controls.Add(this.HopTile2);
            this.Controls.Add(this.HopTile1);
            this.Controls.Add(this.humanDeck1);
            this.Controls.Add(this.humanDeck2);
            this.Controls.Add(this.humanDeck3);
            this.Controls.Add(this.humanDeck4);
            this.Controls.Add(this.humanDeck6);
            this.Controls.Add(this.humanDeck7);
            this.Controls.Add(this.humanDeck8);
            this.Controls.Add(this.btnReshuffle);
            this.Controls.Add(this.TrophyLabelOwn5);
            this.Controls.Add(this.TrophyLabel5);
            this.Controls.Add(this.Trophy5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TrophyLabelOwn4);
            this.Controls.Add(this.TrophyLabelOwn3);
            this.Controls.Add(this.TrophyLabelOwn2);
            this.Controls.Add(this.TrophyLabelOwn1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TrophyLabel4);
            this.Controls.Add(this.TrophyLabel3);
            this.Controls.Add(this.TrophyLabel2);
            this.Controls.Add(this.TrophyLabel1);
            this.Controls.Add(this.Trophy1);
            this.Controls.Add(this.Trophy4);
            this.Controls.Add(this.Trophy3);
            this.Controls.Add(this.Trophy2);
            this.Controls.Add(this.computerDeckLabel8);
            this.Controls.Add(this.computerDeckLabel7);
            this.Controls.Add(this.computerDeckLabel6);
            this.Controls.Add(this.computerDeckLabel5);
            this.Controls.Add(this.computerDeckLabel4);
            this.Controls.Add(this.computerDeckLabel3);
            this.Controls.Add(this.computerDeckLabel2);
            this.Controls.Add(this.computerDeckLabel1);
            this.Controls.Add(this.computerDeck1);
            this.Controls.Add(this.computerDeck2);
            this.Controls.Add(this.computerDeck3);
            this.Controls.Add(this.computerDeck4);
            this.Controls.Add(this.computerDeck5);
            this.Controls.Add(this.computerDeck6);
            this.Controls.Add(this.computerDeck7);
            this.Controls.Add(this.computerDeck8);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Ballon Cup";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.Trophy5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck8)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TrophyLabelOwn5;
        private System.Windows.Forms.Label TrophyLabel5;
        private System.Windows.Forms.PictureBox Trophy5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label TrophyLabelOwn4;
        private System.Windows.Forms.Label TrophyLabelOwn3;
        private System.Windows.Forms.Label TrophyLabelOwn2;
        private System.Windows.Forms.Label TrophyLabelOwn1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label TrophyLabel4;
        private System.Windows.Forms.Label TrophyLabel3;
        private System.Windows.Forms.Label TrophyLabel2;
        private System.Windows.Forms.Label TrophyLabel1;
        private System.Windows.Forms.PictureBox Trophy1;
        private System.Windows.Forms.PictureBox Trophy4;
        private System.Windows.Forms.PictureBox Trophy3;
        private System.Windows.Forms.PictureBox Trophy2;
        private System.Windows.Forms.Button btnReshuffle;
        private System.Windows.Forms.Label computerDeckLabel8;
        private System.Windows.Forms.Label computerDeckLabel7;
        private System.Windows.Forms.Label computerDeckLabel6;
        private System.Windows.Forms.Label computerDeckLabel5;
        private System.Windows.Forms.Label computerDeckLabel4;
        private System.Windows.Forms.Label computerDeckLabel3;
        private System.Windows.Forms.Label computerDeckLabel2;
        private System.Windows.Forms.Label computerDeckLabel1;
        private System.Windows.Forms.PictureBox computerDeck1;
        private System.Windows.Forms.PictureBox computerDeck2;
        private System.Windows.Forms.PictureBox computerDeck3;
        private System.Windows.Forms.PictureBox computerDeck4;
        private System.Windows.Forms.PictureBox computerDeck5;
        private System.Windows.Forms.PictureBox computerDeck6;
        private System.Windows.Forms.PictureBox computerDeck7;
        private System.Windows.Forms.PictureBox computerDeck8;
        private System.Windows.Forms.Label humanDeckLabel5;
        private System.Windows.Forms.PictureBox humanDeck5;
        private System.Windows.Forms.PictureBox HopTile3_Cubes3;
        private System.Windows.Forms.PictureBox HopTile4_Cubes4;
        private System.Windows.Forms.PictureBox HopTile4_Cubes3;
        private System.Windows.Forms.PictureBox HopTile4_Cubes2;
        private System.Windows.Forms.PictureBox HopTile4_Cubes1;
        private System.Windows.Forms.PictureBox HopTile3_Cubes2;
        private System.Windows.Forms.PictureBox HopTile3_Cubes1;
        private System.Windows.Forms.PictureBox HopTile2_Cubes2;
        private System.Windows.Forms.PictureBox HopTile2_Cubes1;
        private System.Windows.Forms.PictureBox HopTile1_Cubes1;
        private System.Windows.Forms.Label HopTile1_hLabel1;
        private System.Windows.Forms.Label HopTile3_hLabel1;
        private System.Windows.Forms.Label HopTile3_hLabel3;
        private System.Windows.Forms.Label HopTile3_hLabel2;
        private System.Windows.Forms.Label HopTile2_hLabel2;
        private System.Windows.Forms.Label HopTile2_hLabel1;
        private System.Windows.Forms.Label HopTile4_hLabel4;
        private System.Windows.Forms.Label HopTile4_hLabel3;
        private System.Windows.Forms.Label HopTile4_hLabel2;
        private System.Windows.Forms.Label HopTile4_hLabel1;
        private System.Windows.Forms.Label HopTile4_cLabel4;
        private System.Windows.Forms.Label HopTile4_cLabel3;
        private System.Windows.Forms.Label HopTile4_cLabel2;
        private System.Windows.Forms.Label HopTile4_cLabel1;
        private System.Windows.Forms.Label HopTile3_cLabel3;
        private System.Windows.Forms.Label HopTile3_cLabel2;
        private System.Windows.Forms.Label HopTile3_cLabel1;
        private System.Windows.Forms.Label HopTile2_cLabel2;
        private System.Windows.Forms.Label HopTile2_cLabel1;
        private System.Windows.Forms.Label HopTile1_cLabel1;
        private System.Windows.Forms.Label HopTileLabel4;
        private System.Windows.Forms.Label HopTileLabel2;
        private System.Windows.Forms.Label HopTileLabel3;
        private System.Windows.Forms.Label HopTileLabel1;
        private System.Windows.Forms.Label humanDeckLabel8;
        private System.Windows.Forms.Label humanDeckLabel7;
        private System.Windows.Forms.Label humanDeckLabel6;
        private System.Windows.Forms.Label humanDeckLabel4;
        private System.Windows.Forms.Label humanDeckLabel3;
        private System.Windows.Forms.Label humanDeckLabel2;
        private System.Windows.Forms.Label humanDeckLabel1;
        private System.Windows.Forms.Label humanDeckl1;
        private System.Windows.Forms.PictureBox HopTile1_c1;
        private System.Windows.Forms.PictureBox HopTile2_c2;
        private System.Windows.Forms.PictureBox HopTile2_c1;
        private System.Windows.Forms.PictureBox HopTile1_h1;
        private System.Windows.Forms.PictureBox HopTile2_h2;
        private System.Windows.Forms.PictureBox HopTile2_h1;
        private System.Windows.Forms.PictureBox HopTile3_h3;
        private System.Windows.Forms.PictureBox HopTile3_h2;
        private System.Windows.Forms.PictureBox HopTile3_h1;
        private System.Windows.Forms.PictureBox HopTile3_c3;
        private System.Windows.Forms.PictureBox HopTile3_c2;
        private System.Windows.Forms.PictureBox HopTile3_c1;
        private System.Windows.Forms.PictureBox HopTile4_h4;
        private System.Windows.Forms.PictureBox HopTile4_h3;
        private System.Windows.Forms.PictureBox HopTile4_h2;
        private System.Windows.Forms.PictureBox HopTile4_h1;
        private System.Windows.Forms.PictureBox HopTile4_c4;
        private System.Windows.Forms.PictureBox HopTile4_c3;
        private System.Windows.Forms.PictureBox HopTile4_c2;
        private System.Windows.Forms.PictureBox HopTile4_c1;
        private System.Windows.Forms.PictureBox HopTile4;
        private System.Windows.Forms.PictureBox HopTile3;
        private System.Windows.Forms.PictureBox HopTile2;
        private System.Windows.Forms.PictureBox HopTile1;
        private System.Windows.Forms.PictureBox humanDeck1;
        private System.Windows.Forms.PictureBox humanDeck2;
        private System.Windows.Forms.PictureBox humanDeck3;
        private System.Windows.Forms.PictureBox humanDeck4;
        private System.Windows.Forms.PictureBox humanDeck6;
        private System.Windows.Forms.PictureBox humanDeck7;
        private System.Windows.Forms.PictureBox humanDeck8;
        private System.Windows.Forms.TextBox CubeshumanTextBox;
        private System.Windows.Forms.Button ThreeForOne;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DeckTextBox;
        private System.Windows.Forms.TextBox CubeTextBox;
        private System.Windows.Forms.TextBox GraveyardTextBox;
        private System.Windows.Forms.TextBox CubesComputerTextBox;
        private System.Windows.Forms.GroupBox groupBox1;

    }
}

