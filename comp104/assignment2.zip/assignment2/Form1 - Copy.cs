﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics.Contracts;
using System.Runtime.InteropServices;

namespace assignment2
{
    public partial class Form1 : Form
    {
        //default color
        Color Default = Color.LightGray;

        /// <summary>
        /// all the preparation variables
        /// </summary>
        List<Cube> bags = new List<Cube>();
        List<Card> deck = new List<Card>();
        List<Card> Graveyard = new List<Card>();
        List<HopTile> HopTiles = new List<HopTile>();
        List<TrophyCard> TrophyCards = new List<TrophyCard>();

        /// <summary>
        /// list of picturebox for the player(human). we will create a list of click handler from this list
        /// so that the pictureboxes in this list is clickable
        /// </summary>
        List<PictureBox> PlayersPicBox = new List<PictureBox>();

        /// <summary>
        /// list of pic boxes of slots which belong to the hop tiles
        /// they are clickable as well, but only after the pic box in the PlayersPicBox is clicked
        /// </summary>
        List<PictureBox> HopTilesSlotPicBox = new List<PictureBox>();

        /// <summary>
        /// list of pic boxes of trophycards, so as to create click event for 3 to 1
        /// </summary>
        List<PictureBox> TrophyCardsPicBox = new List<PictureBox>();

        /// <summary>
        /// previousColor is the color that user previously claimed
        /// threeforone is true when user uses the threeforOne method
        /// </summary>
        Color previousColor;
        bool threeforone = false;

        /// <summary>
        /// reshuffle variables
        /// reshuffle is set to true is the user is selecting cards to be reshuffled
        /// reshuffledcards store the list of cards that user want to discard
        /// </summary>
        bool reshuffle = false;
        List<Card> reshuffledcards = new List<Card>();

        /// <summary>
        /// currentCard and currentHoptile are used by human for referencing
        /// currentComputerHoptile and currentComputerCard are used by computer fo referencing during the program
        /// </summary>
        Card currentCard;
        HopTile currentHopTile;
        HopTile currentComputerHopTile;
        Card currentComputerCard;

        /// <summary>
        /// human represents the user who are playing the game
        /// </summary>
        Human human = new Human();
        Computer computer = new Computer();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Preparation()
        {
            generateRandomCubesAndCards();
            generateHopTiles();
            randomCubesOnTiles();
            ShuffleCardsToPlayer(human, 8, true);
            ShuffleCardsToPlayer(computer,8,true);
            generateAndPlaceTrophyCards();
            boundSlots();
            initControlsForCards();
            if (!CalculateCardsCanBePlacedOnSlots(human))
            {
                startReshuffle();
            }
        }
        /// <summary>
        /// generate new 4 hop tiles
        /// </summary>
        private void generateHopTiles()
        {

            for (int i = 0; i < 4; i++)
            {
                if (i%2 == 0)
                {
                    HopTiles.Add(new HopTile(HopTile.stateofHopTiles.High, i + 1, (PictureBox)this.Controls["HopTile" + (i+1).ToString()], (Label)this.Controls["HopTileLabel" + (i + 1).ToString()]));
                }
                else
                {
                    HopTiles.Add(new HopTile(HopTile.stateofHopTiles.Low, i + 1, (PictureBox)this.Controls["HopTile" + (i+1).ToString()], (Label)this.Controls["HopTileLabel" + (i + 1).ToString()]));
                }
            }
        }
        /// <summary>
        /// generate random lists of cubes in the bag, and random lists of cards on the deck
        /// </summary>
        private void generateRandomCubesAndCards()
        {
            //generate 45 randomised cubes and cards 
            for (int i = 1; i <= 13; i++)
            {
                Color newcolor = Default;
                if (i == 1||i==4||i==7||i ==10||i==13)
                {
                    AddNewCubeAndCard(Color.Gray, i);
                }
                if (i%2 != 0)
                {
                    AddNewCubeAndCard(Color.Blue, i);
                }
                if ((i%2 != 0 && i != 0 && i!= 13 && i != 7)||i== 2||i == 12)
                {
                    AddNewCubeAndCard(Color.Green, i);
                }
                if (i!=4||i!=10)
                {
                    AddNewCubeAndCard(Color.Yellow, i);
                }
                AddNewCubeAndCard(Color.Red, i);

            }
            bags.Shuffle();
            deck.Shuffle();

        }
        /// <summary>
        /// Add Cube and Card into the bag and deck using the parameter
        /// </summary>
        /// <param name="color"></param>
        /// <param name="value"></param>
        private void AddNewCubeAndCard(Color color,int value)
        {
            bags.Add(new Cube(color));
            deck.Add(new Card(color, value));
        }
        /// <summary>
        /// used for preparation at the start of the game
        /// generate randomly selected cubes from the bags to place on the hop tiles
        /// </summary>
        private void randomCubesOnTiles()
        {
            for (int i = 1; i <= 4; i++)
            {
                PlaceCubesOnTiles(i);
            }
        }
        /// <summary>
        /// Place the randomly drawn cubes onto the hop tiles
        /// </summary>
        /// <returns></returns>
        private void PlaceCubesOnTiles(int numberToBeDrawn)
        {
            Contract.Requires(numberToBeDrawn > 0);
            List<Cube> cubetoPlace = new List<Cube>();
            //retrieve cubes from bags
            for (int i = 0; i < numberToBeDrawn; i++)
            {
                cubetoPlace.Add(bags[i]);
            }
            //remove the cubes which are retrieved from the bag
            for (int i = 0; i < numberToBeDrawn; i++)
            {
                bags.RemoveAt(0);
            }
            //bound the picturebox to the cubes inside hop tiles
            for (int i = 0; i < cubetoPlace.Count; i++)
            {
                cubetoPlace[i].BoundedBox = (PictureBox)this.Controls["HopTile" + numberToBeDrawn.ToString() + "_Cubes" + (i + 1).ToString()];
            }
            HopTiles[numberToBeDrawn-1].Cubes = cubetoPlace;
            currentHopTile = HopTiles[numberToBeDrawn-1];
            
        }
        /// <summary>
        /// discard the number of cards in player's hand, and redraw from he deck
        /// </summary>
        /// <param name="player"></param>
        /// <param name="number"></param> number to be discarded and reshuffled
        /// <param name="ispreparation"></param> is it during the preparation process
        private void ShuffleCardsToPlayer(Player player,int number,bool ispreparation)
        {
            Contract.Requires(number > 0);
            ///if this isnt preparation, then we will discard the number, then draw again
            ///if it is during preparation part, no cards is in player's hand, so there is nothing to be discarded
            if (!ispreparation)
            {
                for (int i = 0; i < number; i++)
                {
                    Graveyard.Add(player.Cards[i]);
                }
                for (int i = 0; i < number; i++)
                {
                    player.Cards.RemoveAt(0);
                }
                //discard the cards if itsn't during the preparation
            }

            //add card from the deck
            for (int i = 0; i < number; i++)
            {
                player.Cards.Add(deck[i]);
            }
            for (int i = 0; i < number; i++)
            {
                deck.RemoveAt(0);
            }
            
            //bound pictureboxes and label controls to the cards whic are shuffled to each player
            for (int i = 1; i < 9; i++)
            {
                if (player is Human)
                {
                    if (ispreparation)
                    {
                        PlayersPicBox.Add((PictureBox)this.Controls["humanDeck" + i.ToString()]);
                    }
                    human.Cards[i - 1].BoundedBox = PlayersPicBox[i-1]; 
                    ///both human.Cards.BoundedBox and PlayersPicBox add the same pictureBox, because
                    ///because they all belong to human right now
                    human.Cards[i - 1].BoundedLabel = (Label)this.Controls["humanDeckLabel" + i.ToString()];
                }
                else if (player is Computer)
                {
                    computer.Cards[i - 1].BoundedBox = (PictureBox)this.Controls["computerDeck" + i.ToString()];
                    computer.Cards[i - 1].BoundedLabel = (Label)this.Controls["computerDeckLabel" + i.ToString()];
                }
                
            }
        }
        /// <summary>
        /// generate and bound Trophycard to picture box and label in the form
        /// </summary>
        private void generateAndPlaceTrophyCards()
        {
            TrophyCards.Add(new TrophyCard(3, Color.Gray));
            TrophyCards.Add(new TrophyCard(4, Color.Blue));
            TrophyCards.Add(new TrophyCard(5, Color.Green));
            TrophyCards.Add(new TrophyCard(6, Color.Yellow));
            TrophyCards.Add(new TrophyCard(7, Color.Red));
            human.TrophyCards = new List<TrophyCard>(TrophyCards);
            computer.TrophyCards = new List<TrophyCard>(TrophyCards);
            for (int i = 0; i < 5; i++)
            {
                TrophyCardsPicBox.Add((PictureBox)this.Controls["Trophy" + (i + 1).ToString()]);
                human.TrophyCards[i].BoundedBox = (PictureBox)this.Controls["Trophy" + (i + 1).ToString()];
                human.TrophyCards[i].BoundedLabel = (Label)this.Controls["TrophyLabel" + (i + 1).ToString()];
                human.TrophyCards[i].BoundedLabelOwn = (Label)this.Controls["TrophyLabelOwn" + (i + 1).ToString()];
            }
        }
        /// <summary>
        /// Bound slots to picturebox and label in the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void boundSlots()
        {
            for (int hcount = 1; hcount <= 4; hcount++) //count for hop tiles
            {
                for (int scount = 1; scount <= hcount; scount++) //each slots which belong to each hpo tile
                {
                    HopTilesSlotPicBox.Add((PictureBox)this.Controls["HopTile" + hcount.ToString() + "_h" + scount.ToString()]);
                    HopTiles[hcount-1].CardsOnPlayer.Add(new Card(Default, 0, (PictureBox)this.Controls["HopTile" + hcount.ToString() + "_h" + scount.ToString()], (Label)this.Controls["HopTile" + hcount.ToString() + "_hLabel" + scount.ToString()]));
                    HopTiles[hcount-1].CardsOnPC.Add(new Card(Default, 0, (PictureBox)this.Controls["HopTile" + hcount.ToString() + "_c" + scount.ToString()], (Label)this.Controls["HopTile" + hcount.ToString() + "_cLabel" + scount.ToString()]));
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            
            
        }
        /// <summary>
        /// draw everything in the form
        /// </summary>
        private void Draw()
        {
            List<List<Cube>> listofAmountForEachColor;

            foreach (Card item in human.Cards)
            {
                item.Draw();
            }
            foreach (Card item in computer.Cards)
            {
                item.Draw();
            }
            foreach (HopTile item in HopTiles)
            {
                item.Draw();
            }
            foreach (TrophyCard item in human.TrophyCards)
            {
                item.Draw();
            }

            //get the list of cubes with respect to their color.
            //e.g. listofAmountForEachColor[0] is the list of gray cubes. blue, green etc..
            //listofAmountForEachColor[0][0] is the first element in the gray cubes
            listofAmountForEachColor = DistinctListForEachColor(human.Cubes);
            CubeshumanTextBox.Text = "You has " + "Gray " + listofAmountForEachColor[0].Count + "\n" + " Blue " + listofAmountForEachColor[1].Count + "\n" + " Green " + listofAmountForEachColor[2].Count + "\n" + " Yellow " + listofAmountForEachColor[3].Count + "\n" + " Red" + listofAmountForEachColor[4].Count + " Cubes";

            listofAmountForEachColor = DistinctListForEachColor(computer.Cubes);
            CubesComputerTextBox.Text = "PC has " + "Gray " + listofAmountForEachColor[0].Count + "\n" + " Blue " + listofAmountForEachColor[1].Count + "\n" + " Green " + listofAmountForEachColor[2].Count + "\n" + " Yellow " + listofAmountForEachColor[3].Count + "\n" + " Red" + listofAmountForEachColor[4].Count + " Cubes";

            DeckTextBox.Text = deck.Count.ToString();
            GraveyardTextBox.Text = Graveyard.Count.ToString();
            CubeTextBox.Text = bags.Count.ToString();
        }


        private void Form1_Resize(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// check if either play has more than three trophies
        /// if yes, close the form, thus ending the game
        /// if no, doing nothing and continue the game
        /// </summary>
        private void IsGameEnd()
        {
            if (computer.NumberOfTrophies >= 3 || human.NumberOfTrophies >= 3)
            {
                MessageBox.Show("game end!");
                this.Close();
            }
        }

        /// <summary>
        /// initilise click event for pictureboxes 
        /// one is the user's deck
        /// one is the slot of the hop tile on user's side
        /// one is the user's trophyCards
        /// </summary>
        private void initControlsForCards()
         {
            Control.ControlCollection controls = this.Controls;
            foreach (Control c in controls)  
             {

                 if (c is PictureBox)
                 {
                    if (PlayersPicBox.Contains(c)) //deck pictureboxes' click event
	                {
		                 c.MouseClick += (sender, e) => {
                             ///inside the click event for each picturebox on human's side
                             ///it loops through and set the currentcard to the one being clicked
                             IsGameEnd();
                             PictureBox currentpic = (PictureBox)c;
                             foreach (Card item in human.Cards)
                             {
                                 if (item.BoundedBox == c)
                                 {
                                     if (currentCard != null) //if the user wants to drop the previous selected card, and choose a new one, play the animation of the previous one
                                     {
                                         AnimateDown(currentCard.BoundedBox);
                                     }
                                         currentCard = item;
                                         AnimateUp(c);
                                         ///if the player is reshuffling
                                         if (reshuffle)
                                         {
                                             if (reshuffledcards.Count == 4)//maximum 4 cards to be shuffled
                                             {
                                                 FinishReshuffle(human);
                                                 return;
                                             }
                                             else
                                             {
                                                 reshuffledcards.Add(item);
                                                 return; 
                                             }
                                             
                                         }
                                         else
                                         {
                                             Draw();
                                             return;
                                         }
                                         
                                 }
                             }
                         };  
	                }
                    else if (HopTilesSlotPicBox.Contains(c)) //slots pictureboxes' click event
                    {
                        c.MouseClick += (sender, e) => {
                             ///inside the click event for each picturebox on the slots of the current hop tile
                            if (currentCard != null)//if a card in player's hand is selected
                            {
                                
                                currentHopTile = FindHopTile((PictureBox)c); //find the corresponding hoptile with respect to this slot
                                Contract.Requires(currentHopTile != null);
                                if (!human.CardsCanBePlacedOnSlots[currentHopTile.Value-1].Contains(currentCard))
                                    ///if the selected card (current card) is CANNOT be put into this slot
                                {
                                    MessageBox.Show("You can't add this, please select another one");
                                    return;
                                }

                                Card availableslot = AvailableSlot(currentHopTile.CardsOnPlayer);
                                //find an availble slot
                                Contract.Requires(availableslot != null);
                                    AnimateDown(currentCard.BoundedBox);
                                    ///add a card from the deck 
                                    if (!IsDeckEnough(1)) //can the deck be drawn with 1 card
                                    {
                                        AddGraveyardToDeck();
                                    }
                                    //pass the value of the current selected card to the slot
                                    availableslot.Value = currentCard.Value;
                                    availableslot.Colour = currentCard.Colour;

                                    Contract.Requires(human.Cards.Contains(currentCard));

                                    AddaCardFromDeck(human, currentCard);//discard the currentCard, and Add a new one from the deck
                                    currentCard = null;

                                    ///check again if there is available slots to be placed
                                    ///if nothing can be added, we will calculate the score
                                    Card availableslotAgain = AvailableSlot(currentHopTile.CardsOnPlayer);
                                    Card availableslotAgainPC = AvailableSlot(currentHopTile.CardsOnPC);
                                    if (availableslotAgain == null && availableslotAgainPC == null)
                                    {
                                        Draw();
                                        scoring(human);
                                        return;
                                    }
                                    ///if there is available slot, we will switch to the next turn
                                    ///which is the computer's turn. we check if computer has available cards
                                    if (!CalculateCardsCanBePlacedOnSlots(computer))
                                    {
                                        if (!IsDeckEnough(4))
                                        {
                                            AddGraveyardToDeck();
                                        }
                                        computerReshuffle();
                                        return;
                                    }
                                    Draw();
                                    robot();
                                    return;

                            }
                         
                         }; 
                    }
                    else if (TrophyCardsPicBox.Contains(c)) //trohpy cards picturebox clickevent
                    {
                        c.MouseClick += (sender, e) =>
                        {
                            if (threeforone)
                            {
                                foreach (TrophyCard AimTrophy in TrophyCards)
                                {
                                    if (AimTrophy.BoundedBox == c)
                                    {
                                        ///lists to be traded 
                                        List<Cube> listsofTrade = new List<Cube>(); //e.g. 3 green to be traded for one yellow, this is the lists of green
                                        List<Cube> ListsofOriginalColor = new List<Cube>(); ///in the above example, this is the list for yellow
                                                                                            ///
                                        List<List<Cube>> listofAmountForEachColor;
                                        listofAmountForEachColor = DistinctListForEachColor(human.Cubes); //two dimentional list, first dimention is the color, [0] for gray
                                        //second dimention is the list. e.g. [0][0] is the first element in the gray list
                                        foreach (List<Cube> list in listofAmountForEachColor) //
                                        {
                                            if (list.Count != 0)
                                            {
                                                if (list.Count >= 3)
                                                {
                                                    if (list[0].Colour == previousColor) //e.g. find all cubes that is green, and must be more than three
                                                    {
                                                        listsofTrade = new List<Cube>(list);
                                                    }
                                                }
                                                if (list[0].Colour == AimTrophy.Colour) //e.g. find the cubes that is yellow
                                                {
                                                    if (AimTrophy.NumberOfCubesNeeded - list.Count == 1)
                                                    {
                                                        ListsofOriginalColor = new List<Cube>(list);
                                                    }
                                                }
                                            }
                                            
                                        }
                                        if (listsofTrade.Count != 0 && ListsofOriginalColor.Count != 0)
                                        {
                                            for (int i = 0; i < 3; i++)
                                            {
                                                bags.Add(ListsofOriginalColor[i]);
                                                human.Cubes.Remove(listsofTrade[i]); //delete the first three elements of the the green list
                                            }
                                            for (int j = 0; j < ListsofOriginalColor.Count; j++)
                                            {
                                                bags.Add(ListsofOriginalColor[j]);
                                                human.Cubes.Remove(ListsofOriginalColor[j]); //remove all the yellow cubes in player's hand
                                            }
                                            bags.Shuffle();
                                            AimTrophy.NumberOwned++;
                                            MessageBox.Show("you get a new trophy " + AimTrophy.Colour.ToString());
                                            CheckTrophy(human);
                                            threeforone = false;
                                            Draw();
                                            return;
                                        }
                                        else
                                        {
                                            MessageBox.Show("you are not eligible for this function");
                                            threeforone = false;
                                        }
                                        
                                    }
                                }
                                
                            }
                        };
                    }
                 }
               
             }
         }

        /// <summary>
        /// animation for selecting a card in the deck
        /// </summary>
        /// <param name="control"></param>
        private void AnimateUp(Control control)
        {
            Contract.Requires(control != null);
                int directionY = 10;
                int destination = control.Top - 10;
                while (control.Top != destination)
                {
                    try
                    {
                        if (control.Top != destination)
                        {
                            this.Invoke((Action)delegate()
                            {
                                control.Top -= directionY; //move by directionY
                            });
                        }
                        Thread.Sleep(50);
                    }
                    catch
                    {
                        MessageBox.Show("animation failed");
                    }
                }

        }
        /// <summary>
        /// animation for the card being selected in the deck after selecting a slot 
        /// </summary>
        /// <param name="control"></param>
        private void AnimateDown(Control control)
        {
            Contract.Requires(control != null);
                int directionY = 10;
                int destination = control.Top + 10;
                while (control.Top != destination)
                {
                    try
                    {
                        if (control.Top != destination)
                        {
                            this.Invoke((Action)delegate()
                            {
                                control.Top += directionY; //move by directionY
                            });
                        }
                        Thread.Sleep(50);
                    }
                    catch
                    {
                        MessageBox.Show("animation failed");
                    }
                }

        }
        /// <summary>
        /// this find the available slot which has not yet been placed upon
        /// if all the slots have been placed, it returns null
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        private Card AvailableSlot(List<Card> list)
        {
            Contract.Requires(list != null);
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Value == 0)
                {
                    return list[i]; //if there is a value which is 0, thus this means this slot hasn't been
                    //placed, thus it is a available slot
                }
            }
            return null;
        }

        /// <summary>
        /// find the HopTile using the pictureBox provided
        /// this picturebox should bounded with a slot object
        /// </summary>
        /// <param name="picslot"></param>
        /// <returns></returns>
        private HopTile FindHopTile(PictureBox picslot)
        {
            Contract.Requires(picslot != null);
            foreach (HopTile item in HopTiles)
            {
                foreach (Card card in item.CardsOnPlayer)
                {
                    if (card.BoundedBox == picslot)
                    {
                        return item;
                    }
                }
            }
            return null;
        }
        /// <summary>
        /// remove the item(card) from the player's hand, and add the top card from the deck to hand
        /// </summary>
        /// <param name="player"></param>
        /// <param name="item"></param> card to be removed
        private void AddaCardFromDeck(Player player,Card item)
        {
            Contract.Requires(item != null && player != null);
            if (player is Computer)
            {
                int value = deck[0].Value;
            }
            
            deck[0].BoundedBox = item.BoundedBox;
            deck[0].BoundedLabel = item.BoundedLabel;
            if (player is Human)
            {
                human.Cards.Remove(item);//remove the current selected
                human.Cards.Add(deck[0]);//add the top card of the deck
                                     
            }
            else
            {
                computer.Cards.Remove(item);
                computer.Cards.Add(deck[0]);
            }
            deck.RemoveAt(0);
        }

        
        /// <summary>
        /// calculate the list of cards that can be placed, 
        /// return true if players can place cards, and values of CardsCanBePlacedOnSlots of the player is set
        /// return false otherwise
        /// </summary>
        /// <param name="player"></param>
        private bool CalculateCardsCanBePlacedOnSlots(Player player)
        {
            Contract.Requires(player != null);

            List<Card> AllCardsInHand = new List<Card>();
            List<Card> AllSlotsInTilesForThisPlayer = new List<Card>();
            List<Card> cardsCanBePlacedInHand = new List<Card>();

            List<Color> distinguishedcolorsCube = new List<Color>();
            List<Color> distinguishedcolorsSlot = new List<Color>();

            bool hasvalue = false;
            for (int i = 0; i < 4; i++)
            {
                cardsCanBePlacedInHand = new List<Card>();//rest the values
                distinguishedcolorsCube = new List<Color>();
                distinguishedcolorsSlot = new List<Color>();
                if (player is Human)
                {
                    AllSlotsInTilesForThisPlayer = new List<Card>(HopTiles[i].CardsOnPlayer);
                }
                else
                {
                    AllSlotsInTilesForThisPlayer = new List<Card>(HopTiles[i].CardsOnPC);
                }

                    //all the color in the slots for this player
                    AllSlotsInTilesForThisPlayer.RemoveAll(Cards => Cards.Value == 0);
                    foreach (Card item in AllSlotsInTilesForThisPlayer)
                    {
                        distinguishedcolorsSlot.Add(item.Colour);
                    }


                    //all the color in the tile for this player
                    foreach (Cube item in HopTiles[i].Cubes)
                    {
                        distinguishedcolorsCube.Add(item.Colour);
                    }
                    

                    //remove the duplicates of distinguishedcolor for CUBE and distingusihed color for SLOT
                    //so only the color we want to add is left in this list distinguishedcolorsCube
                        foreach (Color item in distinguishedcolorsSlot)
                        {
                            distinguishedcolorsCube.Remove(item);

                        }
                        distinguishedcolorsCube = distinguishedcolorsCube.Distinct().ToList<Color>();
                    
                //find all the cards that can be used in player's hand
                    foreach (Card cardsinhand in player.Cards)
                    {
                        foreach (Color Cubecolor in distinguishedcolorsCube)
                        {
                            if (Cubecolor == cardsinhand.Colour)
                            {
                                cardsCanBePlacedInHand.Add(cardsinhand);
                            }
                        }
                    }
                //if something can be placed on the slots
                    if (cardsCanBePlacedInHand.Count != 0)
                    {
                        hasvalue = true;
                        if (player is Human)
                        {
                            human.CardsCanBePlacedOnSlots[i] = new List<Card>(cardsCanBePlacedInHand);
                            
                        }
                        else
                        {
                            computer.CardsCanBePlacedOnSlots[i] = new List<Card>(cardsCanBePlacedInHand);
                        }
                    }
                    else //if no values can be placed in this tile
                    {
                        if (player is Human)
                        {
                            human.CardsCanBePlacedOnSlots[i].Clear();
                        }
                        else
                        {
                            computer.CardsCanBePlacedOnSlots[i].Clear();
                        }
                    }
                }
            return hasvalue;
            
        }
        /// <summary>
        /// Start the reshuffle if the user cannot place any cards on the tile
        /// </summary>
        private void startReshuffle()
        {
            MessageBox.Show("you don't have anything to place, please select up to 4 cards in your hand to reshuffle. press the button to finish");
            reshuffle = true;
            btnReshuffle.Enabled = true;
        }    
        /// <summary>
        /// Finish the reshuffle process after user chooses up to 4 cards
        /// </summary>
        /// <param name="player"></param>
        private void FinishReshuffle(Player player)
        {
            Contract.Requires(player != null);
            if (!IsDeckEnough(reshuffledcards.Count)) //can the deck be drawn with these card?
            {
                AddGraveyardToDeck();
            }
            ShuffleCardsToPlayer(player, reshuffledcards.Count, false);
            MessageBox.Show("reshuffled successful");
            if (!CalculateCardsCanBePlacedOnSlots(player))
            {
                MessageBox.Show("You cant doing anything again even if you ve already shuffled once, your turn is ended");
            }
            reshuffle = false;//rest the value
            btnReshuffle.Enabled = false;
            Draw();

        }
        /// <summary>
        /// check if the deck can be drawn with the provided number
        /// return true if yes, otherwise false
        /// </summary>
        /// <param name="numberToBeDrawn"></param>
        /// <returns></returns>
        /// 
        private bool IsDeckEnough(int numberToBeDrawn)
        {
            if (numberToBeDrawn < deck.Count)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// this method is called is deck is not enough, all of the cards in the disposable deck is filled into
        /// the main deck, then main deck is shuffled
        /// </summary>
        private void AddGraveyardToDeck()
        {
            foreach (Card item in Graveyard)
            {
                deck.Add(item);

            }
            Graveyard.Clear();
            deck.Shuffle();
        }
        /// <summary>
        /// compare the scoring of two player, then calculate who is the winner
        /// </summary>
        /// <param name="player"></param>
        private void scoring(Player player)
        {
            Contract.Requires(player != null);
            int playerscore = 0;
            foreach (Card item in currentHopTile.CardsOnPlayer)
            {
                playerscore += item.Value;
            }
            int computerscore = 0;
            foreach (Card item in currentHopTile.CardsOnPC)
            {
                computerscore += item.Value;
            }
            if (computerscore == playerscore)
            {
                Win(player);
                return;
            }
            if (currentHopTile.State.ToString("F") == "High")
            {
                if (computerscore > playerscore)
                {
                    Win(computer);
                    return;
                }
                else
                {
                    Win(human);
                    return;
                }
            }
            else
            {
                if (computerscore > playerscore)
                {
                    Win(human);
                    return;
                }
                else
                {
                    Win(computer);
                    return;
                }
            }
        }

        /// <summary>
        /// list of things after a winner is announced
        /// </summary>
        /// <param name="player"></param>
        private void Win(Player player)
        {
            Contract.Requires(player != null);

            MessageBox.Show(player.Name + " Wins");
            player.Cubes.AddRange(currentHopTile.Cubes);//winnner takes the cubes on the hop tiles
            foreach (Cube item in currentHopTile.Cubes)
            {
                MessageBox.Show(player.Name+ " gained 1 Cube of" + item.Colour);
            }
            Graveyard.AddRange(currentHopTile.CardsOnPC);
            Graveyard.AddRange(currentHopTile.CardsOnPlayer); //winner discards the cards on both sides of the tile
            if (currentHopTile.State.ToString("F") == "High")//switch the state
            {
                currentHopTile.State = HopTile.stateofHopTiles.Low;
            }
            else
            {
                currentHopTile.State = HopTile.stateofHopTiles.High;
            }
            PlaceCubesOnTiles(currentHopTile.Cubes.Count); //winner place cubes

            foreach (Card item in currentHopTile.CardsOnPC) //clear the slots
            {
                item.Colour = Default;
                item.Value = 0;
            }
            foreach (Card item in currentHopTile.CardsOnPlayer)
            {
                item.Colour = Default;
                item.Value = 0;
            }

            CheckTrophy(player);
            Draw();

            if (player is Human) //if the winner human, robot starts the next turn
                //otherwise the computer wins, so do nothing
            {
                MessageBox.Show("robot's turn");
                robot();
                return;
            }
            MessageBox.Show("your turn");
            

        }

        /// <summary>
        /// check if the player is qualified for a trophy
        /// </summary>
        /// <param name="player"></param>
        private void CheckTrophy(Player player)
        {
            Contract.Requires(player != null);
            List<List<Cube>> listofAmountForEachColor = DistinctListForEachColor(player.Cubes);
            //distinct values in terms of color, e.g. [0] for graylists. [0][0] is the first element of gray lists

            for (int i = 0; i < TrophyCards.Count; i++)
            {
                if (listofAmountForEachColor[i].Count >= TrophyCards[i].NumberOfCubesNeeded)
                    {
                        player.TrophyCards[i].NumberOwned++;
                        player.NumberOfTrophies++;
                        MessageBox.Show(player.Name + " gained 1 trophy of " + TrophyCards[i].Colour.ToString());
                    ///item to be removed
                        foreach (Cube itemRemove in listofAmountForEachColor[i])
                        {
                            previousColor = itemRemove.Colour;
                            bags.Add(itemRemove);
                            player.Cubes.Remove(itemRemove);
                        }
                        bags.Shuffle();
                    }
            }     
            
        }
        /// <summary>
        /// distinct values of the given lists of cubes.
        /// return a two dimentional lists. first element is the color, second element is the sequence of this color
        /// e.g. [0] for gray, [0][0] first element of graylists of cubes
        /// </summary>
        /// <param name="lists"></param>
        /// <returns></returns>
        private List<List<Cube>> DistinctListForEachColor(List<Cube> lists)
        {
            Contract.Requires(lists != null);
            List<Cube> AmountFor1 = new List<Cube>();
            List<Cube> AmountFor2 = new List<Cube>();
            List<Cube> AmountFor3 = new List<Cube>();
            List<Cube> AmountFor4 = new List<Cube>();
            List<Cube> AmountFor5 = new List<Cube>();
            List<List<Cube>> listofAmountForEachColor;

            //for each color of trophpy
            if (lists != null)
            {
                foreach (Cube cube in lists)
                {
                    if (cube.Colour == Color.Gray)
                    {
                        AmountFor1.Add(cube);
                    }
                    if (cube.Colour == Color.Blue)
                    {
                        AmountFor2.Add(cube);
                    }
                    if (cube.Colour == Color.Green)
                    {
                        AmountFor3.Add(cube);
                    }
                    if (cube.Colour == Color.Yellow)
                    {
                        AmountFor4.Add(cube);
                    }
                    if (cube.Colour == Color.Red)
                    {
                        AmountFor5.Add(cube);
                    }
                }
            }
            listofAmountForEachColor = new List<List<Cube>>() { AmountFor1, AmountFor2, AmountFor3, AmountFor4, AmountFor5 };
            return listofAmountForEachColor;
        }
        /// <summary>
        /// robot strategy
        /// </summary>
        private void robot()
        {
            IsGameEnd();
            Contract.Requires(computer.Cards.Count == 8);
            //since we already reshuffled after the human's turn, so computer has already reshuffled once
            //if there is still no available cards, computer skips its turn
            if (!CalculateCardsCanBePlacedOnSlots(computer))
	        {
		         MessageBox.Show("computer cannot doing anything due to the cards it have, your turn");
                 return;
	        }
            
            //after the above code, current hop tile and current card is set

                if (!IsDeckEnough(1)) //can the deck be drawn with 1 card?
                {
                    AddGraveyardToDeck();
                }
                CalculateComputersDesiredHopTiles();
                Card availableslot = AvailableSlot(currentComputerHopTile.CardsOnPC);

                //since we ve already calculated availalbe slots using CalculateComputersDesiredHopTiles
                //thus available must be not null
                
                availableslot.Value = currentComputerCard.Value;
                availableslot.Colour = currentComputerCard.Colour;

                Contract.Requires(computer.Cards.Contains(currentComputerCard));
                AddaCardFromDeck(computer, currentComputerCard);

                ///check again if there is available slots to be placed
                ///if nothing can be added, we will calculate the score
                Card availableslotAgain = AvailableSlot(currentComputerHopTile.CardsOnPC);
                Card availableslotAgainHuman = AvailableSlot(currentComputerHopTile.CardsOnPlayer);
                if (availableslotAgain == null && availableslotAgainHuman == null)
                {
                    Draw();
                    scoring(computer);
                }
                //if no available cards to be added anywhere
                if (!CalculateCardsCanBePlacedOnSlots(human))
                {
                    startReshuffle();
                    return;
                }
                Draw();
                
        }
        /// <summary>
        /// calculate computer's desired tiles. it is the as what user selects if the computer has the abaility to respond with that hop tiles
        /// if the computer cannot placed the hop tile that user selected, computer choose a random hop tile that can be placed
        /// </summary>
        private void CalculateComputersDesiredHopTiles()
        {
            List<Card> cardsCanBePlaced = new List<Card>(computer.CardsCanBePlacedOnSlots[currentHopTile.Cubes.Count - 1]);
            //currentHopTile is the hop tile that human selects. same as the currentCard
            if (cardsCanBePlaced.Count != 0) 
                ///if the computer can place cards on the hop tiles for which the human placed
            {
                ///develop the strategy
                currentComputerHopTile = currentHopTile;

                if (currentComputerHopTile.State.ToString("F") == "High")
                {
                    currentComputerCard = FindMaxCard(cardsCanBePlaced);
                }
                else if (currentComputerHopTile.State.ToString("F") == "Low")
                {
                    currentComputerCard = FindMinCard(cardsCanBePlaced);
                }
                if (!computer.Cards.Contains(currentComputerCard))
                {
                    throw new Exception();
                }
                return;
            }
            //if the computer cannot, the computer choose a tile out of 4 from the right, because the right provides more rewards 

            int chosen = 0;
            for (int i = 0; i < 4; i++)
            {
                if (i != currentHopTile.Cubes.Count - 1)
                {
                    if (computer.CardsCanBePlacedOnSlots[i].Count != 0)
                    {
                        chosen = i;
                    }
                }
            }

            cardsCanBePlaced = new List<Card>(computer.CardsCanBePlacedOnSlots[chosen]);
            //develop strategy
                if (HopTiles[chosen].State.ToString("F") == "High")
                {
                    currentComputerCard = FindMaxCard(cardsCanBePlaced);

                }
                else if (HopTiles[chosen].State.ToString("F") == "Low")
                {
                    currentComputerCard = FindMinCard(cardsCanBePlaced);
                }
                currentComputerHopTile = HopTiles[chosen];
        }

        /// <summary>
        /// find max card in a given list, used to develop computer gaming strategy
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        private Card FindMaxCard(List<Card> list)
        {
            Contract.Requires(list != null);
            Card max = new Card(Default, 0);
            foreach (Card item in list)
            {
                if (item.Value > max.Value)
                {
                    max = item;
                }
            }
            return max;
        }
        /// <summary>
        /// find min card ina given list
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        private Card FindMinCard(List<Card> list)
        {
            Contract.Requires(list != null);
            Card min = new Card(Default, 45);
            foreach (Card item in list)
            {
                if (item.Value < min.Value)
                {
                    min = item;
                }
            }
            return min;
        }

        /// <summary>
        /// automatic reshuffle strategy for computer
        /// it shuffles 4 cards in the computer's hand, and redraw 4
        /// </summary>
        private void computerReshuffle()
        {
            MessageBox.Show("computer has nothing to place, your turn");
            if (!IsDeckEnough(4))
            {
                AddGraveyardToDeck();
            }
            ShuffleCardsToPlayer(computer, 4, false);
            Draw();
        }

        /// <summary>
        /// set the three for one mode
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ThreeForOne_Click(object sender, EventArgs e)
        {
            MessageBox.Show("click on the trohpy you wanna trade on the right");
            threeforone = true;
        }

        /// <summary>
        /// only clickable after reshuffle mode is triggered
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReshuffle_Click(object sender, EventArgs e)
        {
            if (reshuffledcards.Count == 0)
            {
                MessageBox.Show("you havent chosen a card");
            }
            else
            {
                FinishReshuffle(human);
            }
        }

        /// <summary>
        /// start the game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Preparation();
                Draw();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        
    }
    //safe random
    public static class ThreadSafeRandom
    {
        [ThreadStatic]
        private static Random Local;

        public static Random ThisThreadsRandom
        {
            get { return Local ?? (Local = new Random(unchecked(Environment.TickCount * 31 + Thread.CurrentThread.ManagedThreadId))); }
        }
    }

    static class MyExtensions
    {
        public static void Shuffle<T>(this IList<T> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = ThreadSafeRandom.ThisThreadsRandom.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}
