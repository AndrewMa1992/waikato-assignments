﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace assignment2
{
    class Player
    {
        /// <summary>
        /// number of trophies by this player
        /// </summary>
        private int numberOfTrophies = 0;
        public int NumberOfTrophies { get { return numberOfTrophies; } set { numberOfTrophies = value; } }
        protected string name = "";
        public string Name { get { return name; } }

        /// <summary>
        /// number of cubes it has
        /// </summary>
        private List<Cube> cubes = new List<Cube>();
        public List<Cube> Cubes { get { return cubes; } set { cubes = value; } }

        /// <summary>
        /// numbe rof card it has
        /// </summary>
        private List<Card> cards = new List<Card>();
        public List<Card> Cards { get { return cards; } set { cards = value; } }

        /// <summary>
        /// number of trophy cards it has
        /// </summary>
        private List<TrophyCard> trophyCards;
        public List<TrophyCard> TrophyCards { get { return trophyCards; } set { trophyCards = value; } }

        /// <summary>
        /// this list is calculated whenever a turn is ended, the first element is the index of hoptiles, second element is the elements of available cards
        /// e.g. [0].count == 0 means that for the first hop tile, there is no available cards to be placed
        /// </summary>
        private List<List<Card>> cardsCanBePlacedOnSlots;
        public List<List<Card>> CardsCanBePlacedOnSlots { get { return cardsCanBePlacedOnSlots; } set { cardsCanBePlacedOnSlots = value; } }
        
        public Player()
        {
            List<Card> initialvalue = new List<Card>();
            cardsCanBePlacedOnSlots = new List<List<Card>>() { initialvalue, initialvalue, initialvalue, initialvalue };

            //initilise with random values
        }
    }
}
