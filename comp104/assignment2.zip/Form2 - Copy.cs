﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics.Contracts;
using System.Runtime.InteropServices;

namespace assignment2
{
    public partial class Form2 : Form
    {
        Color Default = Color.Azure;
        List<Cube> bags = new List<Cube>();
        List<Card> deck = new List<Card>();
        List<Card> Graveyard = new List<Card>();
        List<HopTile> HopTiles = new List<HopTile>();
        List<TrophyCard> TrophyCards = new List<TrophyCard>();

        /// <summary>
        /// list of picturebox for the player(human). we will create a list of click handler from this list
        /// so that the pictureboxes in this list is clickable
        /// </summary>
        List<PictureBox> PlayersPicBox = new List<PictureBox>();

        /// <summary>
        /// list of pic boxes of slots which belong to the hop tiles
        /// they are clickable as well, but only after the pic box in the PlayersPicBox is clicked
        /// </summary>
        List<PictureBox> HopTilesSlotPicBox = new List<PictureBox>();

        public static int formwidth = 1000;
        public static int formheight = 600;

        bool reshuffle = false;
        List<Card> reshuffledcards = new List<Card>();

        Card currentCard;
        HopTile currentHopTile;
        HopTile currentComputerHopTile;
        Card currentComputerCard;

        Human human = new Human();
        Computer computer = new Computer();
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Preparation()
        {
            generateRandomCubesAndCards();
            generateHopTiles();
            randomCubesOnTiles();
            ShuffleCardsToPlayer(human, 8, true);
            ShuffleCardsToPlayer(computer,8,true);
            generateAndPlaceTrophyCards();
            boundSlots();
            initControlsForCards();
            if (!CalculateCardsCanBePlacedOnSlots(human))
            {
                startReshuffle();
            }
        }
        /// <summary>
        /// generate new 4 hop tiles
        /// </summary>
        private void generateHopTiles()
        {

            for (int i = 0; i < 4; i++)
            {
                if (i%2 == 0)
                {
                    HopTiles.Add(new HopTile(HopTile.stateofHopTiles.High, i + 1, (PictureBox)this.Controls["HopTile" + (i+1).ToString()], (Label)this.Controls["HopTileLabel" + (i + 1).ToString()]));
                }
                else
                {
                    HopTiles.Add(new HopTile(HopTile.stateofHopTiles.Low, i + 1, (PictureBox)this.Controls["HopTile" + (i+1).ToString()], (Label)this.Controls["HopTileLabel" + (i + 1).ToString()]));
                }
            }
        }
        /// <summary>
        /// generate random lists of cubes in the bag, and random lists of cards on the deck
        /// </summary>
        private void generateRandomCubesAndCards()
        {
            //generate 45 randomised cubes and cards 
            for (int i = 1; i < 46; i++)
            {
                Color newcolor = Default;
                if (i<=13)
                {
                    newcolor = Color.Red;
                }
                else if (i<=24)
                {
                    newcolor = Color.Yellow;
                }
                else if (i<=33)
                {
                    newcolor = Color.Green;
                }
                else if (i<= 40)
                {
                    newcolor = Color.Blue;
                }
                else if (i<= 45)
                {
                    newcolor = Color.Gray;
                }
                bags.Add(new Cube(newcolor));
                deck.Add(new Card(newcolor, i));
            }
            bags.Shuffle();
            deck.Shuffle();

        }
        /// <summary>
        /// used for preparation at the start of the game
        /// generate randomly selected cubes from the bags to place on the hop tiles
        /// </summary>
        private void randomCubesOnTiles()
        {
            for (int i = 1; i <= 4; i++)
            {
                PlaceCubesOnTiles(i);
            }
        }
        /// <summary>
        /// Place the randomly drawn cubes onto the hop tiles
        /// </summary>
        /// <returns></returns>
        private void PlaceCubesOnTiles(int numberToBeDrawn)
        {
            List<Cube> cubetoPlace = new List<Cube>();
            //retrieve cubes from bags
            for (int i = 0; i < numberToBeDrawn; i++)
            {
                cubetoPlace.Add(bags[i]);
            }
            //remove the cubes which are retrieved from the bag
            for (int i = 0; i < numberToBeDrawn; i++)
            {
                bags.RemoveAt(0);
            }
            //bound the picturebox to the cubes inside hop tiles
            for (int i = 0; i < cubetoPlace.Count; i++)
            {
                cubetoPlace[i].BoundedBox = (PictureBox)this.Controls["HopTile" + numberToBeDrawn.ToString() + "_Cubes" + (i + 1).ToString()];
            }
            HopTiles[numberToBeDrawn-1].Cubes = cubetoPlace;
            currentHopTile = HopTiles[numberToBeDrawn-1];
            
        }
        /// <summary>
        /// shuffle the cards to computer and player
        /// </summary>
        private void ShuffleCardsToPlayer(Player player,int number,bool ispreparation)
        {
            ///if this isnt preparation, then we will discard the number, then draw again
            ///for the preparation part, no cards is in player's hand, so there is nothing to be discarded
            ///after preparation, players would have to remove same amount of cards 
            if (!ispreparation)
            {
                for (int i = 0; i < number; i++)
                {
                    Graveyard.Add(player.Cards[i]);
                }
                for (int i = 0; i < number; i++)
                {
                    player.Cards.RemoveAt(0);
                }
            }
            for (int i = 0; i < number; i++)
            {
                player.Cards.Add(deck[i]);
            }
            for (int i = 0; i < number; i++)
            {
                deck.RemoveAt(0);
            }
            
            //bound pictureboxes and label controls to the cards whic are shuffled to each player
            for (int i = 1; i < 9; i++)
            {
                if (player is Human)
                {
                    if (ispreparation)
                    {
                        PlayersPicBox.Add((PictureBox)this.Controls["humanDeck" + i.ToString()]);
                    }
                    human.Cards[i - 1].BoundedBox = PlayersPicBox[i-1]; 
                    ///both human.Cards.BoundedBox and PlayersPicBox add the same pictureBox, because
                    ///because they all belong to human right now
                    human.Cards[i - 1].BoundedLabel = (Label)this.Controls["humanDeckLabel" + i.ToString()];
                }
                else if (player is Computer)
                {
                    computer.Cards[i - 1].BoundedBox = (PictureBox)this.Controls["computerDeck" + i.ToString()];
                    computer.Cards[i - 1].BoundedLabel = (Label)this.Controls["computerDeckLabel" + i.ToString()];
                }
                
            }
            int a = 1;
        }
        /// <summary>
        /// generate and place the trophy cards
        /// </summary>
        private void generateAndPlaceTrophyCards()
        {
            TrophyCards.Add(new TrophyCard(1, Color.Gray));
            TrophyCards.Add(new TrophyCard(1, Color.Blue));
            TrophyCards.Add(new TrophyCard(1, Color.Green));
            TrophyCards.Add(new TrophyCard(1, Color.Yellow));
            TrophyCards.Add(new TrophyCard(1, Color.Red));
            human.TrophyCards = new List<TrophyCard>(TrophyCards);
            computer.TrophyCards = new List<TrophyCard>(TrophyCards);
            for (int i = 0; i < 5; i++)
            {
                human.TrophyCards[i].BoundedBox = (PictureBox)this.Controls["Trophy" + (i + 1).ToString()];
                human.TrophyCards[i].BoundedLabel = (Label)this.Controls["TrophyLabel" + (i + 1).ToString()];
                human.TrophyCards[i].BoundedLabelOwn = (Label)this.Controls["TrophyLabelOwn" + (i + 1).ToString()];
            }
        }
        /// <summary>
        /// distribute slots
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void boundSlots()
        {
            for (int hcount = 1; hcount <= 4; hcount++) //count for hop tiles
            {
                for (int scount = 1; scount <= hcount; scount++) //each slots which belong to each hpo tile
                {
                    HopTilesSlotPicBox.Add((PictureBox)this.Controls["HopTile" + hcount.ToString() + "_h" + scount.ToString()]);
                    HopTiles[hcount-1].CardsOnPlayer.Add(new Card(Default, 0, (PictureBox)this.Controls["HopTile" + hcount.ToString() + "_h" + scount.ToString()], (Label)this.Controls["HopTile" + hcount.ToString() + "_hLabel" + scount.ToString()]));
                    HopTiles[hcount-1].CardsOnPC.Add(new Card(Default, 0, (PictureBox)this.Controls["HopTile" + hcount.ToString() + "_c" + scount.ToString()], (Label)this.Controls["HopTile" + hcount.ToString() + "_cLabel" + scount.ToString()]));
                }
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                Preparation();
                Draw();
            }
            catch (Exception )
            {
                MessageBox.Show("Ops, something is going wrong, please run again");
            }
            
            
            
        }
        private void Draw()
        {
            foreach (Card item in human.Cards)
            {
                item.Draw();
            }
            foreach (Card item in computer.Cards)
            {
                item.Draw();
            }
            foreach (HopTile item in HopTiles)
            {
                item.Draw();
            }
            foreach (TrophyCard item in human.TrophyCards)
            {
                item.Draw();
            }
            
        }

        private void Form2_Resize(object sender, EventArgs e)
        {
            
        }

        private void initControlsForCards()
         {
            Control.ControlCollection controls = this.Controls;
            foreach (Control c in controls)  
             {
                 c.Anchor = ( AnchorStyles.Bottom | AnchorStyles.Right);
                 if (c is PictureBox)
                 {
                     if (PlayersPicBox.Contains(c))
	                {
		                 c.MouseClick += (sender, e) => {
                             ///inside the click event for each picturebox on human's side
                             ///it loops through and set the currentcard to the one being clicked
                             
                             PictureBox currentpic = (PictureBox)c;
                             foreach (Card item in human.Cards)
                             {
                                 if (item.BoundedBox == c)
                                 {
                                     if (currentCard != null)
                                     {
                                         AnimateDown(currentCard.BoundedBox);
                                     }
                                         currentCard = item;
                                         AnimateUp(c);
                                         ///if the player is reshuffling
                                         if (reshuffle)
                                         {
                                             if (reshuffledcards.Count == 4)
                                             {
                                                 FinishReshuffle(human);
                                                 return;
                                             }
                                             reshuffledcards.Add(item);
                                             return;
                                         }
                                         currentCard = item;
                                         Draw();
                                         return;
                                 }
                             }
                         };  
	                }
                    else if (HopTilesSlotPicBox.Contains(c)) //slots
                    {
                        c.MouseClick += (sender, e) => {
                             ///inside the click event for each picturebox on the slots of the current hop tile
                            if (currentCard != null)
                            {
                                
                                currentHopTile = FindHopTile((PictureBox)c);
                                if (!human.CardsCanBePlacedOnSlots[currentHopTile.Value-1].Contains(currentCard))
                                    ///if the selected card (current card) is CANNOT be put into this slot
                                {
                                    MessageBox.Show("You can't add this, please select another one");
                                    return;
                                }

                                Card availableslot = AvailableSlot(currentHopTile.CardsOnPlayer);
                                //find an availble slot
                                if (availableslot != null)
                                {
                                    AnimateDown(currentCard.BoundedBox);
                                    ///add a card from the deck 
                                    if (!IsDeckEnough(1)) //can the deck be drawn with 1 card
                                    {
                                        AddGraveyardToDeck();
                                    }
                                    //pass the value of the current selected card to the slot
                                    availableslot.Value = currentCard.Value;
                                    availableslot.Colour = currentCard.Colour;

                                    AddaCardFromDeck(human, currentCard);

                                    ///check again if there is available slots to be placed
                                    ///if nothing can be added, we will calculate the score
                                    Card availableslotAgain = AvailableSlot(currentHopTile.CardsOnPlayer);
                                    Card availableslotAgainPC = AvailableSlot(currentHopTile.CardsOnPC);
                                    if (availableslotAgain == null && availableslotAgainPC == null)
                                    {
                                        Draw();
                                        scoring(human);
                                        return;
                                    }
                                    ///if there is available slot, we will switch to the next turn
                                    ///which is the computer's turn. we check if computer has available cards
                                    if (!CalculateCardsCanBePlacedOnSlots(computer))
                                    {
                                        computerReshuffle();
                                        return;
                                    }
                                    Draw();
                                    robot();
                                    return;
                                }

                            }
                         
                         }; 
                    }
                 }
               
             }
         }

        private void AnimateUp(Control control)
        {
            
                int directionY = 10;
                int destination = control.Top - 10;
                while (control.Top != destination)
                {
                    try
                    {
                        if (control.Top != destination)
                        {
                            this.Invoke((Action)delegate()
                            {
                                control.Top -= directionY;
                            });
                        }
                        Thread.Sleep(50);
                    }
                    catch
                    {
                        MessageBox.Show("animation failed");
                    }
                }

        }
        private void AnimateDown(Control control)
        {
                int directionY = 10;
                int destination = control.Top + 10;
                while (control.Top != destination)
                {
                    try
                    {
                        if (control.Top != destination)
                        {
                            this.Invoke((Action)delegate()
                            {
                                control.Top += directionY;
                            });
                        }
                        Thread.Sleep(50);
                    }
                    catch
                    {
                        MessageBox.Show("animation failed");
                    }
                }

        }
        /// <summary>
        /// this find the available slot which has not yet been placed upon, otherwise it returns null
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        private Card AvailableSlot(List<Card> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Value == 0)
                {
                    return list[i]; //if there is a value which is 0, thus this means this slot hasn't been
                    //placed, thus it is a available slot
                }
            }
            return null;
        }

        private HopTile FindHopTile(PictureBox picslot)
        {
            foreach (HopTile item in HopTiles)
            {
                foreach (Card card in item.CardsOnPlayer)
                {
                    if (card.BoundedBox == picslot)
                    {
                        return item;
                    }
                }
            }
            return null;
        }
        /// <summary>
        /// remove the item(card) from the player's hand, and add the top card from the deck to hand
        /// </summary>
        /// <param name="player"></param>
        /// <param name="item"></param> card to be removed
        private void AddaCardFromDeck(Player player,Card item)
        {
            if (player is Computer)
            {
                int value = deck[0].Value;
            }
            
            deck[0].BoundedBox = item.BoundedBox;
            deck[0].BoundedLabel = item.BoundedLabel;
            if (player is Human)
            {
                human.Cards.Remove(item);//remove the current selected
                human.Cards.Add(deck[0]);//add the top card of the deck
                                     
            }
            else
            {
                computer.Cards.Remove(item);
                if (computer.Cards.Count == 8)
                {
                    throw new Exception();
                }
                computer.Cards.Add(deck[0]);
            }
            deck.RemoveAt(0);
        }

        
        /// <summary>
        /// calculate the list of cards that can be placed, 
        /// return true if players can place cards, and values of CardsCanBePlacedOnSlots of the player is set
        /// return false otherwise
        /// </summary>
        /// <param name="player"></param>
        private bool CalculateCardsCanBePlacedOnSlots(Player player)
        {
            List<Card> AllCardsInHand = new List<Card>();
            List<Card> AllSlotsInTilesForThisPlayer = new List<Card>();
            List<Card> cardsCanBePlacedInHand = new List<Card>();

            List<Color> distinguishedcolorsCube = new List<Color>();
            List<Color> distinguishedcolorsSlot = new List<Color>();

            bool hasvalue = false;
            for (int i = 0; i < 4; i++)
            {
                cardsCanBePlacedInHand = new List<Card>();//rest the values
                distinguishedcolorsCube = new List<Color>();
                distinguishedcolorsSlot = new List<Color>();
                if (player is Human)
                {
                    AllSlotsInTilesForThisPlayer = new List<Card>(HopTiles[i].CardsOnPlayer);
                }
                else
                {
                    AllSlotsInTilesForThisPlayer = new List<Card>(HopTiles[i].CardsOnPC);
                }

                    //all the distinguished color in the slots for this player
                    AllSlotsInTilesForThisPlayer.RemoveAll(Cards => Cards.Value == 0);
                    foreach (Card item in AllSlotsInTilesForThisPlayer)
                    {
                        distinguishedcolorsSlot.Add(item.Colour);
                    }
                    //distinguishedcolorsSlot = distinguishedcolorsSlot.Distinct().ToList<Color>();


                    //all the distinguished color in the tile for this player
                    foreach (Cube item in HopTiles[i].Cubes)
                    {
                        distinguishedcolorsCube.Add(item.Colour);
                    }
                    

                    //remove the duplicates of distinguishedcolor for CUBE and distingusihed color for SLOT
                    //so only the color we want to add is left in this list distinguishedcolorsCube
                        foreach (Color item in distinguishedcolorsSlot)
                        {
                            distinguishedcolorsCube.Remove(item);

                        }
                        distinguishedcolorsCube = distinguishedcolorsCube.Distinct().ToList<Color>();
                    

                    foreach (Card cardsinhand in player.Cards)
                    {
                        foreach (Color Cubecolor in distinguishedcolorsCube)
                        {
                            if (Cubecolor == cardsinhand.Colour)
                            {
                                cardsCanBePlacedInHand.Add(cardsinhand);
                            }
                        }
                    }
                    if (cardsCanBePlacedInHand.Count != 0)
                    {
                        hasvalue = true;
                        if (player is Human)
                        {
                            human.CardsCanBePlacedOnSlots[i] = new List<Card>(cardsCanBePlacedInHand);
                            
                        }
                        else
                        {
                            computer.CardsCanBePlacedOnSlots[i] = new List<Card>(cardsCanBePlacedInHand);
                        }
                    }
                    else //if no values can be placed in this tile
                    {
                        if (player is Human)
                        {
                            human.CardsCanBePlacedOnSlots[i].Clear();
                        }
                        else
                        {
                            computer.CardsCanBePlacedOnSlots[i].Clear();
                        }
                    }
                }
            return hasvalue;
            
        }
        /// <summary>
        /// Start the reshuffle if the user cannot place any cards on the tile
        /// </summary>
        private void startReshuffle()
        {
            MessageBox.Show("you don't have anything to place, please select up to 4 cards in your hand to reshuffle. press the button to finish");
            reshuffle = true;
            btnReshuffle.Enabled = true;
        }    
        /// <summary>
        /// Finish the reshuffle process after user chooses up to 4 cards
        /// </summary>
        /// <param name="player"></param>
        private void FinishReshuffle(Player player)
        {
            if (!IsDeckEnough(reshuffledcards.Count)) //can the deck be drawn with these card?
            {
                AddGraveyardToDeck();
            }
            ShuffleCardsToPlayer(player, reshuffledcards.Count, false);
            MessageBox.Show("reshuffled successful");
            if (!CalculateCardsCanBePlacedOnSlots(player))
            {
                MessageBox.Show("You cant doing anything again even if you ve already shuffled once, your turn is ended");
            }
            reshuffle = false;//rest the value
            btnReshuffle.Enabled = false;
            Draw();

            robot();
        }
        /// <summary>
        /// check if the deck can be drawn with the provided number
        /// return true if yes, otherwise false
        /// </summary>
        /// <param name="numberToBeDrawn"></param>
        /// <returns></returns>
        /// 
        private bool IsDeckEnough(int numberToBeDrawn)
        {
            if (numberToBeDrawn <= deck.Count)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// this method is called is deck is not enough, all of the cards in the disposable deck is filled into
        /// the main deck, then main deck is shuffled
        /// </summary>
        private void AddGraveyardToDeck()
        {
            foreach (Card item in Graveyard)
            {
                deck.Add(item);

            }
            Graveyard.Clear();
            deck.Shuffle();
        }

        private void scoring(Player player)
        {
            int playerscore = 0;
            foreach (Card item in currentHopTile.CardsOnPlayer)
            {
                playerscore += item.Value;
            }
            int computerscore = 0;
            foreach (Card item in currentHopTile.CardsOnPC)
            {
                computerscore += item.Value;
            }
            if (computerscore == playerscore)
            {
                Win(player);
                return;
            }
            if (currentHopTile.State.ToString("F") == "High")
            {
                if (computerscore > playerscore)
                {
                    Win(computer);
                    return;
                }
                else
                {
                    Win(human);
                    return;
                }
            }
            else
            {
                if (computerscore > playerscore)
                {
                    Win(human);
                    return;
                }
                else
                {
                    Win(computer);
                    return;
                }
            }
        }

        private void Win(Player player)
        {
            MessageBox.Show(player.Name + " Wins");
            player.Cubes.AddRange(currentHopTile.Cubes);//winnner takes the cubes on the hop tiles
            foreach (Cube item in currentHopTile.Cubes)
            {
                MessageBox.Show(player.Name+ " gained 1" + item.Colour);
            }
            Graveyard.AddRange(currentHopTile.CardsOnPC);
            Graveyard.AddRange(currentHopTile.CardsOnPlayer); //winner discards the cards on both sides of the tile
            if (currentHopTile.State.ToString("F") == "High")//switch the state
            {
                currentHopTile.State = HopTile.stateofHopTiles.Low;
            }
            else
            {
                currentHopTile.State = HopTile.stateofHopTiles.High;
            }
            PlaceCubesOnTiles(currentHopTile.Cubes.Count); //winner place cubes

            foreach (Card item in currentHopTile.CardsOnPC) //clear the slots
            {
                item.Colour = Default;
                item.Value = 0;
            }
            foreach (Card item in currentHopTile.CardsOnPlayer)
            {
                item.Colour = Default;
                item.Value = 0;
            }

            CheckTrophy(player);
            Draw();

            if (player is Human) //if the winner human, robot starts the next turn
                //otherwise the computer wins, so do nothing
            {
                MessageBox.Show("robot's turn");
                robot();
                return;
            }
            MessageBox.Show("your turn");
            

        }

        /// <summary>
        /// check if the player is qualified for a trophy, this is only called after a tile is scored
        /// </summary>
        /// <param name="player"></param>
        private void CheckTrophy(Player player)
        {
            List<Cube> AmountFor1 = new List<Cube>();
            List<Cube> AmountFor2 = new List<Cube>();
            List<Cube> AmountFor3 = new List<Cube>();
            List<Cube> AmountFor4 = new List<Cube>();
            List<Cube> AmountFor5 = new List<Cube>();
            List<List<Cube>> listofAmountForEachColor;

            //for each color of trophpy
            foreach (Cube cube in player.Cubes)
            {
                if (cube.Colour == Color.Gray)
                {
                    AmountFor1.Add(cube);
                }
                if (cube.Colour == Color.Blue)
                {
                    AmountFor2.Add(cube);
                }
                if (cube.Colour == Color.Green)
                {
                    AmountFor3.Add(cube);
                }
                if (cube.Colour == Color.Yellow)
                {
                    AmountFor4.Add(cube);
                }
                if (cube.Colour == Color.Red)
                {
                    AmountFor5.Add(cube);
                }
            }
            listofAmountForEachColor = new List<List<Cube>>() { AmountFor1, AmountFor2, AmountFor3, AmountFor4, AmountFor5 };

            for (int i = 0; i < TrophyCards.Count; i++)
            {
                if (listofAmountForEachColor[i].Count >= TrophyCards[i].NumberOfCubesNeeded)
                    {
                        player.TrophyCards[i].NumberOwned++;
                        MessageBox.Show(player.Name + " gained 1 trophy of " + TrophyCards[i].Colour.ToString());
                        foreach (Cube itemRemove in listofAmountForEachColor[i])
                        {
                            bags.Add(itemRemove);
                            player.Cubes.Remove(itemRemove);
                        }
                        bags.Shuffle();
                    }
            }     
            
        }

        private void robot()
        {
            Contract.Requires(computer.Cards.Count == 8);
            //since we already reshuffled after the human's turn, so computer has already reshuffled once
            //if there is still no available cards, computer skips its turn
            if (!CalculateCardsCanBePlacedOnSlots(computer))
	        {
		         MessageBox.Show("computer cannot doing anything due to the cards it have, your turn");
                 return;
	        }
            
            //after the above code, current hop tile and current card is set

                if (!IsDeckEnough(1)) //can the deck be drawn with 1 card?
                {
                    AddGraveyardToDeck();
                }
                CalculateComputersDesiredHopTiles();
                Card availableslot = AvailableSlot(currentComputerHopTile.CardsOnPC);

                //since we ve already calculated 
                //pass the value of the current selected card to the slot
                availableslot.Value = currentComputerCard.Value;
                availableslot.Colour = currentComputerCard.Colour;

                if (!computer.Cards.Contains(currentComputerCard))
                {
                    throw new Exception();
                }
                AddaCardFromDeck(computer, currentComputerCard);

                ///check again if there is available slots to be placed
                ///if nothing can be added, we will calculate the score
                Card availableslotAgain = AvailableSlot(currentComputerHopTile.CardsOnPC);
                Card availableslotAgainHuman = AvailableSlot(currentComputerHopTile.CardsOnPlayer);
                if (availableslotAgain == null && availableslotAgainHuman == null)
                {
                    Draw();
                    scoring(computer);
                }
                //if no available cards to be added anywhere
                if (!CalculateCardsCanBePlacedOnSlots(human))
                {
                    startReshuffle();
                    return;
                }
                Draw();
                
        }
        private void check()
        {
            if (computer.Cards.Count == 9)
	{
        MessageBox.Show("aaa");
        throw new Exception();
	}
            
        }
        /// <summary>
        /// calculate computer's desired tiles. it is the as what user selects if the computer has the abaility to respond with that hop tiles
        /// if the computer cannot placed the hop tile that user selected, computer choose a random hop tile that can be placed
        /// </summary>
        private void CalculateComputersDesiredHopTiles()
        {
            List<Card> cardsCanBePlaced = new List<Card>(computer.CardsCanBePlacedOnSlots[currentHopTile.Cubes.Count - 1]);
            //currentHopTile is the hop tile that human selects. same as the currentCard
            if (cardsCanBePlaced.Count != 0) 
                ///if the computer can place cards on the hop tiles for which the human placed
            {
                currentComputerHopTile = currentHopTile;

                if (currentComputerHopTile.State.ToString("F") == "High")
                {
                    currentComputerCard = FindMaxCard(cardsCanBePlaced);
                }
                else if (currentComputerHopTile.State.ToString("F") == "Low")
                {
                    currentComputerCard = FindMinCard(cardsCanBePlaced);
                }
                if (!computer.Cards.Contains(currentComputerCard))
                {
                    throw new Exception();
                }
                return;
            }
            //if the computer cannot, the computer choose a tile out of 4 in its best interest

            int chosen = 0;
            for (int i = 0; i < 4; i++)
            {
                if (i != currentHopTile.Cubes.Count - 1)
                {
                    if (computer.CardsCanBePlacedOnSlots[i].Count != 0)
                    {
                        chosen = i;
                    }
                }
            }

            cardsCanBePlaced = new List<Card>(computer.CardsCanBePlacedOnSlots[chosen]);
                if (HopTiles[chosen].State.ToString("F") == "High")
                {
                    currentComputerCard = FindMaxCard(cardsCanBePlaced);

                }
                else if (HopTiles[chosen].State.ToString("F") == "Low")
                {
                    currentComputerCard = FindMinCard(cardsCanBePlaced);
                }
                if (!computer.Cards.Contains(currentComputerCard))
                {
                    throw new Exception();
                }
                currentComputerHopTile = HopTiles[chosen];
        }

        private Card FindMaxCard(List<Card> list)
        {
            Card max = new Card(Default, 0);
            foreach (Card item in list)
            {
                if (item.Value > max.Value)
                {
                    max = item;
                }
            }
            return max;
        }

        private Card FindMinCard(List<Card> list)
        {
            Card min = new Card(Default, 45);
            foreach (Card item in list)
            {
                if (item.Value < min.Value)
                {
                    min = item;
                }
            }
            return min;
        }

        private void computerReshuffle()
        {
            MessageBox.Show("computer has nothing to place, your turn");
            ShuffleCardsToPlayer(computer, 4, false);
            Draw();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (reshuffledcards.Count == 0)
            {
                MessageBox.Show("you havent chosen a card");
            }
            else
            {
                FinishReshuffle(human);
            }
        }

        
    }
    //safe random
    public static class ThreadSafeRandom
    {
        [ThreadStatic]
        private static Random Local;

        public static Random ThisThreadsRandom
        {
            get { return Local ?? (Local = new Random(unchecked(Environment.TickCount * 31 + Thread.CurrentThread.ManagedThreadId))); }
        }
    }

    static class MyExtensions
    {
        public static void Shuffle<T>(this IList<T> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = ThreadSafeRandom.ThisThreadsRandom.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}
