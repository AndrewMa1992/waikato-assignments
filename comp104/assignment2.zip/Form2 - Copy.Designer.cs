﻿namespace assignment2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.humanDeck8 = new System.Windows.Forms.PictureBox();
            this.humanDeck7 = new System.Windows.Forms.PictureBox();
            this.humanDeck5 = new System.Windows.Forms.PictureBox();
            this.humanDeck6 = new System.Windows.Forms.PictureBox();
            this.humanDeck1 = new System.Windows.Forms.PictureBox();
            this.humanDeck2 = new System.Windows.Forms.PictureBox();
            this.humanDeck3 = new System.Windows.Forms.PictureBox();
            this.humanDeck4 = new System.Windows.Forms.PictureBox();
            this.computerDeck1 = new System.Windows.Forms.PictureBox();
            this.computerDeck2 = new System.Windows.Forms.PictureBox();
            this.computerDeck3 = new System.Windows.Forms.PictureBox();
            this.computerDeck4 = new System.Windows.Forms.PictureBox();
            this.computerDeck5 = new System.Windows.Forms.PictureBox();
            this.computerDeck6 = new System.Windows.Forms.PictureBox();
            this.computerDeck7 = new System.Windows.Forms.PictureBox();
            this.computerDeck8 = new System.Windows.Forms.PictureBox();
            this.HopTile1 = new System.Windows.Forms.PictureBox();
            this.HopTile2 = new System.Windows.Forms.PictureBox();
            this.HopTile3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c2 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_c4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h3 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h2 = new System.Windows.Forms.PictureBox();
            this.HopTile4_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile3_c3 = new System.Windows.Forms.PictureBox();
            this.HopTile3_c2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile3_h3 = new System.Windows.Forms.PictureBox();
            this.HopTile3_h2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile1_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_h2 = new System.Windows.Forms.PictureBox();
            this.HopTile2_h1 = new System.Windows.Forms.PictureBox();
            this.HopTile1_c1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_c2 = new System.Windows.Forms.PictureBox();
            this.HopTile2_c1 = new System.Windows.Forms.PictureBox();
            this.humanDeckl1 = new System.Windows.Forms.Label();
            this.humanDeckLabel1 = new System.Windows.Forms.Label();
            this.humanDeckLabel2 = new System.Windows.Forms.Label();
            this.humanDeckLabel4 = new System.Windows.Forms.Label();
            this.humanDeckLabel3 = new System.Windows.Forms.Label();
            this.humanDeckLabel8 = new System.Windows.Forms.Label();
            this.humanDeckLabel7 = new System.Windows.Forms.Label();
            this.humanDeckLabel6 = new System.Windows.Forms.Label();
            this.humanDeckLabel5 = new System.Windows.Forms.Label();
            this.computerDeckLabel4 = new System.Windows.Forms.Label();
            this.computerDeckLabel3 = new System.Windows.Forms.Label();
            this.computerDeckLabel2 = new System.Windows.Forms.Label();
            this.computerDeckLabel1 = new System.Windows.Forms.Label();
            this.computerDeckLabel8 = new System.Windows.Forms.Label();
            this.computerDeckLabel7 = new System.Windows.Forms.Label();
            this.computerDeckLabel6 = new System.Windows.Forms.Label();
            this.computerDeckLabel5 = new System.Windows.Forms.Label();
            this.HopTileLabel1 = new System.Windows.Forms.Label();
            this.HopTileLabel3 = new System.Windows.Forms.Label();
            this.HopTileLabel2 = new System.Windows.Forms.Label();
            this.HopTileLabel4 = new System.Windows.Forms.Label();
            this.HopTile1_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile2_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile2_cLabel2 = new System.Windows.Forms.Label();
            this.HopTile3_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile3_cLabel3 = new System.Windows.Forms.Label();
            this.HopTile3_cLabel2 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel2 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel1 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel4 = new System.Windows.Forms.Label();
            this.HopTile4_cLabel3 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel2 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel4 = new System.Windows.Forms.Label();
            this.HopTile4_hLabel3 = new System.Windows.Forms.Label();
            this.HopTile2_hLabel2 = new System.Windows.Forms.Label();
            this.HopTile2_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile3_hLabel3 = new System.Windows.Forms.Label();
            this.HopTile3_hLabel2 = new System.Windows.Forms.Label();
            this.HopTile3_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile1_hLabel1 = new System.Windows.Forms.Label();
            this.HopTile1_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile2_Cubes2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_Cubes2 = new System.Windows.Forms.PictureBox();
            this.HopTile3_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes2 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes1 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes4 = new System.Windows.Forms.PictureBox();
            this.HopTile4_Cubes3 = new System.Windows.Forms.PictureBox();
            this.HopTile3_Cubes3 = new System.Windows.Forms.PictureBox();
            this.btnReshuffle = new System.Windows.Forms.Button();
            this.Trophy2 = new System.Windows.Forms.PictureBox();
            this.Trophy3 = new System.Windows.Forms.PictureBox();
            this.Trophy4 = new System.Windows.Forms.PictureBox();
            this.Trophy1 = new System.Windows.Forms.PictureBox();
            this.TrophyLabel1 = new System.Windows.Forms.Label();
            this.TrophyLabel2 = new System.Windows.Forms.Label();
            this.TrophyLabel4 = new System.Windows.Forms.Label();
            this.TrophyLabel3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn4 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn3 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn2 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TrophyLabelOwn5 = new System.Windows.Forms.Label();
            this.TrophyLabel5 = new System.Windows.Forms.Label();
            this.Trophy5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy5)).BeginInit();
            this.SuspendLayout();
            // 
            // humanDeck8
            // 
            this.humanDeck8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck8.Location = new System.Drawing.Point(693, 415);
            this.humanDeck8.Name = "humanDeck8";
            this.humanDeck8.Size = new System.Drawing.Size(90, 120);
            this.humanDeck8.TabIndex = 7;
            this.humanDeck8.TabStop = false;
            // 
            // humanDeck7
            // 
            this.humanDeck7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.humanDeck7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck7.Location = new System.Drawing.Point(598, 415);
            this.humanDeck7.Name = "humanDeck7";
            this.humanDeck7.Size = new System.Drawing.Size(90, 120);
            this.humanDeck7.TabIndex = 16;
            this.humanDeck7.TabStop = false;
            // 
            // humanDeck5
            // 
            this.humanDeck5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck5.Location = new System.Drawing.Point(408, 415);
            this.humanDeck5.Name = "humanDeck5";
            this.humanDeck5.Size = new System.Drawing.Size(90, 120);
            this.humanDeck5.TabIndex = 18;
            this.humanDeck5.TabStop = false;
            // 
            // humanDeck6
            // 
            this.humanDeck6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck6.Location = new System.Drawing.Point(503, 415);
            this.humanDeck6.Name = "humanDeck6";
            this.humanDeck6.Size = new System.Drawing.Size(90, 120);
            this.humanDeck6.TabIndex = 17;
            this.humanDeck6.TabStop = false;
            // 
            // humanDeck1
            // 
            this.humanDeck1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck1.Location = new System.Drawing.Point(27, 415);
            this.humanDeck1.Name = "humanDeck1";
            this.humanDeck1.Size = new System.Drawing.Size(90, 120);
            this.humanDeck1.TabIndex = 22;
            this.humanDeck1.TabStop = false;
            // 
            // humanDeck2
            // 
            this.humanDeck2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck2.Location = new System.Drawing.Point(123, 415);
            this.humanDeck2.Name = "humanDeck2";
            this.humanDeck2.Size = new System.Drawing.Size(90, 120);
            this.humanDeck2.TabIndex = 21;
            this.humanDeck2.TabStop = false;
            // 
            // humanDeck3
            // 
            this.humanDeck3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck3.Location = new System.Drawing.Point(218, 415);
            this.humanDeck3.Name = "humanDeck3";
            this.humanDeck3.Size = new System.Drawing.Size(90, 120);
            this.humanDeck3.TabIndex = 20;
            this.humanDeck3.TabStop = false;
            // 
            // humanDeck4
            // 
            this.humanDeck4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.humanDeck4.Location = new System.Drawing.Point(313, 415);
            this.humanDeck4.Name = "humanDeck4";
            this.humanDeck4.Size = new System.Drawing.Size(90, 120);
            this.humanDeck4.TabIndex = 19;
            this.humanDeck4.TabStop = false;
            // 
            // computerDeck1
            // 
            this.computerDeck1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck1.Location = new System.Drawing.Point(28, 12);
            this.computerDeck1.Name = "computerDeck1";
            this.computerDeck1.Size = new System.Drawing.Size(90, 120);
            this.computerDeck1.TabIndex = 30;
            this.computerDeck1.TabStop = false;
            // 
            // computerDeck2
            // 
            this.computerDeck2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck2.Location = new System.Drawing.Point(123, 12);
            this.computerDeck2.Name = "computerDeck2";
            this.computerDeck2.Size = new System.Drawing.Size(90, 120);
            this.computerDeck2.TabIndex = 29;
            this.computerDeck2.TabStop = false;
            // 
            // computerDeck3
            // 
            this.computerDeck3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck3.Location = new System.Drawing.Point(218, 12);
            this.computerDeck3.Name = "computerDeck3";
            this.computerDeck3.Size = new System.Drawing.Size(90, 120);
            this.computerDeck3.TabIndex = 28;
            this.computerDeck3.TabStop = false;
            // 
            // computerDeck4
            // 
            this.computerDeck4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck4.Location = new System.Drawing.Point(313, 12);
            this.computerDeck4.Name = "computerDeck4";
            this.computerDeck4.Size = new System.Drawing.Size(90, 120);
            this.computerDeck4.TabIndex = 27;
            this.computerDeck4.TabStop = false;
            // 
            // computerDeck5
            // 
            this.computerDeck5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck5.Location = new System.Drawing.Point(408, 12);
            this.computerDeck5.Name = "computerDeck5";
            this.computerDeck5.Size = new System.Drawing.Size(90, 120);
            this.computerDeck5.TabIndex = 26;
            this.computerDeck5.TabStop = false;
            // 
            // computerDeck6
            // 
            this.computerDeck6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck6.Location = new System.Drawing.Point(503, 12);
            this.computerDeck6.Name = "computerDeck6";
            this.computerDeck6.Size = new System.Drawing.Size(90, 120);
            this.computerDeck6.TabIndex = 25;
            this.computerDeck6.TabStop = false;
            // 
            // computerDeck7
            // 
            this.computerDeck7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck7.Location = new System.Drawing.Point(598, 12);
            this.computerDeck7.Name = "computerDeck7";
            this.computerDeck7.Size = new System.Drawing.Size(90, 120);
            this.computerDeck7.TabIndex = 24;
            this.computerDeck7.TabStop = false;
            // 
            // computerDeck8
            // 
            this.computerDeck8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.computerDeck8.Location = new System.Drawing.Point(693, 12);
            this.computerDeck8.Name = "computerDeck8";
            this.computerDeck8.Size = new System.Drawing.Size(90, 120);
            this.computerDeck8.TabIndex = 23;
            this.computerDeck8.TabStop = false;
            // 
            // HopTile1
            // 
            this.HopTile1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile1.Location = new System.Drawing.Point(28, 208);
            this.HopTile1.Name = "HopTile1";
            this.HopTile1.Size = new System.Drawing.Size(184, 117);
            this.HopTile1.TabIndex = 31;
            this.HopTile1.TabStop = false;
            // 
            // HopTile2
            // 
            this.HopTile2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2.Location = new System.Drawing.Point(218, 208);
            this.HopTile2.Name = "HopTile2";
            this.HopTile2.Size = new System.Drawing.Size(184, 117);
            this.HopTile2.TabIndex = 34;
            this.HopTile2.TabStop = false;
            // 
            // HopTile3
            // 
            this.HopTile3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3.Location = new System.Drawing.Point(408, 208);
            this.HopTile3.Name = "HopTile3";
            this.HopTile3.Size = new System.Drawing.Size(184, 117);
            this.HopTile3.TabIndex = 37;
            this.HopTile3.TabStop = false;
            // 
            // HopTile4_c1
            // 
            this.HopTile4_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c1.Location = new System.Drawing.Point(598, 159);
            this.HopTile4_c1.Name = "HopTile4_c1";
            this.HopTile4_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c1.TabIndex = 41;
            this.HopTile4_c1.TabStop = false;
            // 
            // HopTile4
            // 
            this.HopTile4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4.Location = new System.Drawing.Point(598, 208);
            this.HopTile4.Name = "HopTile4";
            this.HopTile4.Size = new System.Drawing.Size(184, 117);
            this.HopTile4.TabIndex = 40;
            this.HopTile4.TabStop = false;
            // 
            // HopTile4_c2
            // 
            this.HopTile4_c2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c2.Location = new System.Drawing.Point(635, 159);
            this.HopTile4_c2.Name = "HopTile4_c2";
            this.HopTile4_c2.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c2.TabIndex = 47;
            this.HopTile4_c2.TabStop = false;
            // 
            // HopTile4_c3
            // 
            this.HopTile4_c3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c3.Location = new System.Drawing.Point(672, 159);
            this.HopTile4_c3.Name = "HopTile4_c3";
            this.HopTile4_c3.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c3.TabIndex = 49;
            this.HopTile4_c3.TabStop = false;
            // 
            // HopTile4_c4
            // 
            this.HopTile4_c4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_c4.Location = new System.Drawing.Point(709, 159);
            this.HopTile4_c4.Name = "HopTile4_c4";
            this.HopTile4_c4.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_c4.TabIndex = 51;
            this.HopTile4_c4.TabStop = false;
            // 
            // HopTile4_h4
            // 
            this.HopTile4_h4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h4.Location = new System.Drawing.Point(709, 331);
            this.HopTile4_h4.Name = "HopTile4_h4";
            this.HopTile4_h4.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h4.TabIndex = 55;
            this.HopTile4_h4.TabStop = false;
            // 
            // HopTile4_h3
            // 
            this.HopTile4_h3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h3.Location = new System.Drawing.Point(672, 331);
            this.HopTile4_h3.Name = "HopTile4_h3";
            this.HopTile4_h3.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h3.TabIndex = 54;
            this.HopTile4_h3.TabStop = false;
            // 
            // HopTile4_h2
            // 
            this.HopTile4_h2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h2.Location = new System.Drawing.Point(635, 331);
            this.HopTile4_h2.Name = "HopTile4_h2";
            this.HopTile4_h2.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h2.TabIndex = 53;
            this.HopTile4_h2.TabStop = false;
            // 
            // HopTile4_h1
            // 
            this.HopTile4_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile4_h1.Location = new System.Drawing.Point(598, 331);
            this.HopTile4_h1.Name = "HopTile4_h1";
            this.HopTile4_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile4_h1.TabIndex = 52;
            this.HopTile4_h1.TabStop = false;
            // 
            // HopTile3_c3
            // 
            this.HopTile3_c3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_c3.Location = new System.Drawing.Point(485, 159);
            this.HopTile3_c3.Name = "HopTile3_c3";
            this.HopTile3_c3.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_c3.TabIndex = 58;
            this.HopTile3_c3.TabStop = false;
            // 
            // HopTile3_c2
            // 
            this.HopTile3_c2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_c2.Location = new System.Drawing.Point(448, 159);
            this.HopTile3_c2.Name = "HopTile3_c2";
            this.HopTile3_c2.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_c2.TabIndex = 57;
            this.HopTile3_c2.TabStop = false;
            // 
            // HopTile3_c1
            // 
            this.HopTile3_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_c1.Location = new System.Drawing.Point(411, 159);
            this.HopTile3_c1.Name = "HopTile3_c1";
            this.HopTile3_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_c1.TabIndex = 56;
            this.HopTile3_c1.TabStop = false;
            // 
            // HopTile3_h3
            // 
            this.HopTile3_h3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_h3.Location = new System.Drawing.Point(485, 331);
            this.HopTile3_h3.Name = "HopTile3_h3";
            this.HopTile3_h3.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_h3.TabIndex = 62;
            this.HopTile3_h3.TabStop = false;
            // 
            // HopTile3_h2
            // 
            this.HopTile3_h2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_h2.Location = new System.Drawing.Point(448, 331);
            this.HopTile3_h2.Name = "HopTile3_h2";
            this.HopTile3_h2.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_h2.TabIndex = 61;
            this.HopTile3_h2.TabStop = false;
            // 
            // HopTile3_h1
            // 
            this.HopTile3_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile3_h1.Location = new System.Drawing.Point(411, 331);
            this.HopTile3_h1.Name = "HopTile3_h1";
            this.HopTile3_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile3_h1.TabIndex = 60;
            this.HopTile3_h1.TabStop = false;
            // 
            // HopTile1_h1
            // 
            this.HopTile1_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile1_h1.Location = new System.Drawing.Point(28, 331);
            this.HopTile1_h1.Name = "HopTile1_h1";
            this.HopTile1_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile1_h1.TabIndex = 68;
            this.HopTile1_h1.TabStop = false;
            // 
            // HopTile2_h2
            // 
            this.HopTile2_h2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_h2.Location = new System.Drawing.Point(255, 331);
            this.HopTile2_h2.Name = "HopTile2_h2";
            this.HopTile2_h2.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_h2.TabIndex = 65;
            this.HopTile2_h2.TabStop = false;
            // 
            // HopTile2_h1
            // 
            this.HopTile2_h1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_h1.Location = new System.Drawing.Point(218, 331);
            this.HopTile2_h1.Name = "HopTile2_h1";
            this.HopTile2_h1.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_h1.TabIndex = 64;
            this.HopTile2_h1.TabStop = false;
            // 
            // HopTile1_c1
            // 
            this.HopTile1_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile1_c1.Location = new System.Drawing.Point(28, 159);
            this.HopTile1_c1.Name = "HopTile1_c1";
            this.HopTile1_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile1_c1.TabIndex = 76;
            this.HopTile1_c1.TabStop = false;
            // 
            // HopTile2_c2
            // 
            this.HopTile2_c2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_c2.Location = new System.Drawing.Point(252, 159);
            this.HopTile2_c2.Name = "HopTile2_c2";
            this.HopTile2_c2.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_c2.TabIndex = 73;
            this.HopTile2_c2.TabStop = false;
            // 
            // HopTile2_c1
            // 
            this.HopTile2_c1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.HopTile2_c1.Location = new System.Drawing.Point(215, 159);
            this.HopTile2_c1.Name = "HopTile2_c1";
            this.HopTile2_c1.Size = new System.Drawing.Size(30, 40);
            this.HopTile2_c1.TabIndex = 72;
            this.HopTile2_c1.TabStop = false;
            // 
            // humanDeckl1
            // 
            this.humanDeckl1.AutoSize = true;
            this.humanDeckl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.humanDeckl1.Location = new System.Drawing.Point(40, 426);
            this.humanDeckl1.Name = "humanDeckl1";
            this.humanDeckl1.Size = new System.Drawing.Size(0, 20);
            this.humanDeckl1.TabIndex = 77;
            // 
            // humanDeckLabel1
            // 
            this.humanDeckLabel1.AutoSize = true;
            this.humanDeckLabel1.Location = new System.Drawing.Point(25, 426);
            this.humanDeckLabel1.Name = "humanDeckLabel1";
            this.humanDeckLabel1.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel1.TabIndex = 78;
            this.humanDeckLabel1.Text = "1";
            // 
            // humanDeckLabel2
            // 
            this.humanDeckLabel2.AutoSize = true;
            this.humanDeckLabel2.Location = new System.Drawing.Point(123, 426);
            this.humanDeckLabel2.Name = "humanDeckLabel2";
            this.humanDeckLabel2.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel2.TabIndex = 79;
            this.humanDeckLabel2.Text = "1";
            // 
            // humanDeckLabel4
            // 
            this.humanDeckLabel4.AutoSize = true;
            this.humanDeckLabel4.Location = new System.Drawing.Point(317, 426);
            this.humanDeckLabel4.Name = "humanDeckLabel4";
            this.humanDeckLabel4.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel4.TabIndex = 81;
            this.humanDeckLabel4.Text = "1";
            // 
            // humanDeckLabel3
            // 
            this.humanDeckLabel3.AutoSize = true;
            this.humanDeckLabel3.Location = new System.Drawing.Point(219, 426);
            this.humanDeckLabel3.Name = "humanDeckLabel3";
            this.humanDeckLabel3.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel3.TabIndex = 80;
            this.humanDeckLabel3.Text = "1";
            // 
            // humanDeckLabel8
            // 
            this.humanDeckLabel8.AutoSize = true;
            this.humanDeckLabel8.Location = new System.Drawing.Point(701, 426);
            this.humanDeckLabel8.Name = "humanDeckLabel8";
            this.humanDeckLabel8.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel8.TabIndex = 85;
            this.humanDeckLabel8.Text = "1";
            // 
            // humanDeckLabel7
            // 
            this.humanDeckLabel7.AutoSize = true;
            this.humanDeckLabel7.Location = new System.Drawing.Point(603, 426);
            this.humanDeckLabel7.Name = "humanDeckLabel7";
            this.humanDeckLabel7.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel7.TabIndex = 84;
            this.humanDeckLabel7.Text = "1";
            // 
            // humanDeckLabel6
            // 
            this.humanDeckLabel6.AutoSize = true;
            this.humanDeckLabel6.Location = new System.Drawing.Point(507, 426);
            this.humanDeckLabel6.Name = "humanDeckLabel6";
            this.humanDeckLabel6.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel6.TabIndex = 83;
            this.humanDeckLabel6.Text = "1";
            // 
            // humanDeckLabel5
            // 
            this.humanDeckLabel5.AutoSize = true;
            this.humanDeckLabel5.Location = new System.Drawing.Point(409, 426);
            this.humanDeckLabel5.Name = "humanDeckLabel5";
            this.humanDeckLabel5.Size = new System.Drawing.Size(13, 13);
            this.humanDeckLabel5.TabIndex = 82;
            this.humanDeckLabel5.Text = "1";
            // 
            // computerDeckLabel4
            // 
            this.computerDeckLabel4.AutoSize = true;
            this.computerDeckLabel4.Location = new System.Drawing.Point(319, 26);
            this.computerDeckLabel4.Name = "computerDeckLabel4";
            this.computerDeckLabel4.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel4.TabIndex = 89;
            this.computerDeckLabel4.Text = "1";
            // 
            // computerDeckLabel3
            // 
            this.computerDeckLabel3.AutoSize = true;
            this.computerDeckLabel3.Location = new System.Drawing.Point(221, 26);
            this.computerDeckLabel3.Name = "computerDeckLabel3";
            this.computerDeckLabel3.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel3.TabIndex = 88;
            this.computerDeckLabel3.Text = "1";
            // 
            // computerDeckLabel2
            // 
            this.computerDeckLabel2.AutoSize = true;
            this.computerDeckLabel2.Location = new System.Drawing.Point(125, 26);
            this.computerDeckLabel2.Name = "computerDeckLabel2";
            this.computerDeckLabel2.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel2.TabIndex = 87;
            this.computerDeckLabel2.Text = "1";
            // 
            // computerDeckLabel1
            // 
            this.computerDeckLabel1.AutoSize = true;
            this.computerDeckLabel1.Location = new System.Drawing.Point(27, 26);
            this.computerDeckLabel1.Name = "computerDeckLabel1";
            this.computerDeckLabel1.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel1.TabIndex = 86;
            this.computerDeckLabel1.Text = "1";
            // 
            // computerDeckLabel8
            // 
            this.computerDeckLabel8.AutoSize = true;
            this.computerDeckLabel8.Location = new System.Drawing.Point(701, 26);
            this.computerDeckLabel8.Name = "computerDeckLabel8";
            this.computerDeckLabel8.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel8.TabIndex = 93;
            this.computerDeckLabel8.Text = "1";
            // 
            // computerDeckLabel7
            // 
            this.computerDeckLabel7.AutoSize = true;
            this.computerDeckLabel7.Location = new System.Drawing.Point(603, 26);
            this.computerDeckLabel7.Name = "computerDeckLabel7";
            this.computerDeckLabel7.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel7.TabIndex = 92;
            this.computerDeckLabel7.Text = "1";
            // 
            // computerDeckLabel6
            // 
            this.computerDeckLabel6.AutoSize = true;
            this.computerDeckLabel6.Location = new System.Drawing.Point(507, 26);
            this.computerDeckLabel6.Name = "computerDeckLabel6";
            this.computerDeckLabel6.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel6.TabIndex = 91;
            this.computerDeckLabel6.Text = "1";
            // 
            // computerDeckLabel5
            // 
            this.computerDeckLabel5.AutoSize = true;
            this.computerDeckLabel5.Location = new System.Drawing.Point(409, 26);
            this.computerDeckLabel5.Name = "computerDeckLabel5";
            this.computerDeckLabel5.Size = new System.Drawing.Size(13, 13);
            this.computerDeckLabel5.TabIndex = 90;
            this.computerDeckLabel5.Text = "1";
            // 
            // HopTileLabel1
            // 
            this.HopTileLabel1.AutoSize = true;
            this.HopTileLabel1.Location = new System.Drawing.Point(29, 221);
            this.HopTileLabel1.Name = "HopTileLabel1";
            this.HopTileLabel1.Size = new System.Drawing.Size(29, 13);
            this.HopTileLabel1.TabIndex = 94;
            this.HopTileLabel1.Text = "High";
            // 
            // HopTileLabel3
            // 
            this.HopTileLabel3.AutoSize = true;
            this.HopTileLabel3.Location = new System.Drawing.Point(412, 221);
            this.HopTileLabel3.Name = "HopTileLabel3";
            this.HopTileLabel3.Size = new System.Drawing.Size(29, 13);
            this.HopTileLabel3.TabIndex = 95;
            this.HopTileLabel3.Text = "High";
            // 
            // HopTileLabel2
            // 
            this.HopTileLabel2.AutoSize = true;
            this.HopTileLabel2.Location = new System.Drawing.Point(219, 221);
            this.HopTileLabel2.Name = "HopTileLabel2";
            this.HopTileLabel2.Size = new System.Drawing.Size(27, 13);
            this.HopTileLabel2.TabIndex = 96;
            this.HopTileLabel2.Text = "Low";
            // 
            // HopTileLabel4
            // 
            this.HopTileLabel4.AutoSize = true;
            this.HopTileLabel4.Location = new System.Drawing.Point(601, 221);
            this.HopTileLabel4.Name = "HopTileLabel4";
            this.HopTileLabel4.Size = new System.Drawing.Size(27, 13);
            this.HopTileLabel4.TabIndex = 97;
            this.HopTileLabel4.Text = "Low";
            // 
            // HopTile1_cLabel1
            // 
            this.HopTile1_cLabel1.AutoSize = true;
            this.HopTile1_cLabel1.Location = new System.Drawing.Point(27, 159);
            this.HopTile1_cLabel1.Name = "HopTile1_cLabel1";
            this.HopTile1_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile1_cLabel1.TabIndex = 98;
            this.HopTile1_cLabel1.Text = "1";
            // 
            // HopTile2_cLabel1
            // 
            this.HopTile2_cLabel1.AutoSize = true;
            this.HopTile2_cLabel1.Location = new System.Drawing.Point(215, 159);
            this.HopTile2_cLabel1.Name = "HopTile2_cLabel1";
            this.HopTile2_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_cLabel1.TabIndex = 99;
            this.HopTile2_cLabel1.Text = "1";
            // 
            // HopTile2_cLabel2
            // 
            this.HopTile2_cLabel2.AutoSize = true;
            this.HopTile2_cLabel2.Location = new System.Drawing.Point(252, 159);
            this.HopTile2_cLabel2.Name = "HopTile2_cLabel2";
            this.HopTile2_cLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_cLabel2.TabIndex = 100;
            this.HopTile2_cLabel2.Text = "1";
            // 
            // HopTile3_cLabel1
            // 
            this.HopTile3_cLabel1.AutoSize = true;
            this.HopTile3_cLabel1.Location = new System.Drawing.Point(412, 159);
            this.HopTile3_cLabel1.Name = "HopTile3_cLabel1";
            this.HopTile3_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_cLabel1.TabIndex = 101;
            this.HopTile3_cLabel1.Text = "1";
            // 
            // HopTile3_cLabel3
            // 
            this.HopTile3_cLabel3.AutoSize = true;
            this.HopTile3_cLabel3.Location = new System.Drawing.Point(484, 159);
            this.HopTile3_cLabel3.Name = "HopTile3_cLabel3";
            this.HopTile3_cLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_cLabel3.TabIndex = 103;
            this.HopTile3_cLabel3.Text = "1";
            // 
            // HopTile3_cLabel2
            // 
            this.HopTile3_cLabel2.AutoSize = true;
            this.HopTile3_cLabel2.Location = new System.Drawing.Point(447, 159);
            this.HopTile3_cLabel2.Name = "HopTile3_cLabel2";
            this.HopTile3_cLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_cLabel2.TabIndex = 102;
            this.HopTile3_cLabel2.Text = "1";
            // 
            // HopTile4_cLabel2
            // 
            this.HopTile4_cLabel2.AutoSize = true;
            this.HopTile4_cLabel2.Location = new System.Drawing.Point(638, 159);
            this.HopTile4_cLabel2.Name = "HopTile4_cLabel2";
            this.HopTile4_cLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel2.TabIndex = 105;
            this.HopTile4_cLabel2.Text = "1";
            // 
            // HopTile4_cLabel1
            // 
            this.HopTile4_cLabel1.AutoSize = true;
            this.HopTile4_cLabel1.Location = new System.Drawing.Point(601, 159);
            this.HopTile4_cLabel1.Name = "HopTile4_cLabel1";
            this.HopTile4_cLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel1.TabIndex = 104;
            this.HopTile4_cLabel1.Text = "1";
            // 
            // HopTile4_cLabel4
            // 
            this.HopTile4_cLabel4.AutoSize = true;
            this.HopTile4_cLabel4.Location = new System.Drawing.Point(708, 159);
            this.HopTile4_cLabel4.Name = "HopTile4_cLabel4";
            this.HopTile4_cLabel4.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel4.TabIndex = 107;
            this.HopTile4_cLabel4.Text = "1";
            // 
            // HopTile4_cLabel3
            // 
            this.HopTile4_cLabel3.AutoSize = true;
            this.HopTile4_cLabel3.Location = new System.Drawing.Point(671, 159);
            this.HopTile4_cLabel3.Name = "HopTile4_cLabel3";
            this.HopTile4_cLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_cLabel3.TabIndex = 106;
            this.HopTile4_cLabel3.Text = "1";
            // 
            // HopTile4_hLabel2
            // 
            this.HopTile4_hLabel2.AutoSize = true;
            this.HopTile4_hLabel2.Location = new System.Drawing.Point(638, 331);
            this.HopTile4_hLabel2.Name = "HopTile4_hLabel2";
            this.HopTile4_hLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel2.TabIndex = 109;
            this.HopTile4_hLabel2.Text = "1";
            // 
            // HopTile4_hLabel1
            // 
            this.HopTile4_hLabel1.AutoSize = true;
            this.HopTile4_hLabel1.Location = new System.Drawing.Point(601, 331);
            this.HopTile4_hLabel1.Name = "HopTile4_hLabel1";
            this.HopTile4_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel1.TabIndex = 108;
            this.HopTile4_hLabel1.Text = "1";
            // 
            // HopTile4_hLabel4
            // 
            this.HopTile4_hLabel4.AutoSize = true;
            this.HopTile4_hLabel4.Location = new System.Drawing.Point(708, 331);
            this.HopTile4_hLabel4.Name = "HopTile4_hLabel4";
            this.HopTile4_hLabel4.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel4.TabIndex = 111;
            this.HopTile4_hLabel4.Text = "1";
            // 
            // HopTile4_hLabel3
            // 
            this.HopTile4_hLabel3.AutoSize = true;
            this.HopTile4_hLabel3.Location = new System.Drawing.Point(671, 331);
            this.HopTile4_hLabel3.Name = "HopTile4_hLabel3";
            this.HopTile4_hLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile4_hLabel3.TabIndex = 110;
            this.HopTile4_hLabel3.Text = "1";
            // 
            // HopTile2_hLabel2
            // 
            this.HopTile2_hLabel2.AutoSize = true;
            this.HopTile2_hLabel2.Location = new System.Drawing.Point(254, 331);
            this.HopTile2_hLabel2.Name = "HopTile2_hLabel2";
            this.HopTile2_hLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_hLabel2.TabIndex = 113;
            this.HopTile2_hLabel2.Text = "1";
            // 
            // HopTile2_hLabel1
            // 
            this.HopTile2_hLabel1.AutoSize = true;
            this.HopTile2_hLabel1.Location = new System.Drawing.Point(217, 331);
            this.HopTile2_hLabel1.Name = "HopTile2_hLabel1";
            this.HopTile2_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile2_hLabel1.TabIndex = 112;
            this.HopTile2_hLabel1.Text = "1";
            // 
            // HopTile3_hLabel3
            // 
            this.HopTile3_hLabel3.AutoSize = true;
            this.HopTile3_hLabel3.Location = new System.Drawing.Point(484, 331);
            this.HopTile3_hLabel3.Name = "HopTile3_hLabel3";
            this.HopTile3_hLabel3.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_hLabel3.TabIndex = 115;
            this.HopTile3_hLabel3.Text = "1";
            // 
            // HopTile3_hLabel2
            // 
            this.HopTile3_hLabel2.AutoSize = true;
            this.HopTile3_hLabel2.Location = new System.Drawing.Point(447, 331);
            this.HopTile3_hLabel2.Name = "HopTile3_hLabel2";
            this.HopTile3_hLabel2.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_hLabel2.TabIndex = 114;
            this.HopTile3_hLabel2.Text = "1";
            // 
            // HopTile3_hLabel1
            // 
            this.HopTile3_hLabel1.AutoSize = true;
            this.HopTile3_hLabel1.Location = new System.Drawing.Point(412, 331);
            this.HopTile3_hLabel1.Name = "HopTile3_hLabel1";
            this.HopTile3_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile3_hLabel1.TabIndex = 116;
            this.HopTile3_hLabel1.Text = "1";
            // 
            // HopTile1_hLabel1
            // 
            this.HopTile1_hLabel1.AutoSize = true;
            this.HopTile1_hLabel1.Location = new System.Drawing.Point(25, 331);
            this.HopTile1_hLabel1.Name = "HopTile1_hLabel1";
            this.HopTile1_hLabel1.Size = new System.Drawing.Size(13, 13);
            this.HopTile1_hLabel1.TabIndex = 117;
            this.HopTile1_hLabel1.Text = "1";
            // 
            // HopTile1_Cubes1
            // 
            this.HopTile1_Cubes1.Location = new System.Drawing.Point(44, 253);
            this.HopTile1_Cubes1.Name = "HopTile1_Cubes1";
            this.HopTile1_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile1_Cubes1.TabIndex = 118;
            this.HopTile1_Cubes1.TabStop = false;
            // 
            // HopTile2_Cubes1
            // 
            this.HopTile2_Cubes1.Location = new System.Drawing.Point(235, 253);
            this.HopTile2_Cubes1.Name = "HopTile2_Cubes1";
            this.HopTile2_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile2_Cubes1.TabIndex = 119;
            this.HopTile2_Cubes1.TabStop = false;
            // 
            // HopTile2_Cubes2
            // 
            this.HopTile2_Cubes2.Location = new System.Drawing.Point(271, 253);
            this.HopTile2_Cubes2.Name = "HopTile2_Cubes2";
            this.HopTile2_Cubes2.Size = new System.Drawing.Size(30, 30);
            this.HopTile2_Cubes2.TabIndex = 120;
            this.HopTile2_Cubes2.TabStop = false;
            // 
            // HopTile3_Cubes2
            // 
            this.HopTile3_Cubes2.Location = new System.Drawing.Point(466, 253);
            this.HopTile3_Cubes2.Name = "HopTile3_Cubes2";
            this.HopTile3_Cubes2.Size = new System.Drawing.Size(30, 30);
            this.HopTile3_Cubes2.TabIndex = 122;
            this.HopTile3_Cubes2.TabStop = false;
            // 
            // HopTile3_Cubes1
            // 
            this.HopTile3_Cubes1.Location = new System.Drawing.Point(430, 253);
            this.HopTile3_Cubes1.Name = "HopTile3_Cubes1";
            this.HopTile3_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile3_Cubes1.TabIndex = 121;
            this.HopTile3_Cubes1.TabStop = false;
            // 
            // HopTile4_Cubes2
            // 
            this.HopTile4_Cubes2.Location = new System.Drawing.Point(657, 253);
            this.HopTile4_Cubes2.Name = "HopTile4_Cubes2";
            this.HopTile4_Cubes2.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes2.TabIndex = 124;
            this.HopTile4_Cubes2.TabStop = false;
            // 
            // HopTile4_Cubes1
            // 
            this.HopTile4_Cubes1.Location = new System.Drawing.Point(621, 253);
            this.HopTile4_Cubes1.Name = "HopTile4_Cubes1";
            this.HopTile4_Cubes1.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes1.TabIndex = 123;
            this.HopTile4_Cubes1.TabStop = false;
            // 
            // HopTile4_Cubes4
            // 
            this.HopTile4_Cubes4.Location = new System.Drawing.Point(731, 253);
            this.HopTile4_Cubes4.Name = "HopTile4_Cubes4";
            this.HopTile4_Cubes4.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes4.TabIndex = 126;
            this.HopTile4_Cubes4.TabStop = false;
            // 
            // HopTile4_Cubes3
            // 
            this.HopTile4_Cubes3.Location = new System.Drawing.Point(695, 253);
            this.HopTile4_Cubes3.Name = "HopTile4_Cubes3";
            this.HopTile4_Cubes3.Size = new System.Drawing.Size(30, 30);
            this.HopTile4_Cubes3.TabIndex = 125;
            this.HopTile4_Cubes3.TabStop = false;
            // 
            // HopTile3_Cubes3
            // 
            this.HopTile3_Cubes3.Location = new System.Drawing.Point(503, 253);
            this.HopTile3_Cubes3.Name = "HopTile3_Cubes3";
            this.HopTile3_Cubes3.Size = new System.Drawing.Size(30, 30);
            this.HopTile3_Cubes3.TabIndex = 127;
            this.HopTile3_Cubes3.TabStop = false;
            // 
            // btnReshuffle
            // 
            this.btnReshuffle.Enabled = false;
            this.btnReshuffle.Location = new System.Drawing.Point(806, 512);
            this.btnReshuffle.Name = "btnReshuffle";
            this.btnReshuffle.Size = new System.Drawing.Size(96, 23);
            this.btnReshuffle.TabIndex = 128;
            this.btnReshuffle.Text = "Finish Reshuffle";
            this.btnReshuffle.UseVisualStyleBackColor = true;
            this.btnReshuffle.Click += new System.EventHandler(this.button1_Click);
            // 
            // Trophy2
            // 
            this.Trophy2.Location = new System.Drawing.Point(821, 137);
            this.Trophy2.Name = "Trophy2";
            this.Trophy2.Size = new System.Drawing.Size(100, 50);
            this.Trophy2.TabIndex = 129;
            this.Trophy2.TabStop = false;
            // 
            // Trophy3
            // 
            this.Trophy3.Location = new System.Drawing.Point(821, 213);
            this.Trophy3.Name = "Trophy3";
            this.Trophy3.Size = new System.Drawing.Size(100, 50);
            this.Trophy3.TabIndex = 130;
            this.Trophy3.TabStop = false;
            // 
            // Trophy4
            // 
            this.Trophy4.Location = new System.Drawing.Point(821, 290);
            this.Trophy4.Name = "Trophy4";
            this.Trophy4.Size = new System.Drawing.Size(100, 50);
            this.Trophy4.TabIndex = 131;
            this.Trophy4.TabStop = false;
            // 
            // Trophy1
            // 
            this.Trophy1.Location = new System.Drawing.Point(821, 71);
            this.Trophy1.Name = "Trophy1";
            this.Trophy1.Size = new System.Drawing.Size(100, 50);
            this.Trophy1.TabIndex = 133;
            this.Trophy1.TabStop = false;
            // 
            // TrophyLabel1
            // 
            this.TrophyLabel1.AutoSize = true;
            this.TrophyLabel1.Location = new System.Drawing.Point(818, 71);
            this.TrophyLabel1.Name = "TrophyLabel1";
            this.TrophyLabel1.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel1.TabIndex = 134;
            this.TrophyLabel1.Text = "1";
            // 
            // TrophyLabel2
            // 
            this.TrophyLabel2.AutoSize = true;
            this.TrophyLabel2.Location = new System.Drawing.Point(818, 137);
            this.TrophyLabel2.Name = "TrophyLabel2";
            this.TrophyLabel2.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel2.TabIndex = 135;
            this.TrophyLabel2.Text = "1";
            // 
            // TrophyLabel4
            // 
            this.TrophyLabel4.AutoSize = true;
            this.TrophyLabel4.Location = new System.Drawing.Point(818, 290);
            this.TrophyLabel4.Name = "TrophyLabel4";
            this.TrophyLabel4.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel4.TabIndex = 137;
            this.TrophyLabel4.Text = "1";
            // 
            // TrophyLabel3
            // 
            this.TrophyLabel3.AutoSize = true;
            this.TrophyLabel3.Location = new System.Drawing.Point(818, 213);
            this.TrophyLabel3.Name = "TrophyLabel3";
            this.TrophyLabel3.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel3.TabIndex = 136;
            this.TrophyLabel3.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(817, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 20);
            this.label6.TabIndex = 139;
            this.label6.Text = "Trophies";
            // 
            // TrophyLabelOwn4
            // 
            this.TrophyLabelOwn4.AutoSize = true;
            this.TrophyLabelOwn4.Location = new System.Drawing.Point(940, 327);
            this.TrophyLabelOwn4.Name = "TrophyLabelOwn4";
            this.TrophyLabelOwn4.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn4.TabIndex = 143;
            this.TrophyLabelOwn4.Text = "1";
            // 
            // TrophyLabelOwn3
            // 
            this.TrophyLabelOwn3.AutoSize = true;
            this.TrophyLabelOwn3.Location = new System.Drawing.Point(940, 250);
            this.TrophyLabelOwn3.Name = "TrophyLabelOwn3";
            this.TrophyLabelOwn3.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn3.TabIndex = 142;
            this.TrophyLabelOwn3.Text = "1";
            // 
            // TrophyLabelOwn2
            // 
            this.TrophyLabelOwn2.AutoSize = true;
            this.TrophyLabelOwn2.Location = new System.Drawing.Point(940, 174);
            this.TrophyLabelOwn2.Name = "TrophyLabelOwn2";
            this.TrophyLabelOwn2.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn2.TabIndex = 141;
            this.TrophyLabelOwn2.Text = "1";
            // 
            // TrophyLabelOwn1
            // 
            this.TrophyLabelOwn1.AutoSize = true;
            this.TrophyLabelOwn1.Location = new System.Drawing.Point(940, 108);
            this.TrophyLabelOwn1.Name = "TrophyLabelOwn1";
            this.TrophyLabelOwn1.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn1.TabIndex = 140;
            this.TrophyLabelOwn1.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(912, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 20);
            this.label5.TabIndex = 144;
            this.label5.Text = "Own";
            // 
            // TrophyLabelOwn5
            // 
            this.TrophyLabelOwn5.AutoSize = true;
            this.TrophyLabelOwn5.Location = new System.Drawing.Point(940, 398);
            this.TrophyLabelOwn5.Name = "TrophyLabelOwn5";
            this.TrophyLabelOwn5.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabelOwn5.TabIndex = 147;
            this.TrophyLabelOwn5.Text = "1";
            // 
            // TrophyLabel5
            // 
            this.TrophyLabel5.AutoSize = true;
            this.TrophyLabel5.Location = new System.Drawing.Point(818, 361);
            this.TrophyLabel5.Name = "TrophyLabel5";
            this.TrophyLabel5.Size = new System.Drawing.Size(13, 13);
            this.TrophyLabel5.TabIndex = 146;
            this.TrophyLabel5.Text = "1";
            // 
            // Trophy5
            // 
            this.Trophy5.Location = new System.Drawing.Point(821, 361);
            this.Trophy5.Name = "Trophy5";
            this.Trophy5.Size = new System.Drawing.Size(100, 50);
            this.Trophy5.TabIndex = 145;
            this.Trophy5.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(984, 562);
            this.Controls.Add(this.TrophyLabelOwn5);
            this.Controls.Add(this.TrophyLabel5);
            this.Controls.Add(this.Trophy5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TrophyLabelOwn4);
            this.Controls.Add(this.TrophyLabelOwn3);
            this.Controls.Add(this.TrophyLabelOwn2);
            this.Controls.Add(this.TrophyLabelOwn1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TrophyLabel4);
            this.Controls.Add(this.TrophyLabel3);
            this.Controls.Add(this.TrophyLabel2);
            this.Controls.Add(this.TrophyLabel1);
            this.Controls.Add(this.Trophy1);
            this.Controls.Add(this.Trophy4);
            this.Controls.Add(this.Trophy3);
            this.Controls.Add(this.Trophy2);
            this.Controls.Add(this.btnReshuffle);
            this.Controls.Add(this.HopTile3_Cubes3);
            this.Controls.Add(this.HopTile4_Cubes4);
            this.Controls.Add(this.HopTile4_Cubes3);
            this.Controls.Add(this.HopTile4_Cubes2);
            this.Controls.Add(this.HopTile4_Cubes1);
            this.Controls.Add(this.HopTile3_Cubes2);
            this.Controls.Add(this.HopTile3_Cubes1);
            this.Controls.Add(this.HopTile2_Cubes2);
            this.Controls.Add(this.HopTile2_Cubes1);
            this.Controls.Add(this.HopTile1_Cubes1);
            this.Controls.Add(this.HopTile1_hLabel1);
            this.Controls.Add(this.HopTile3_hLabel1);
            this.Controls.Add(this.HopTile3_hLabel3);
            this.Controls.Add(this.HopTile3_hLabel2);
            this.Controls.Add(this.HopTile2_hLabel2);
            this.Controls.Add(this.HopTile2_hLabel1);
            this.Controls.Add(this.HopTile4_hLabel4);
            this.Controls.Add(this.HopTile4_hLabel3);
            this.Controls.Add(this.HopTile4_hLabel2);
            this.Controls.Add(this.HopTile4_hLabel1);
            this.Controls.Add(this.HopTile4_cLabel4);
            this.Controls.Add(this.HopTile4_cLabel3);
            this.Controls.Add(this.HopTile4_cLabel2);
            this.Controls.Add(this.HopTile4_cLabel1);
            this.Controls.Add(this.HopTile3_cLabel3);
            this.Controls.Add(this.HopTile3_cLabel2);
            this.Controls.Add(this.HopTile3_cLabel1);
            this.Controls.Add(this.HopTile2_cLabel2);
            this.Controls.Add(this.HopTile2_cLabel1);
            this.Controls.Add(this.HopTile1_cLabel1);
            this.Controls.Add(this.HopTileLabel4);
            this.Controls.Add(this.HopTileLabel2);
            this.Controls.Add(this.HopTileLabel3);
            this.Controls.Add(this.HopTileLabel1);
            this.Controls.Add(this.computerDeckLabel8);
            this.Controls.Add(this.computerDeckLabel7);
            this.Controls.Add(this.computerDeckLabel6);
            this.Controls.Add(this.computerDeckLabel5);
            this.Controls.Add(this.computerDeckLabel4);
            this.Controls.Add(this.computerDeckLabel3);
            this.Controls.Add(this.computerDeckLabel2);
            this.Controls.Add(this.computerDeckLabel1);
            this.Controls.Add(this.humanDeckLabel8);
            this.Controls.Add(this.humanDeckLabel7);
            this.Controls.Add(this.humanDeckLabel6);
            this.Controls.Add(this.humanDeckLabel5);
            this.Controls.Add(this.humanDeckLabel4);
            this.Controls.Add(this.humanDeckLabel3);
            this.Controls.Add(this.humanDeckLabel2);
            this.Controls.Add(this.humanDeckLabel1);
            this.Controls.Add(this.humanDeckl1);
            this.Controls.Add(this.HopTile1_c1);
            this.Controls.Add(this.HopTile2_c2);
            this.Controls.Add(this.HopTile2_c1);
            this.Controls.Add(this.HopTile1_h1);
            this.Controls.Add(this.HopTile2_h2);
            this.Controls.Add(this.HopTile2_h1);
            this.Controls.Add(this.HopTile3_h3);
            this.Controls.Add(this.HopTile3_h2);
            this.Controls.Add(this.HopTile3_h1);
            this.Controls.Add(this.HopTile3_c3);
            this.Controls.Add(this.HopTile3_c2);
            this.Controls.Add(this.HopTile3_c1);
            this.Controls.Add(this.HopTile4_h4);
            this.Controls.Add(this.HopTile4_h3);
            this.Controls.Add(this.HopTile4_h2);
            this.Controls.Add(this.HopTile4_h1);
            this.Controls.Add(this.HopTile4_c4);
            this.Controls.Add(this.HopTile4_c3);
            this.Controls.Add(this.HopTile4_c2);
            this.Controls.Add(this.HopTile4_c1);
            this.Controls.Add(this.HopTile4);
            this.Controls.Add(this.HopTile3);
            this.Controls.Add(this.HopTile2);
            this.Controls.Add(this.HopTile1);
            this.Controls.Add(this.computerDeck1);
            this.Controls.Add(this.computerDeck2);
            this.Controls.Add(this.computerDeck3);
            this.Controls.Add(this.computerDeck4);
            this.Controls.Add(this.computerDeck5);
            this.Controls.Add(this.computerDeck6);
            this.Controls.Add(this.computerDeck7);
            this.Controls.Add(this.computerDeck8);
            this.Controls.Add(this.humanDeck1);
            this.Controls.Add(this.humanDeck2);
            this.Controls.Add(this.humanDeck3);
            this.Controls.Add(this.humanDeck4);
            this.Controls.Add(this.humanDeck5);
            this.Controls.Add(this.humanDeck6);
            this.Controls.Add(this.humanDeck7);
            this.Controls.Add(this.humanDeck8);
            this.Name = "Form2";
            this.Text = "Ballon Cup";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Resize += new System.EventHandler(this.Form2_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.humanDeck4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computerDeck8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_c4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_h1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_c1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile1_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile2_Cubes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile4_Cubes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HopTile3_Cubes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Trophy5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox humanDeck8;
        private System.Windows.Forms.PictureBox humanDeck7;
        private System.Windows.Forms.PictureBox humanDeck5;
        private System.Windows.Forms.PictureBox humanDeck6;
        private System.Windows.Forms.PictureBox humanDeck1;
        private System.Windows.Forms.PictureBox humanDeck2;
        private System.Windows.Forms.PictureBox humanDeck3;
        private System.Windows.Forms.PictureBox humanDeck4;
        private System.Windows.Forms.PictureBox computerDeck1;
        private System.Windows.Forms.PictureBox computerDeck2;
        private System.Windows.Forms.PictureBox computerDeck3;
        private System.Windows.Forms.PictureBox computerDeck4;
        private System.Windows.Forms.PictureBox computerDeck5;
        private System.Windows.Forms.PictureBox computerDeck6;
        private System.Windows.Forms.PictureBox computerDeck7;
        private System.Windows.Forms.PictureBox computerDeck8;
        private System.Windows.Forms.PictureBox HopTile1;
        private System.Windows.Forms.PictureBox HopTile2;
        private System.Windows.Forms.PictureBox HopTile3;
        private System.Windows.Forms.PictureBox HopTile4_c1;
        private System.Windows.Forms.PictureBox HopTile4;
        private System.Windows.Forms.PictureBox HopTile4_c2;
        private System.Windows.Forms.PictureBox HopTile4_c3;
        private System.Windows.Forms.PictureBox HopTile4_c4;
        private System.Windows.Forms.PictureBox HopTile4_h4;
        private System.Windows.Forms.PictureBox HopTile4_h3;
        private System.Windows.Forms.PictureBox HopTile4_h2;
        private System.Windows.Forms.PictureBox HopTile4_h1;
        private System.Windows.Forms.PictureBox HopTile3_c3;
        private System.Windows.Forms.PictureBox HopTile3_c2;
        private System.Windows.Forms.PictureBox HopTile3_c1;
        private System.Windows.Forms.PictureBox HopTile3_h3;
        private System.Windows.Forms.PictureBox HopTile3_h2;
        private System.Windows.Forms.PictureBox HopTile3_h1;
        private System.Windows.Forms.PictureBox HopTile1_h1;
        private System.Windows.Forms.PictureBox HopTile2_h2;
        private System.Windows.Forms.PictureBox HopTile2_h1;
        private System.Windows.Forms.PictureBox HopTile1_c1;
        private System.Windows.Forms.PictureBox HopTile2_c2;
        private System.Windows.Forms.PictureBox HopTile2_c1;
        private System.Windows.Forms.Label humanDeckl1;
        private System.Windows.Forms.Label humanDeckLabel1;
        private System.Windows.Forms.Label humanDeckLabel2;
        private System.Windows.Forms.Label humanDeckLabel4;
        private System.Windows.Forms.Label humanDeckLabel3;
        private System.Windows.Forms.Label humanDeckLabel8;
        private System.Windows.Forms.Label humanDeckLabel7;
        private System.Windows.Forms.Label humanDeckLabel6;
        private System.Windows.Forms.Label humanDeckLabel5;
        private System.Windows.Forms.Label computerDeckLabel4;
        private System.Windows.Forms.Label computerDeckLabel3;
        private System.Windows.Forms.Label computerDeckLabel2;
        private System.Windows.Forms.Label computerDeckLabel1;
        private System.Windows.Forms.Label computerDeckLabel8;
        private System.Windows.Forms.Label computerDeckLabel7;
        private System.Windows.Forms.Label computerDeckLabel6;
        private System.Windows.Forms.Label computerDeckLabel5;
        private System.Windows.Forms.Label HopTileLabel1;
        private System.Windows.Forms.Label HopTileLabel3;
        private System.Windows.Forms.Label HopTileLabel2;
        private System.Windows.Forms.Label HopTileLabel4;
        private System.Windows.Forms.Label HopTile1_cLabel1;
        private System.Windows.Forms.Label HopTile2_cLabel1;
        private System.Windows.Forms.Label HopTile2_cLabel2;
        private System.Windows.Forms.Label HopTile3_cLabel1;
        private System.Windows.Forms.Label HopTile3_cLabel3;
        private System.Windows.Forms.Label HopTile3_cLabel2;
        private System.Windows.Forms.Label HopTile4_cLabel2;
        private System.Windows.Forms.Label HopTile4_cLabel1;
        private System.Windows.Forms.Label HopTile4_cLabel4;
        private System.Windows.Forms.Label HopTile4_cLabel3;
        private System.Windows.Forms.Label HopTile4_hLabel2;
        private System.Windows.Forms.Label HopTile4_hLabel1;
        private System.Windows.Forms.Label HopTile4_hLabel4;
        private System.Windows.Forms.Label HopTile4_hLabel3;
        private System.Windows.Forms.Label HopTile2_hLabel2;
        private System.Windows.Forms.Label HopTile2_hLabel1;
        private System.Windows.Forms.Label HopTile3_hLabel3;
        private System.Windows.Forms.Label HopTile3_hLabel2;
        private System.Windows.Forms.Label HopTile3_hLabel1;
        private System.Windows.Forms.Label HopTile1_hLabel1;
        private System.Windows.Forms.PictureBox HopTile1_Cubes1;
        private System.Windows.Forms.PictureBox HopTile2_Cubes1;
        private System.Windows.Forms.PictureBox HopTile2_Cubes2;
        private System.Windows.Forms.PictureBox HopTile3_Cubes2;
        private System.Windows.Forms.PictureBox HopTile3_Cubes1;
        private System.Windows.Forms.PictureBox HopTile4_Cubes2;
        private System.Windows.Forms.PictureBox HopTile4_Cubes1;
        private System.Windows.Forms.PictureBox HopTile4_Cubes4;
        private System.Windows.Forms.PictureBox HopTile4_Cubes3;
        private System.Windows.Forms.PictureBox HopTile3_Cubes3;
        private System.Windows.Forms.Button btnReshuffle;
        private System.Windows.Forms.PictureBox Trophy2;
        private System.Windows.Forms.PictureBox Trophy3;
        private System.Windows.Forms.PictureBox Trophy4;
        private System.Windows.Forms.PictureBox Trophy1;
        private System.Windows.Forms.Label TrophyLabel1;
        private System.Windows.Forms.Label TrophyLabel2;
        private System.Windows.Forms.Label TrophyLabel4;
        private System.Windows.Forms.Label TrophyLabel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label TrophyLabelOwn4;
        private System.Windows.Forms.Label TrophyLabelOwn3;
        private System.Windows.Forms.Label TrophyLabelOwn2;
        private System.Windows.Forms.Label TrophyLabelOwn1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label TrophyLabelOwn5;
        private System.Windows.Forms.Label TrophyLabel5;
        private System.Windows.Forms.PictureBox Trophy5;
    }
}

