﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        const int DIAMETER = 100;//set constant for the circle
        const int GAP = 5;//set constant for the gap
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDraw_Click(object sender, EventArgs e)

        {
            int temp = 0;
            int NumDraw = 0;//integer for the number of circles to draw
            int x = GAP;// x variable
            int y = GAP;// y variable
            Graphics paper = pictureBoxBowl.CreateGraphics();//allows graphics to be drawn inside the picture box
            Pen pen1 = new Pen(Color.Black, 5);//declare new pen with the color black and a width of 5
            SolidBrush br = new SolidBrush(Color.Black);//declare new brush with the color black
            if (!string.IsNullOrEmpty(textBoxNumSeeds.Text) || !string.IsNullOrWhiteSpace(textBoxNumSeeds.Text))
            {
                if (Convert.ToInt16(textBoxNumSeeds.Text) > 0)
                {
                    try
                    {
                        NumDraw = int.Parse(textBoxNumSeeds.Text);//parses the integer that was typed in the text box and stores it in the variable NumDraw
                        temp = NumDraw;
                        pictureBoxBowl.Refresh();//refreshes the picture box
                        Rectangle Rec = new Rectangle(x, y, DIAMETER, DIAMETER);//declare new rectangle 
                        if ((DIAMETER * NumDraw) > pictureBoxBowl.Width)//checks if the total number of circles drawn exceeds the width of the picture box
                        {
                            for (int k = 1; k < NumDraw; k++)//for loop to draw a row of circles
                            {
                                for (int i = 1; i < NumDraw; i++)//loops through to draw a second row of circles
                                {
                                    if ((DIAMETER * i) > pictureBoxBowl.Width)//checks if the integer diameter times the integer i is greater than the width of the picture box
                                    {
                                        break;//stops the loop
                                    }
                                    else
                                    {
                                        paper.DrawEllipse(pen1, Rec);//draws the outline of the circle
                                        paper.FillEllipse(br, Rec);//fills the circle
                                        Rec.X += (DIAMETER + GAP);//shift the x position of the rectangle by the diameter plus the gap of the last drawn circle
                                    }

                                }
                                
                                Rec.X = GAP;//shift the x postion of the rectangle equal to the gap 
                                Rec.Y = (DIAMETER + GAP); //shift the y position of the rectangle equal to the diameter plus gap
                                paper.DrawEllipse(pen1, Rec);//
                                paper.FillEllipse(br, Rec);
                                NumDraw += -7; //take away 2 from NumDraw each time it loops through
                            }
                            if (temp > 14)
                            {
                                MessageBox.Show("too large");
                            }

                        }
                        else
                        {
                            for (int i = 0; i < NumDraw; i++)//draws a row of circles
                            {
                                paper.DrawEllipse(pen1, Rec);
                                paper.FillEllipse(br, Rec);
                                Rec.X += (DIAMETER + GAP);
                            }
                        }
                        textBoxNumSeeds.Clear();//clears the text box
                        textBoxNumSeeds.Focus();//focus back on the text box
                    }
                    catch (Exception)
                    {
                        
                        throw;
                    }
                }
                else
                {
                    MessageBox.Show("you either entered a non-number or the number equals to or below 0");
                }
            }
            else
            {
                MessageBox.Show("there is no number is the textbox");
            }
        }
    }
}
