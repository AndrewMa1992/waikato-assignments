﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PracP0
{
    class Program
    {
        
        static void Main(string[] args)
        {
            List<string> wordslist = new List<string>();
            string filename = @"H:/104/PracP0/sentences.txt";
            //open the file.
            StreamReader infile = new StreamReader(filename);

            // read sentences
            while (!infile.EndOfStream)
            {
                //read a line from the file, as a whole string
                string line = infile.ReadLine();
                //split string into 'words', separated by sentences
                string[] words = line.Split(' ');
                for (int i = 0; i < words.Length; i++)
                {
                    wordslist.Add(words[i]);
                }
                //loop through each 'word' found

                wordslist.Reverse();
                for (int i = 0; i < wordslist.Count; i++)
                {

                    //output current word
                    if (wordslist[i] != "")
                    {
                        Console.Write(wordslist[i]);
                        if (i < wordslist.Count - 1)
                            Console.Write(" ");
                    }
                    //output a space between every word, except the last one
                    
                }

                //output a newline chatracter at the end of the sentence
                Console.WriteLine();
                wordslist.Clear();
                
            }
            infile.Close(); //be a tidy kiwi
            
            

            //wait for user to have read output
            Console.WriteLine();
            Console.Write("Press enter to finish:");
            Console.ReadLine();
        }
    }
}
