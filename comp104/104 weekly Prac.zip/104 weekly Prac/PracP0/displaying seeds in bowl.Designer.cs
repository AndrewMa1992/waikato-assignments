﻿namespace WindowsFormsApplication3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxBowl = new System.Windows.Forms.PictureBox();
            this.textBoxNumSeeds = new System.Windows.Forms.TextBox();
            this.buttonDraw = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBowl)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxBowl
            // 
            this.pictureBoxBowl.Location = new System.Drawing.Point(31, 31);
            this.pictureBoxBowl.Name = "pictureBoxBowl";
            this.pictureBoxBowl.Size = new System.Drawing.Size(768, 225);
            this.pictureBoxBowl.TabIndex = 0;
            this.pictureBoxBowl.TabStop = false;
            // 
            // textBoxNumSeeds
            // 
            this.textBoxNumSeeds.Location = new System.Drawing.Point(822, 31);
            this.textBoxNumSeeds.Name = "textBoxNumSeeds";
            this.textBoxNumSeeds.Size = new System.Drawing.Size(100, 20);
            this.textBoxNumSeeds.TabIndex = 1;
            // 
            // buttonDraw
            // 
            this.buttonDraw.Location = new System.Drawing.Point(847, 71);
            this.buttonDraw.Name = "buttonDraw";
            this.buttonDraw.Size = new System.Drawing.Size(75, 23);
            this.buttonDraw.TabIndex = 2;
            this.buttonDraw.Text = "Draw";
            this.buttonDraw.UseVisualStyleBackColor = true;
            this.buttonDraw.Click += new System.EventHandler(this.buttonDraw_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 323);
            this.Controls.Add(this.buttonDraw);
            this.Controls.Add(this.textBoxNumSeeds);
            this.Controls.Add(this.pictureBoxBowl);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBowl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxBowl;
        private System.Windows.Forms.TextBox textBoxNumSeeds;
        private System.Windows.Forms.Button buttonDraw;
    }
}

