﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class Parcel
    {
        public bool urgent
        {
            get { return purgent; }
            set { purgent = value; }
        }
        private bool purgent = false;
        private double cost = 0;
        public double publiccost
        {
            get { return cost; }
        }
        private string sender = "";
        public string publicsender
        {
            get { return sender; }
        }
        private int stamp = 0;
        public int Stamp { get { return stamp; } }

        public Parcel(int size,string name,bool urgent)
        {
            if (size <= 2000000)
            {
                cost = 1.40;
                stamp = 1;
            }
            else if (size <= 3000000)
            {
                cost = 2.10;
                stamp = 2;
            }
            else if (size <= 6000000)
            {
                cost = 2.80;
                stamp = 3;
            }
            else
            {
                cost = 3.50;
                stamp = 4;
            }
            purgent = urgent;
            if (purgent)
            {
                cost += 0.70;
            }
            sender = name;
        }
        public Parcel (int lsize,string name) : this(lsize,name,false)
        {

        }
    }
}
