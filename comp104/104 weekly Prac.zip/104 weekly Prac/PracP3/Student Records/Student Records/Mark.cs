﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Records
{
    class Mark
    {
        private int mark = 0;
        public int Markofthis
        {
            get
            {
                return mark;
            }
            set
            {
                mark = value;
            }
        }
        private static List<int[]> marksID = new List<int[]>(); //list of all the relationships
        private Student thisstu;
        private Paper thispap;
        private int sid = 0;
        public int SID
        {
            get { return sid; }
        }
        private string sname = "";
        private int pid = 0;
        public int PID { get { return pid; } }
        private string pname = "";
        
        public Mark(Student stu, Paper pap, int inputmark) //store all the values in public property
        {
             sid = stu.sID;
             sname = stu.sName;
             pid = pap.sID;
             pname = pap.sName;
             mark = inputmark;
        }
        public Mark(Student stu, Paper pap) :this(stu,pap,-1)
        {

        }

        public string stuname()
        {
            return sname;
        }

        public string papname()
        {
            return pname;
        }
    }
}
