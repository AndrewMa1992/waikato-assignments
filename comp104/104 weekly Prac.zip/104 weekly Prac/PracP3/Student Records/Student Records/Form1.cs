﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Records
{
    public partial class Form1 : Form
    {
        List<Student> stuList = new List<Student>();
        List<Paper> papList = new List<Paper>();
        List<Mark> markList = new List<Mark>();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool has = false; //validate the answer of paid
            if (textBox3.Text.ToLower() == "yes")
	{
		 has = true;
	}
            else if (textBox3.Text.ToLower() == "no")
	{
		 has = false;
	}
            else if (textBox3.Text == "")
            {
                has = false;
            }
            else
	{
                MessageBox.Show("you must enter either yes or no");
                return;
	}
            try 
	{
        Student snew = new Student(textBox1.Text, Convert.ToInt16(textBox2.Text), has); //create new instance of student
        if (snew != null)
        {
            stuList.Add(snew);
            listBox1.Items.Add(snew.ToString());
        }
        
	}
	catch (Exception)
	{

        MessageBox.Show("you have entered non integer values for ID");
        return;
	}
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Paper pnew = new Paper(textBox4.Text, Convert.ToInt16(textBox5.Text), textBox6.Text); //create new instance of paper
                if (pnew != null)
                {
                    papList.Add(pnew);
                    listBox1.Items.Add(pnew.ToString());
                }
            }
            catch (Exception)
            {

                MessageBox.Show("you have enter a whole integer for paper's ID");
                return;
            }
            
        }

        public static int LimitToRange(
            int value)
        {
            if (value < 0) { MessageBox.Show("value is too small"); throw new Exception(); }
            if (value > 100) { MessageBox.Show("value is too large"); throw new Exception(); }
            return value;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool found = false;
            int markofpaper = 0;
            try //validate the value of mark
            {
                markofpaper = int.Parse(textBox9.Text);
                markofpaper = LimitToRange(markofpaper);
            }
            catch (Exception)
            {
                return; //stop the operation
            }
            foreach (Student item in stuList)
            {
                if (item.sID == Convert.ToInt16(textBox7.Text))
                {
                    foreach (Paper item2 in papList)
                    {
                        if (item2.sID == Convert.ToInt16(textBox8.Text))
                        {
                            found = true;
                            Mark nmark = new Mark(item, item2,markofpaper); //create new relation of paper and student
                            markList.Add(nmark);
                        }
                    }
                }
            }
            
            if (!found)
            {
                MessageBox.Show("the student has not yet registered this paper");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string output = "";
            if (String.IsNullOrEmpty(textBox10.Text) || String.IsNullOrWhiteSpace(textBox10.Text)) //if is not empty
            {
               
                foreach (Mark item in markList)
                {
                    if (item.stuname() == textBox11.Text)
                    {
                        output += item.stuname() + "Marks: " + item.Markofthis + "\n";
                    }
                }
                if (output != "") //if something is found
                {
                    MessageBox.Show(output);
                }
                else
                {
                    MessageBox.Show("no values have been found");
                }
            }
            else //check ID
            {
                try
                {
                    int test = int.Parse(textBox10.Text); //validate
                }
                catch (Exception)
                {
                    MessageBox.Show("enter a valid number for student id");
                }

                foreach (Mark item in markList)
                {
                    if (item.SID == Convert.ToInt16(textBox10.Text))
                    {
                        output += item.stuname() + "Marks: " + item.Markofthis + "\n";
                    }
                }
                if (output != "")
                {
                    MessageBox.Show(output);
                }
                else
                {
                    MessageBox.Show("no values have been found");
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string output = "";
            if (String.IsNullOrEmpty(textBox12.Text) || String.IsNullOrWhiteSpace(textBox12.Text)) //if is not empty
            {

                foreach (Mark item in markList)
                {
                    if (item.papname() == textBox13.Text)
                    {
                        output += item.stuname() + "Marks: " + item.Markofthis + "\n";
                    }
                }
                if (output != "") //if something is found
                {
                    MessageBox.Show(output);
                }
                else
                {
                    MessageBox.Show("no values have been found");
                }
            }
            else //check ID
            {
                try
                {
                    int test = int.Parse(textBox12.Text); //validate
                }
                catch (Exception)
                {
                    MessageBox.Show("enter a valid number for student id");
                }

                foreach (Mark item in markList)
                {
                    if (item.PID == Convert.ToInt16(textBox12.Text))
                    {
                        output += item.stuname() + "Marks: " + item.Markofthis + "\n";
                    }
                }
                if (output != "")
                {
                    MessageBox.Show(output);
                }
                else
                {
                    MessageBox.Show("no values have been found");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Student snew = new Student("bruce", 1, true);
            Paper spap = new Paper("104", 1, "a");
            loop(snew, spap);

            Student snew1 = new Student("james", 2, true);
            stuList.Add(snew1);
            listBox1.Items.Add(snew1.ToString());
            Mark nmark = new Mark(snew1, spap, 99);
            markList.Add(nmark);
            
            
        }
        private void loop(Student snew, Paper spap)
        {
            stuList.Add(snew);
            papList.Add(spap);
            listBox1.Items.Add(spap.ToString());
            listBox1.Items.Add(snew.ToString());
            Mark nmark = new Mark(snew, spap, 100);
            markList.Add(nmark);
        }
    }

}
