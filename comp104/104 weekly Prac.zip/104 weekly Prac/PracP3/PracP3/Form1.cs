﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PracP3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //lots of plants!
        List<Plant> garden = new List<Plant>();

         /// <summary>
        /// add a plant at x,y position of mouse.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBoxGarden_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                int mouseX = e.X;
                int mouseY = e.Y;

                string name = textBoxName.Text;
                int size = Convert.ToInt32(textBoxSize.Text);
                decimal cost = Convert.ToDecimal(textBoxCost.Text);

                Plant plant = new Plant(name, size, cost, mouseX, mouseY);
                garden.Add(plant); //add new plant to list

                Graphics paper = pictureBoxGarden.CreateGraphics();
                plant.DrawPlant(paper);

                //update listbox
                listBoxPlants.DataSource = null;
                listBoxPlants.DataSource = garden;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter plant details first");
            }
        }

        private void buttonFinish_Click(object sender, EventArgs e)
        {
            
            using(System.IO.StreamWriter file = new System.IO.StreamWriter("H:/Visual Studio 2013/Projects/104/PracP3/A.txt")) //write to files
	{
		 foreach (Plant item in garden)
	{

        file.WriteLine(item.ToString());
	}
	}
            
        }


    }
}
