﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP3
{
    class Plant
    {
        public string Name { get; set; }
        public int Size { get; set; }
        public decimal Cost { get; set; }

        private int _x, _y; //position of plant

        public Plant(string name, int size, decimal cost, int x, int y)
        {
            Name = name;
            Size = size;
            Cost = cost;
            _x = x;
            _y = y;
        }

        public void DrawPlant(Graphics paper)
        {
            paper.FillEllipse(Brushes.Green, _x - Size / 2, _y - Size / 2, Size, Size);
        }

        public override string ToString()
        {
            return Name.PadRight(25) + Size.ToString().PadLeft(4) + "cm wide at " +
               "(" + _x.ToString().PadLeft(3) + "," + _y.ToString().PadLeft(3) + ")" + Cost.ToString("c").PadLeft(10);
        }
    }
}
