﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZombieDice
{
    class YellowDie : Dice
    {
        public YellowDie() 
        {
            DieColour = System.Drawing.Color.Yellow;

            //2 brains, 2 shotgun, 2 runners
            Faces[0] = Faces[1] = Symbol.Brain;
            Faces[2] = Faces[3] = Symbol.Shotgun;
            Faces[4] = Faces[5] = Symbol.Feet;
        }
    }
}
