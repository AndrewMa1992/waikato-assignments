﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZombieDice
{
    class Dice
    {
        public enum DiceColour { Green, Yellow, Red, };
        public enum Symbol { Brain, Shotgun, Feet,} //represents the symbols a face can have
        public Symbol[] Faces { get; protected set; }  //store the 6 symbols on the faces
        public Symbol RolledFace { get; protected set; }    //the randomly selected face
        public System.Drawing.Color DieColour { get; protected set; } 
        protected static Random RandomSymbol = new Random(); //random number

        public Dice()
        { 
            Faces = new Symbol[6];
            DiceColour dc = new DiceColour();
        }

        /// <summary>
        /// Simulate a random roll on a single die
        /// </summary>
        public void RandomFace()
        {
            int faceNum = RandomSymbol.Next(6);
            RolledFace = Faces[faceNum];
        }
    }
}
