﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZombieDice;
using System.Windows.Forms;

namespace ZombieDice
{
    class Game
    {
        public enum GameStatus
        {
            Win,
            Lose,
            Stop,
            Playing,
        }

        public List<Dice> Dice { get; protected set; } //stores all the dice not yet rolled
        protected List<Dice> RolledDice { get; set; }   //stores dice already rolled
        public List<Dice> PlayerDice { get; private set; }
        protected List<Dice> ReRollDice { get; set; }
        public GameStatus CurrentGameStatus { get; set; }
        private static Random randomDie = new Random();

        //Player stats
        public int Brains { get; private set; }
        public int Shotguns { get; private set; }

        //number of dice for the whole game
        private const int GreenDiceNum = 6;
        private const int YellowDiceNum = 4;
        private const int RedDiceNum = 3;

        /// <summary>
        /// Start a new game of Zombie Dice
        /// </summary>
        public Game()
        {
            Dice = new List<Dice>();
            RolledDice = new List<Dice>();
            PlayerDice = new List<Dice>();
            ReRollDice = new List<Dice>();
            CurrentGameStatus = GameStatus.Playing;

            //6 green, 4 yellow, 3 red dice
            for (int g = 1; g <= GreenDiceNum; g++)
            {
                Dice d = new GreenDie();
                d.RandomFace(); //generate the random face
                Dice.Add(d);
            }

            for (int y = 1; y <= YellowDiceNum; y++)
            {
                Dice d = new GreenDie();
                d.RandomFace(); //generate the random face
                Dice.Add(d);
            }

            for (int r = 1; r <= RedDiceNum; r++)
            {
                Dice d = new RedDie();
                d.RandomFace(); //generate the random face
                Dice.Add(d);
            }

            Brains = Shotguns = 0;
        }

        /// <summary>
        /// Roll the selected player's three dice
        /// </summary>
        public void RollDice()
        {
            PlayerDice.Clear(); //clear player's dice for new round
            
            int diceToRoll = 3;

            if (ReRollDice.Count > 0)
            {
                //readd dice that was rolled feet to be rerolled for this round
                PlayerDice.AddRange(ReRollDice);    
                diceToRoll -= PlayerDice.Count;

                //reroll dice with feet
                foreach (var die in PlayerDice)
                {
                    die.RandomFace();
                }
            }

            ReRollDice.Clear(); //any feet should've been rerolled and added to playerDice, so clear

            for (int d = 1; d <= diceToRoll; d++)   //only get 3 - # of runners random dice from Collection
            {
                int diceNum = randomDie.Next(Dice.Count); //generate a random dice
                PlayerDice.Add(Dice[diceNum]);  //add random dice to player's
            }
            
            CheckDice();
        }

        /// <summary>
        /// Check the results of the rolled dice and do appropriate stat and game status changes
        /// </summary>
        private void CheckDice()
        {
            for (int playerDiceNum = 0; playerDiceNum < PlayerDice.Count; playerDiceNum++)
            {
                switch (PlayerDice[playerDiceNum].RolledFace)
                {
                    case ZombieDice.Dice.Symbol.Brain:
                        AddBrain();
                        break;
                    case ZombieDice.Dice.Symbol.Shotgun:
                        AddShotgun();
                        break;
                    case ZombieDice.Dice.Symbol.Feet:
                        ReRollDice.Add(PlayerDice[playerDiceNum]);  //add to temp list to readd to player list
                        break;
                }

                Dice.Remove(PlayerDice[playerDiceNum]); //remove from collection to prevent rolling die again
            }
        }

        /// <summary>
        /// Add 1 to Brain stat
        /// </summary>
        private void AddBrain()
        {
            Brains++;

            if (Brains == 13)
                Win();
        }

        /// <summary>
        /// Add 1 to Shotgun stat
        /// </summary>
        private void AddShotgun()
        {
            Shotguns++;

            if (Shotguns == 3)
                Lose();
        }

        public string Win()
        {
            CurrentGameStatus = GameStatus.Win;
            return "You win!";
        }

        public string Lose()
        {
            CurrentGameStatus = GameStatus.Lose;
            return "You lose!";
        }

        public void Continue()
        {
            RollDice();
        }

        public string Stop()
        {
            CurrentGameStatus = GameStatus.Stop;
            //give scores
            return "Score: " + Brains;
        }
    }
}
