﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZombieDice
{
    class RedDie : Dice
    {
        public RedDie() 
        {
            DieColour = System.Drawing.Color.Red;

            //1 brains, 3 shotgun, 2 runners
            Faces[0] = Symbol.Brain;
            Faces[1] = Faces[2] = Faces[3] = Symbol.Shotgun;
            Faces[4] = Faces[5] = Symbol.Feet;
        }
    }
}
