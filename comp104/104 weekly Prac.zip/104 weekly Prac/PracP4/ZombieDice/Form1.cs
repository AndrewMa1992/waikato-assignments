﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZombieDice
{
    public partial class Form1 : Form
    {
        Game player1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            NewGame();
        }

        /// <summary>
        /// Starts a new game of Zombie Dice
        /// </summary>
        private void NewGame()
        {
            player1 = new Game();
            UpdateStats();
        }

        private void buttonRoll_Click(object sender, EventArgs e)
        {
            player1.RollDice();
            
            UpdateStats();

            //check game status if win or lose
            if (player1.CurrentGameStatus == Game.GameStatus.Playing)
            {
                        MessageBox.Show(player1.Stop());
                        NewGame();
            }
            else if (player1.CurrentGameStatus == Game.GameStatus.Win)
            {
                MessageBox.Show(player1.Win());
                NewGame();
            }
            else if (player1.CurrentGameStatus == Game.GameStatus.Lose)
            {
                MessageBox.Show(player1.Lose());
                NewGame();
            }         
        }

        /// <summary>
        /// Update stats on the form
        /// </summary>
        private void UpdateStats()
        {
            labelBrains.Text = "Brains: ";
            labelShotguns.Text = "Shotguns: ";
            labelRemainingDice.Text = "Remaining Dice: ";

            labelBrains.Text += player1.Brains;
            labelShotguns.Text += player1.Shotguns;
            labelRemainingDice.Text += player1.Dice.Count;

            if (player1.PlayerDice.Count > 0)
            {
                textBox1.Text = player1.PlayerDice[0].RolledFace.ToString();
                textBox2.Text = player1.PlayerDice[1].RolledFace.ToString();
                textBox3.Text = player1.PlayerDice[2].RolledFace.ToString();

                textBox1.BackColor = player1.PlayerDice[0].DieColour;
                textBox2.BackColor = player1.PlayerDice[1].DieColour;
                textBox3.BackColor = player1.PlayerDice[2].DieColour;
            }
        }

    }
}
