﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZombieDice
{
    class GreenDie : Dice
    {
        public GreenDie() 
        {
            DieColour = System.Drawing.Color.Green;

            //3 brains, 1 shotgun, 2 runners
            Faces[0] = Faces[1] = Faces[2] = Symbol.Brain;
            Faces[3] = Symbol.Shotgun;
            Faces[4] = Faces[5] = Symbol.Feet;
        }
    }
}
