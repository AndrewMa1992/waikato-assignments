﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Post_office
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<letter> listletter = new List<letter>();
        List<Parcel> listparcel = new List<Parcel>();
        List<Postcard> listpostcard = new List<Postcard>();
        private bool letterurgent = false;
        private bool parcelurgent = false;
        public void button1_Click(object sender, EventArgs e)
        {
            letterurgent = false;
            bool urgent = false;
            try
            {
                if (textBox3.Text != "") //if user types in the value of urgentness
                {
                    if (textBox3.Text.ToLower() == "yes")
                    {
                        urgent = true;
                    }
                    else if (textBox3.Text.ToLower() == "no")
                    {
                        urgent = false;
                    }
                    letter lnew = new letter(Convert.ToInt16(textBox1.Text), Convert.ToInt16(textBox2.Text),textBox8.Text, urgent); //new letter, with height, length
                    listletter.Add(lnew);
                    letterurgent = urgent;
                    textBox6.Text = lnew.publiccost.ToString(); //display the cost
                }
                else
                {
                    letter lnew = new letter(Convert.ToInt16(textBox1.Text), Convert.ToInt16(textBox2.Text), textBox8.Text);
                    listletter.Add(lnew);
                    textBox6.Text = lnew.publiccost.ToString(); //display the cost
                }
            }
            catch (Exception)
            {

                MessageBox.Show("you have entered something wrong");
            }
            
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            parcelurgent = false;
            bool urgent = false;
            try
            {
                if (textBox5.Text != "") //if the user types the value of urgentness 
                {
                    if (textBox5.Text.ToLower() == "yes")
                    {
                        urgent = true;
                    }
                    else if (textBox5.Text.ToLower() == "no")
                    {
                        urgent = false;
                    }
                    Parcel pnew = new Parcel(Convert.ToInt32(height.Text), Convert.ToInt32(length.Text), Convert.ToInt32(thickness.Text), textBox9.Text, urgent);
                    listparcel.Add(pnew);
                    parcelurgent = urgent;
                    textBox6.Text = pnew.publiccost.ToString(); //display the cosdt
                }
                else
                {
                    Parcel pnew = new Parcel(Convert.ToInt32(height.Text), Convert.ToInt32(length.Text), Convert.ToInt32(thickness.Text), textBox9.Text);
                    listparcel.Add(pnew);
                    textBox6.Text = pnew.publiccost.ToString();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("you have entered something wrong");
                throw;
            }
            
            
        }
        double cost = 0;
        private void button3_Click(object sender, EventArgs e)
        {
            if (letterurgent) //if urgent
            {
                MessageBox.Show("this letter is already urgent");
                return;
            }
            cost = Convert.ToDouble(textBox6.Text);
            cost += 0.7;
            textBox6.Text = cost.ToString();
            letterurgent = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            letter lnew = new letter(160, 230, "bruce");
            listletter.Add(lnew);
            Parcel pnew = new Parcel(200,4000,400, "bruce");
            listparcel.Add(pnew);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (parcelurgent) //if it is urgent
            {
                MessageBox.Show("this parcel is already urgent");
                return;
            }
            cost = Convert.ToDouble(textBox6.Text);
            cost += 0.7;
            textBox6.Text = cost.ToString();
            parcelurgent = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double cost = 0;
            int num = 0;
            int stamps = 0;
            foreach (letter letter in listletter) //search through the list
            {
                if (letter.publicsender == textBox7.Text.ToLower())
                {
                    cost += letter.publiccost;
                    stamps += letter.Stamp;
                    num++; //stamps and cost are added
                }
            }
            foreach (Parcel parcel in listparcel)
            {
                if (parcel.publicsender == textBox7.Text.ToLower())
                {
                    cost += parcel.publiccost;
                    stamps += parcel.Stamp;
                    num++;
                }
            }
            foreach (Postcard item in listpostcard)//search through the postcard list
            {
                if (item.publicsender == textBox4.Text.ToLower())
                {
                    cost += item.publiccost;
                    stamps += item.Stamp;
                    num++;
                }
            }
            stamps = Convert.ToInt16(cost/ 0.7);
            MessageBox.Show(textBox7.Text + " sent " + num.ToString() + " items needing " + stamps.ToString() + " stamps costing $" + cost.ToString());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Postcard pnew = new Postcard(textBox4.Text); //add new postcard
            listpostcard.Add(pnew);
        }
    }
}
