﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class letter
    {
        protected double cost = 0;
        public double publiccost 
        {
            get { return cost; }
        }
        protected string sender = "";
        public string publicsender
        {
            get { return sender; }
        }

        protected int stamp = 0;
        public int Stamp { get { return stamp; } }
        public virtual bool urgent
        {
            get { return purgent; }
            set { purgent = value;}
        }
        protected bool purgent = false;
        public letter (int height, int length,string name, bool lurgent)
        {
            if (height <= 130 && length <= 235) //compare the length, height 
            {
                cost = 0.70;
                stamp = 1;
            }
            else if (height <= 165 && length <= 235)
            {
                cost = 1.40;
                stamp = 2;
            }
            else if (height <= 230 && length <= 325)
            {
                cost = 2.10;
                stamp = 3;
            }
            else
            {
                cost = 2.80;
                stamp = 4;
            }
            purgent = lurgent; //if urgent
            if (purgent)
            {
                cost += 0.70;
            }
            sender = name;
        }
        public letter (int lheight, int llength,string name) : this(lheight,llength,name,false)
        {

        }
    }
}
