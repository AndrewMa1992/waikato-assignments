﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class Postcard : Parcel
    {
        public override bool urgent
        {
            get
            {
                return base.urgent; //get only
            }
        }
        public Postcard(string name)
            : base(0, 0, 0, name, true)
        { //make 2 stamps and 1.4 cost
            stamp = 2;
            cost = 1.4;
            urgent = true;
        }
    }
}
