﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PracP4
{
    class PoolBall : MovingBall 
    {
        public PoolBall(int x, int y, int dx, int dy):base(x,y,dx,dy)
        {

        }
        /// <summary>
        /// Move the ball horizontally by the value dx.
        /// </summary>
        /// <param name="dx">Amount to move the ball horizontally. Positive value means right, negative means left</param>
        /// 
        public override void Move() //override
        {
            MoveHorizontal(xSpeed);
            MoveVertical(ySpeed);
        }
        public override void MoveHorizontal(int dx)
        {
            int temp = xCoord;
            xCoord += dx;
            if (dx > 233 && dx < 0) //if moving out of border
            {
                xCoord = temp;
                throw new Exception("moving out of the border");
            }
        }

        /// <summary>
        /// Move the ball vertically by the value dy.
        /// </summary>
        /// <param name="dy">Amount to move the ball vertically. Positive value means down, negative means up</param>
        public override void MoveVertical(int dy)
        {
            int temp = xCoord;
            yCoord += dy;
            if (dy > 117 && dy < 0) //if moving out of border
            {
                yCoord = temp;
                throw new Exception("moving out of the border");
            }
        }
    }
}
