﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP4
{
    class ColorPoolBall : PoolBall
    {
        byte R = 0;
        byte G = 0;
        byte B = 0;
        Color myRgbColor = new Color();
        Pen pen2;//initialise variables

        public ColorPoolBall(byte r, byte g, byte b, int x, int y, int dx, int dy) : base(x,y,dx,dy)
        {
            R = r; 
            G = g;
            B = b;
            myRgbColor = Color.FromArgb(R, G, B);
            pen2 = new Pen (Color.FromArgb(R,G,B)); //create new rgb color

        }
        public override void Display(System.Drawing.Graphics paper)
        {
            paper.DrawEllipse( pen2, xCoord, yCoord, size, size); //override
        }
    }
}
