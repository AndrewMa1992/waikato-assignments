﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            List<string> vocabs = new List<string>();
            List<string> tempTrack = new List<string>();
            System.IO.StreamReader file = new System.IO.StreamReader(@"H:\Visual Studio 2013\Projects\104\PracP1\task 2\A.txt");
            while ((line = file.ReadLine()) != null)
            {
                vocabs.Add(line);
            }
            int count = 0;
            Console.Write("Num Occurrances\t\t\tNames\n");
            foreach (string item in vocabs)
            {
                if (!tempTrack.Contains(item))
                {
                    foreach (string item2 in vocabs)
                    {
                        if (item == item2)
                        {
                            count++;
                        }
                    }
                    tempTrack.Add(item);
                    Console.Write(count + "\t\t\t\t" + item + "\n");
                    count = 0;
                }
                
            }
            Console.ReadKey();

            
        }
    }
}
