﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_3
{
    class Program
    {
        static string[] upperalphabets = new string[] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        static char[] lowerAlphabet = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

        static void Main(string[] args)
        {
            if (args.Length == 1)
            {
                int input;

                if (int.TryParse(args[0].ToString(), out input))
                {
                    output(input);
                }
            }
        }

        static void output(int input)
        {
            //if (input >= 8)
            //{
            //    Console.WriteLine("input is too large");
            //    return;
            //}
            System.IO.StreamWriter file = new System.IO.StreamWriter("H:/Visual Studio 2013/Projects/104/PracP1/task 3/A.txt");
            string textout = "";
            file.WriteLine("String\t\t\tIncrement\n");
            for (int i = 0; i <= input; i++)
            {
                string tempout = "";
                int increment = 0;
                int count = 0;
                while (count <= i)
                {
                    if (increment > 50)
                    {
                        int lastattemp = 0;
                        while (increment >= 0)
                        {
                            lastattemp = increment;
                            increment = increment - 50;
                        }
                        increment = lastattemp;
                    }
                    if (increment > 25)
                    {
                        tempout += lowerAlphabet[increment - 25].ToString();
                    }

                    if (increment <= 25)
                    {
                        tempout += upperalphabets[increment];
                    }
                    increment = increment + i ;
                    count++;
                }
                if (i >= 7)
                {
                    tempout += "\t\t+" + i;
                }
                else
                {
                    tempout += "\t\t\t+" + i;
                }
                file.WriteLine(tempout + "\n");
            }
            file.Close();
            
            
        }
    }
}
