﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PracP1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            string s = "";

            //check if 2 args
            if (args.Length == 2)
            {
                if (int.TryParse(args[0], out n))
                {
                    //successful parse, so use n
                    s = args[1]; //second argument is character

                    //draw a line of characters
                    DrawChars(n, s);
                }
                else
                {
                    //unsuccessful parse, so no n value
                }
            }

            //wait for user to have read output
            Console.WriteLine();
            Console.Write("Press enter to finish:");
            Console.ReadLine();
        }
        /// <summary>
        /// Method to draw a line of characters
        /// </summary>
        /// <param name="n">number of characters to draw</param>
        /// <param name="s">character to draw n times</param>
        static void DrawChars(int n, string s)
        {
            int num = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (num == j)
                    {
                        int temp = num;
                        if (num > 8)
                        {
                            num = (num +1) % 10;
                        }
                        Console.Write(num);
                        num = temp;
                    }
                    else
                    {
                        Console.Write(s);
                    }
                }
                Console.WriteLine();
                num++;
            }
            Console.WriteLine();
        }

    }
}
