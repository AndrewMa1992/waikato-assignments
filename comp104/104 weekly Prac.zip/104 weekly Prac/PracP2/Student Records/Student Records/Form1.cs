﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Records
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool has = false;
            if (textBox3.Text.ToLower() == "yes")
	{
		 has = true;
	}
            else if (textBox3.Text.ToLower() == "no")
	{
		 has = false;
	}
            else if (textBox3.Text == "")
            {
                has = false;
            }
            else
	{
                MessageBox.Show("you must enter either yes or no");
                return;
	}
            try 
	{
        Student snew = new Student(textBox1.Text, Convert.ToInt16(textBox2.Text), has);
        listBox1.Items.Add(snew.ToString());
	}
	catch (Exception)
	{

        MessageBox.Show("you have entered wrong values");
        return;
	}
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Paper pnew = new Paper(textBox4.Text, Convert.ToInt16(textBox5.Text), textBox6.Text);
                listBox1.Items.Add(pnew.ToString());
            }
            catch (Exception)
            {

                MessageBox.Show("you have enter wrong values");
                return;
            }
            
        }
    }
}
