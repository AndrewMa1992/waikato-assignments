﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Records
{
    class Student
    {
        public string sName {get 
           { 
              return sname; 
           }
           set 
           {
              sname = value; 
           }}
        private string sname = "";

        public int sID
        {
            get
            {
                return sid;
            }
            set
            {
                sid = value;
            }
        }
        private int sid = 0;

        public bool sPaid
        {
            get
            {
                return spaid;
            }
            set
            {
                spaid = value;
            }
        }
        private bool spaid = false;


        public Student (string name, int id, bool has)
        {
            sname = name;
            sid = id;
            spaid = has;
        }

        public override string ToString()
        {
            string haspaid = "";
            if (spaid)
	{
		 haspaid = "has paid";
	}
            else
	{
                haspaid = "has not paid";
	}
            return sname + "\t" + sid.ToString() + "\t" + haspaid;
        }
    }
}
