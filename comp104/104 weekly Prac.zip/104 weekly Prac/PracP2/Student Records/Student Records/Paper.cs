﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Records
{
    class Paper
    {
        public string sName
        {
            get
            {
                return sname;
            }
            set
            {
                sname = value;
            }
        }
        private string sname = "";

        public int sID
        {
            get
            {
                return sid;
            }
            set
            {
                sid = value;
            }
        }
        private int sid = 0;

        public string slName
        {
            get
            {
                return slname;
            }
            set
            {
                slname = value;
            }
        }
        private string slname = "";


        public Paper(string name, int id, string lname)
        {
            sname = name;
            sid = id;
            slname = lname;
        }

        public override string ToString()
        {
            return sname + "\t" + sid.ToString() + "\t" + slname;
        }
    }
}
