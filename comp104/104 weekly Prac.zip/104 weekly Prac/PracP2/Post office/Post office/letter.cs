﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class letter
    {
        private double cost = 0;
        public double publiccost
        {
            get { return cost; }
        }
        public bool urgent
        {
            get { return purgent; }
            set { purgent = value;}
        }
        private bool purgent = false;
        public letter (int height, int length, bool lurgent)
        {
            if (height <= 130 && length <= 235)
            {
                cost = 0.70;
            }
            else if (height <= 165 && length <= 235)
            {
                cost = 1.40;
            }
            else if (height <= 230 && length <= 325)
            {
                cost = 2.10;
            }
            else
            {
                cost = 2.80;
            }
            purgent = lurgent;
            if (purgent)
            {
                cost += 0.70;
            }
        }
        public letter (int lheight, int llength) : this(lheight,llength,false)
        {

        }
    }
}
