﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Post_office
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private bool letterurgent = false;
        private bool parcelurgent = false;
        public void button1_Click(object sender, EventArgs e)
        {
            letterurgent = false;
            bool urgent = false;
            try
            {
                if (textBox3.Text != "")
                {
                    if (textBox3.Text.ToLower() == "yes")
                    {
                        urgent = true;
                    }
                    else if (textBox3.Text.ToLower() == "no")
                    {
                        urgent = false;
                    }
                    letter lnew = new letter(Convert.ToInt16(textBox1.Text), Convert.ToInt16(textBox2.Text), urgent);
                    letterurgent = urgent;
                    textBox6.Text = lnew.publiccost.ToString();
                }
                else
                {
                    letter lnew = new letter(Convert.ToInt16(textBox1.Text), Convert.ToInt16(textBox2.Text));
                    textBox6.Text = lnew.publiccost.ToString();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("you have entered something wrong");
            }
            
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            parcelurgent = false;
            bool urgent = false;
            try
            {
                if (textBox5.Text != "")
                {
                    if (textBox5.Text.ToLower() == "yes")
                    {
                        urgent = true;
                    }
                    else if (textBox5.Text.ToLower() == "no")
                    {
                        urgent = false;
                    }
                    Parcel pnew = new Parcel(Convert.ToInt32(textBox4.Text), urgent);
                    parcelurgent = urgent;
                    textBox6.Text = pnew.publiccost.ToString();
                }
                else
                {
                    Parcel pnew = new Parcel(Convert.ToInt32(textBox4.Text));
                    textBox6.Text = pnew.publiccost.ToString();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("you have entered something wrong");
                throw;
            }
            
            
        }
        double cost = 0;
        private void button3_Click(object sender, EventArgs e)
        {
            if (letterurgent)
            {
                MessageBox.Show("this letter is already urgent");
                return;
            }
            cost = Convert.ToDouble(textBox6.Text);
            cost += 0.7;
            textBox6.Text = cost.ToString();
            letterurgent = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (parcelurgent)
            {
                MessageBox.Show("this parcel is already urgent");
                return;
            }
            cost = Convert.ToDouble(textBox6.Text);
            cost += 0.7;
            textBox6.Text = cost.ToString();
            parcelurgent = true;
        }
    }
}
