﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class Parcel
    {
        public bool urgent
        {
            get { return purgent; }
            set { purgent = value; }
        }
        private bool purgent = false;
        private double cost = 0;
        public double publiccost
        {
            get { return cost; }
        }

        public Parcel(int size,bool urgent)
        {
            if (size <= 2000000)
            {
                cost = 1.40;
            }
            else if (size <= 3000000)
            {
                cost = 2.10;
            }
            else if (size <= 6000000)
            {
                cost = 2.80;
            }
            else
            {
                cost = 3.50;
            }
            purgent = urgent;
            if (purgent)
            {
                cost += 0.70;
            }
        }
        public Parcel (int lsize) : this(lsize,false)
        {

        }
    }
}
