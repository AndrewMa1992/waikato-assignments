﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PracP5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        List<Sprite> sprites = new List<Sprite>();
        List<Sprite> spritesRemove = new List<Sprite>();
        
        private void buttonGo_Click(object sender, EventArgs e)
        {
            //add sprites to list(s)
            sprites.Clear(); //reset any old simulation first
            sprites.Add(new AlienBomb(100, 60));
            sprites.Add(new Missile(100, 270));
            sprites.Add(new AlienBomb(300, 60));
            sprites.Add(new Missile(170, 205));
            for (int x = 100; x <= 500; x += 100)
                sprites.Add(new AlienShip(x, 50));
            sprites.Add(new PlayerShip(100, 270));
            
            //start timer
            timer1.Interval = 500;
            timer1.Start();           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Graphics paper = CreateGraphics();
            paper.Clear(this.BackColor);

            //move all the things!
            foreach (Sprite s in sprites)
            {
                if (s is Explosion)
                {
                    Explosion s2 = new Explosion(1, 1);
                    s2 = (Explosion)s;
                    if (s2.pwidth == 0 && s2.pheight == 0)
                    {
                        spritesRemove.Add(s);
                        s2 = null;
                    }
                    else
                    {
                        s.Display(paper);
                    }
                }
                else
                {
                    s.Move(15);
                    s.Display(paper);
                }
                
                
            }

            foreach (Sprite item in spritesRemove)
            {
                sprites.Remove(item);
            }
            spritesRemove.Clear();

            //check for collisions!
            for (int i = 0; i < sprites.Count; i++) //cannot use a foreach loop as modify sprites
            {
                for (int j = 0; j < sprites.Count; j++) //cannot use a foreach loop as modify sprites
                {
                    Sprite s1 = sprites[i];
                    Sprite s2 = sprites[j];
                    if (s1.Equals(s2) && !(s1 == s2)) //are the two sprites intersecting, but not the same object
                    {
                        //add explosion sprite here?
                        Explosion explo = new Explosion(s1.X, s1.Y);
                        sprites.Add(explo);
                        sprites.Remove(s1);
                        sprites.Remove(s2);
                        
           //             timer1.Stop(); //stop animation?
                        break;
                    }
                }
            }

            //aliens drop bombs
            for (int i = 0; i < sprites.Count; i++) //cannot use a foreach loop as modify sprites
            {
                if (sprites[i] is AlienShip)
                {
                    //drop bomb?
                    AlienShip ship = (AlienShip)sprites[i]; //cast sprite as an alienship object
                    AlienBomb bomb = ship.DropBomb();
                    if (bomb != null)
                        sprites.Add(bomb);
                }
            }

        }
    }
}
