﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP5
{
    abstract class Sprite
    {
        protected Rectangle _sprite;
        protected const int RADIUS = 2;
        public Sprite(int x, int y)
        {
            _sprite = new Rectangle(x, y, RADIUS * 2, RADIUS * 2);
        }
        public virtual int X
        {
            get { return _sprite.X + RADIUS; }
        }
        public virtual int Y
        {
            get { return _sprite.Y + RADIUS; }
        }
        public abstract void Move(int pixels);
        //cannot move a sprite

        public abstract void Display(Graphics paper);
        //cannot display a sprite

        public override bool Equals(object obj)
        {
            Sprite s = (Sprite)obj;
            return this._sprite.IntersectsWith(s._sprite);
        }
    }
}
