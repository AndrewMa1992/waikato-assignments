﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP5
{
    class AlienShip : Sprite
    {
        private static int direction = 1; //direction aliens move across screen
        private const int BORDER = 50;
        private const int CHANCE = 7; //one in 7 chance of dropping bomb

        private static Random rand; //static so one random number generator for all alien ships

        public AlienShip(int x, int y)
            : base(x, y)
        {
            _sprite.Width = RADIUS * 4;
            _sprite.Height = RADIUS * 4;
            rand = new Random();
        }
        public override void Move(int pixels)
        {
            _sprite.X += pixels * direction;
            if (_sprite.X < BORDER || _sprite.X > 600-BORDER)
                direction *= -1; //change direction
        }
        public override void Display(Graphics paper)
        {
             //draw body
            paper.FillEllipse(Brushes.Black, _sprite.X, _sprite.Y, _sprite.Width, _sprite.Height/2);
            //draw legs
            if (_sprite.X % 20 < 10)
            {

                paper.FillRectangle(Brushes.Black, _sprite.X, _sprite.Y + RADIUS, RADIUS / 2, _sprite.Height / 2);
                paper.FillRectangle(Brushes.Black, _sprite.X+ _sprite.Width-RADIUS/2, _sprite.Y + RADIUS, RADIUS / 2, _sprite.Height / 2);
            }
            else
            {
                paper.FillRectangle(Brushes.Black, _sprite.X+1, _sprite.Y + RADIUS, RADIUS / 2, _sprite.Height / 2);
                paper.FillRectangle(Brushes.Black, _sprite.X + _sprite.Width - RADIUS / 2 - 1, _sprite.Y + RADIUS, RADIUS / 2, _sprite.Height / 2);
            }
        }
        public AlienBomb DropBomb()
        {
            AlienBomb bomb = null;
            if (rand.Next(CHANCE) == 0)
            {
                bomb = new AlienBomb(_sprite.X, _sprite.Y);
            }
            return bomb;
        }
    }
}
