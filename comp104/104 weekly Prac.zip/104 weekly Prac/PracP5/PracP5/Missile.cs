﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP5
{
    class Missile : Sprite
    {
        public Missile(int x, int y) : base(x,y)
        {
            _sprite.Width = RADIUS;            
        }
        public override int X
        {
            get { return _sprite.X + RADIUS / 2; }
        }
       
        public override void Move(int pixels)
        {
            _sprite.Y -= pixels;
        }
        public override void Display(Graphics paper)
        {
            if (_sprite.Y % 20 < 10)
                paper.FillRectangle(Brushes.Red, _sprite);
            else
                paper.FillRectangle(Brushes.Gold, _sprite);
        }
    }
}
