﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP5
{
    class PlayerShip : Sprite
    {
        public PlayerShip(int x, int y)
            : base(x, y)
        {

        }

        public void MovePlayerShip(int mx,int my)
        {
            _sprite.Y += my;
            _sprite.X += mx;
        }
        public override void Move(int pixels)
        {
            _sprite.X += pixels;
        }

        public override void Display(System.Drawing.Graphics paper)
        {
            paper.FillRectangle(Brushes.Green, _sprite.X, _sprite.Y, 10, 3); //centred at the x
            paper.FillRectangle(Brushes.Green, _sprite.X + 4, _sprite.Y - 2, 2, 2); //draw the thing on the top
        }
    }
}
