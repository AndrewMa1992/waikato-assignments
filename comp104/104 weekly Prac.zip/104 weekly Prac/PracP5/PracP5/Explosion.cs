﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP5
{
    class Explosion : Sprite
    {
        public int pwidth = 10;
        public int pheight = 10;
        public Explosion(int x, int y)
            : base(x, y)
        {
            
        }

        public override void Move(int pixels)
        {
            
        } 

        public override void Display(System.Drawing.Graphics paper)
        {
            paper.FillEllipse(Brushes.Red, _sprite.X, _sprite.Y, pwidth, pheight);
            pwidth = pwidth - 2; //decrease the width and height each time
            pheight = pheight - 2;
        }
    }
}
