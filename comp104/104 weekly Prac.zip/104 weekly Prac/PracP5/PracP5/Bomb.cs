﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP5
{
    class AlienBomb : Sprite
    {
        public AlienBomb(int x, int y)
            : base(x, y)
        {
            //only put in here extra code after base (sprite) constructor is called        
        }
        public override void Move(int pixels)
        {
            _sprite.Y += pixels;
        }
        public override void Display(Graphics paper)
        {
            paper.FillEllipse(Brushes.Black, _sprite);
        }
    }
}
