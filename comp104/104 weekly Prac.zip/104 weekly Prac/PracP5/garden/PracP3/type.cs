﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace PracP3
{
    class type : Plant
    {
        private int length;
        private int width;
        public type(string name, int length,int width, decimal cost, int x, int y)
            : base(name, 0, cost, x, y)
        {
            this.length = length;
            this.width = width;
        }
        public override void DrawPlant(Graphics paper)
        {
            paper.FillRectangle(Brushes.Blue, _x, _y, width, length); //draw rectangle
        }
        public override string ToString() //rewrite so length and width is displayed
        {
            return Name.PadRight(25) + length.ToString().PadLeft(4) + "cm length and " + width.ToString().PadLeft(4) + "cm width at " +
               "(" + _x.ToString().PadLeft(3) + "," + _y.ToString().PadLeft(3) + ")" + Cost.ToString("c").PadLeft(10);
        }
    }
}
