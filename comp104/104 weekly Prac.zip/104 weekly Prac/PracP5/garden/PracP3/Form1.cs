﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PracP3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //lots of plants!
        List<Plant> garden = new List<Plant>();

        decimal tcost = 0;

         /// <summary>
        /// add a plant at x,y position of mouse.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBoxGarden_MouseDown(object sender, MouseEventArgs e)
        {
                int mouseX = e.X;
                int mouseY = e.Y;

                try
                {
                    string name = textBoxName.Text;
                    decimal cost = Convert.ToDecimal(textBoxCost.Text);

                    if (string.IsNullOrEmpty(textBox1.Text))
                    {
                        int size = Convert.ToInt32(textBoxSize.Text);
                        Plant plant = new Plant(name, size, cost, mouseX, mouseY);
                        garden.Add(plant); //add new plant to list
                        Graphics paper = pictureBoxGarden.CreateGraphics();
                        plant.DrawPlant(paper);
                    }
                    else
                    {
                        int length = Convert.ToInt16(textBox1.Text);
                        int width = Convert.ToInt16(textBox2.Text); //length and width
                        type plant = new type(name, length, width, cost, mouseX, mouseY); //new type
                        garden.Add(plant); //add new plant to list
                        Graphics paper = pictureBoxGarden.CreateGraphics();
                        plant.DrawPlant(paper);
                    }
                    
                    tcost += cost;

                    

                }
                catch (Exception)
                {
                    throw new Exception();
                    MessageBox.Show("values are wrong");
                    
                }
                

                
                

                

                //update listbox
                listBoxPlants.DataSource = null;
                listBoxPlants.DataSource = garden;

        }

        private void buttonFinish_Click(object sender, EventArgs e)
        {
            
            using(System.IO.StreamWriter file = new System.IO.StreamWriter("H:/Visual Studio 2013/Projects/104/PracP5/garden/A.txt")) //write to files
	{
		 foreach (Plant item in garden)
	{

        file.WriteLine(item.ToString()); //each line
	}
         file.WriteLine("Total Cost" + "                          " + tcost.ToString()); //last line
	}
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


    }
}
