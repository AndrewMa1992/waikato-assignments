﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    abstract class PostallItem
    {
        protected double cost = 0; //all the common values
        public double publiccost
        {
            get { return cost; }
        }
        protected string sender = "";
        public string publicsender
        {
            get { return sender; }
        }

        protected int stamp = 0;
        public int Stamp { get { return stamp; } }
        public virtual bool urgent
        {
            get { return purgent; }
            set { purgent = value; }
        }
        protected bool purgent = false;

    }
}
