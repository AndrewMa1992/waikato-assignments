﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class Postcard : PostallItem
    {
        public override bool urgent
        {
            get
            {
                return base.urgent; //get only
            }
        }
        public Postcard(string name)
        { //make 2 stamps and 1.4 cost
            stamp = 2;
            cost = 1.4;
            urgent = true;
            sender = name;
        }
    }
}
