﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Post_office
{
    class Parcel : PostallItem
    {
        public Parcel(int height,int length, int thickness,string name,bool urgent) 
        {
            int size = height * length * thickness; //calculate the size
            if (size <= 2000000)
            {
                cost = 1.40;
                stamp = 1;
            }
            else if (size <= 3000000)
            {
                cost = 2.10;
                stamp = 2;
            }
            else if (size <= 6000000)
            {
                cost = 2.80;
                stamp = 3;
            }
            else
            {
                cost = 3.50;
                stamp = 4;
            }
            purgent = urgent;
            if (purgent) //if it is urgent
            {
                cost += 0.70;
            }
            sender = name;
        }
        public Parcel(int height, int length, int thickness, string name)
            : this(height,length,thickness, name, false)
        {

        }
    }
}
